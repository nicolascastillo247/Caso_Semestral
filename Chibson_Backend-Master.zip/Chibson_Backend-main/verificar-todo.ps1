function Test-Puerto([int]$puerto) {
    [bool](Get-NetTCPConnection -LocalPort $puerto -State Listen -ErrorAction SilentlyContinue)
}

function Get-Codigo([string]$url) {
    try {
        (Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10).StatusCode
    } catch {
        if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    }
}

$servicios = @(
    @{ Nombre = 'usuarios';  Puerto = 8081; Ruta = '/api/roles/verificar?rut=12345678-5&permiso=VER_PERFIL' },
    @{ Nombre = 'productos'; Puerto = 8082; Ruta = '/api/productos' },
    @{ Nombre = 'ventas';    Puerto = 8083; Ruta = '/api/devoluciones/pendientes/contar' },
    @{ Nombre = 'soporte';   Puerto = 8084; Ruta = '/api/tickets/abiertos/contar' },
    @{ Nombre = 'contenido'; Puerto = 8085; Ruta = '/api/noticias/publicadas' },
    @{ Nombre = 'informes';  Puerto = 8086; Ruta = '/api/reportes' }
)

Write-Host ''
if (Test-Puerto 3306) {
    Write-Host 'MySQL (3306)   OK' -ForegroundColor Green
} else {
    Write-Host 'MySQL (3306)   APAGADO' -ForegroundColor Red
}
$gateway = Test-Puerto 8080
if ($gateway) {
    Write-Host 'Gateway (8080) OK' -ForegroundColor Green
} else {
    Write-Host 'Gateway (8080) APAGADO' -ForegroundColor Red
}
Write-Host ''
Write-Host ('{0,-10} {1,-7} {2,-9} {3,-9} {4}' -f 'Servicio', 'Puerto', 'Swagger', 'Gateway', 'Estado')
Write-Host ('-' * 60)

$malos = 0
foreach ($s in $servicios) {
    if (-not (Test-Puerto $s.Puerto)) {
        Write-Host ('{0,-10} {1,-7} {2,-9} {3,-9} {4}' -f $s.Nombre, $s.Puerto, '-', '-', 'APAGADO') -ForegroundColor Red
        $malos++
        continue
    }
    $directo = Get-Codigo "http://localhost:$($s.Puerto)/v3/api-docs"
    $porGateway = if ($gateway) { Get-Codigo "http://localhost:8080$($s.Ruta)" } else { 0 }
    $gatewayOk = @(200, 401, 403) -contains $porGateway

    if ($directo -eq 200 -and $gatewayOk) {
        $estado = 'OK'; $color = 'Green'
    } elseif ($directo -eq 200) {
        $estado = 'Responde, pero no por el gateway'; $color = 'Yellow'; $malos++
    } else {
        $estado = 'ERROR (revisa su ventana)'; $color = 'Red'; $malos++
    }
    Write-Host ('{0,-10} {1,-7} {2,-9} {3,-9} {4}' -f $s.Nombre, $s.Puerto, $directo, $porGateway, $estado) -ForegroundColor $color
}

Write-Host ''
if ($malos -eq 0 -and $gateway) {
    Write-Host 'Todo esta funcionando.' -ForegroundColor Green
} else {
    Write-Host "Hay $malos servicio(s) con problemas." -ForegroundColor Yellow
}
