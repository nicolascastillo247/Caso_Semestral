package chibson.contenido.controller;

import chibson.contenido.LimpiezaBaseDatos;
import chibson.contenido.client.UsuariosClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class InformacionInstitucionalControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String RUT = "12345678-5";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    @Test
    void getWhenEmpty() throws Exception {
        mockMvc.perform(get("/api/institucional"))
                .andExpect(status().isOk());
    }

    @Test
    void updateAndGet() throws Exception {
        mockMvc.perform(put("/api/institucional").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"mision\":\"Misión\",\"correo\":\"contacto@chibson.cl\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.correo").value("contacto@chibson.cl"));

        mockMvc.perform(get("/api/institucional"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mision").value("Misión"))
                .andExpect(jsonPath("$.correo").value("contacto@chibson.cl"));
    }

    @Test
    void updateWithoutContact400() throws Exception {
        mockMvc.perform(put("/api/institucional").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"mision\":\"Solo misión\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("GESTIONAR_NOTICIAS"));

        mockMvc.perform(put("/api/institucional").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"correo\":\"a@b.cl\"}"))
                .andExpect(status().isForbidden());
    }
}
