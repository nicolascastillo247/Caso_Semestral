package chibson.contenido.service;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.dto.RegistroAccionDTO;
import chibson.contenido.model.InformacionInstitucional;
import chibson.contenido.repository.InformacionInstitucionalRepository;
import chibson.contenido.service.InformacionInstitucionalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class InformacionInstitucionalServiceTest {
    @Mock
    private InformacionInstitucionalRepository repository;
    @Mock
    private UsuariosClient usuariosClient;
    @InjectMocks
    private InformacionInstitucionalService service;

    @Test
    void getWhenEmpty() {
        when(repository.findById(InformacionInstitucional.ID_UNICO)).thenReturn(Optional.empty());

        InformacionInstitucional info = service.obtenerInformacion();

        assertEquals(InformacionInstitucional.ID_UNICO, info.getIdInformacion());
        assertNull(info.getCorreo());
    }

    @Test
    void getSaved() {
        InformacionInstitucional guardada = new InformacionInstitucional(1L, "M", "V", "a@b.cl", null, null);
        when(repository.findById(1L)).thenReturn(Optional.of(guardada));

        assertEquals("a@b.cl", service.obtenerInformacion().getCorreo());
    }

    @Test
    void updateNoContact() {
        InformacionInstitucional datos = new InformacionInstitucional(null, "Misión", "Visión", " ", null, "");

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> service.actualizarInformacion(datos, "12345678-5"));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
        verify(repository, never()).save(any());
    }

    @Test
    void updateSaves() {
        InformacionInstitucional actual = new InformacionInstitucional(1L, "M", "V", "viejo@b.cl", null, null);
        when(repository.findById(1L)).thenReturn(Optional.of(actual));
        when(repository.save(any(InformacionInstitucional.class))).thenAnswer(i -> i.getArgument(0));
        InformacionInstitucional datos = new InformacionInstitucional(99L, "M", "V", "nuevo@b.cl", null, null);

        InformacionInstitucional guardada = service.actualizarInformacion(datos, "12345678-5");

        assertEquals(1L, guardada.getIdInformacion());
        ArgumentCaptor<RegistroAccionDTO> accion = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(accion.capture());
        assertEquals(1, accion.getValue().getCambios().size());
        assertEquals("correo", accion.getValue().getCambios().get(0).getCampo());
    }
}
