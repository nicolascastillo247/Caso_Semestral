package chibson.contenido.client;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.dto.RegistroAccionDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsuariosClientTest {
    @Mock
    private RestTemplate restTemplate;

    private UsuariosClient client;

    @BeforeEach
    void setUp() {
        client = new UsuariosClient(restTemplate, "http://localhost:8081");
    }

    @Test
    void noRut401() {
        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> client.exigirPermiso(" ", "GESTIONAR_NOTICIAS"));

        assertEquals(HttpStatus.UNAUTHORIZED, e.getStatusCode());
    }

    @Test
    void allowed() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("12345678-5"), eq("GESTIONAR_NOTICIAS")))
                .thenReturn(true);

        assertDoesNotThrow(() -> client.exigirPermiso(" 12345678-5 ", "GESTIONAR_NOTICIAS"));
    }

    @Test
    void denied403() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("12345678-5"), eq("GESTIONAR_NOTICIAS")))
                .thenReturn(false);

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> client.exigirPermiso("12345678-5", "GESTIONAR_NOTICIAS"));

        assertEquals(HttpStatus.FORBIDDEN, e.getStatusCode());
    }

    @Test
    void down503() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("12345678-5"), eq("GESTIONAR_NOTICIAS")))
                .thenThrow(new ResourceAccessException("sin conexión"));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> client.exigirPermiso("12345678-5", "GESTIONAR_NOTICIAS"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, e.getStatusCode());
    }

    @Test
    void logAction() {
        RegistroAccionDTO accion = new RegistroAccionDTO("12345678-5", "CREAR", "Noticias", "Creó", new ArrayList<>());

        client.registrarAccion(accion);

        verify(restTemplate).postForObject("http://localhost:8081/api/acciones", accion, Void.class);
    }

    @Test
    void logActionFailure() {
        RegistroAccionDTO accion = new RegistroAccionDTO("12345678-5", "CREAR", "Noticias", "Creó", new ArrayList<>());
        when(restTemplate.postForObject(anyString(), eq(accion), eq(Void.class)))
                .thenThrow(new ResourceAccessException("sin conexión"));

        assertDoesNotThrow(() -> client.registrarAccion(accion));
    }
}
