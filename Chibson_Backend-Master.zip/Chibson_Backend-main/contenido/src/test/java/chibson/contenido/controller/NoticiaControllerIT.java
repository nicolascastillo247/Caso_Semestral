package chibson.contenido.controller;

import chibson.contenido.LimpiezaBaseDatos;
import chibson.contenido.client.UsuariosClient;
import chibson.contenido.model.CategoriaNoticia;
import chibson.contenido.model.EstadoNoticia;
import chibson.contenido.model.Noticia;
import chibson.contenido.repository.NoticiaRepository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class NoticiaControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String RUT = "12345678-5";
    private static final String CUERPO = "{\"titulo\":\"Oferta\",\"contenido\":\"Descuentos\",\"categoria\":\"PROMOCION\",\"publicar\":true}";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private NoticiaRepository noticiaRepository;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Noticia guardar(String titulo, EstadoNoticia estado) {
        Noticia n = new Noticia();
        n.setTitulo(titulo);
        n.setContenido("Contenido");
        n.setCategoria(CategoriaNoticia.PROMOCION);
        n.setEstado(estado);
        n.setFechaPublicacion(LocalDate.now());
        n.setFechaModificacion(LocalDateTime.now());
        return noticiaRepository.save(n);
    }

    @Test
    void createAndListPublished() throws Exception {
        mockMvc.perform(post("/api/noticias").header("X-Rut-Usuario", RUT).contentType(JSON).content(CUERPO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idNoticia").exists())
                .andExpect(jsonPath("$.estado").value("ACTIVADA"));

        mockMvc.perform(get("/api/noticias/publicadas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.noticias.length()").value(1))
                .andExpect(jsonPath("$._embedded.noticias[0].titulo").value("Oferta"));
    }

    @Test
    void createDraftIsNotPublic() throws Exception {
        mockMvc.perform(post("/api/noticias").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"titulo\":\"Borrador\",\"contenido\":\"x\",\"categoria\":\"EVENTO\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.estado").value("BORRADOR"));

        mockMvc.perform(get("/api/noticias/publicadas"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
    }

    @Test
    void createWithoutTitle400() throws Exception {
        mockMvc.perform(post("/api/noticias").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"contenido\":\"x\",\"categoria\":\"EVENTO\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void publishedDetailAndNotFound() throws Exception {
        Noticia n = guardar("Oferta", EstadoNoticia.ACTIVADA);
        Noticia borrador = guardar("Borrador", EstadoNoticia.BORRADOR);

        mockMvc.perform(get("/api/noticias/publicadas/" + n.getIdNoticia()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Oferta"));
        mockMvc.perform(get("/api/noticias/publicadas/" + borrador.getIdNoticia()))
                .andExpect(status().isNotFound());
    }

    @Test
    void adminListWithFilters() throws Exception {
        guardar("Oferta de verano", EstadoNoticia.ACTIVADA);
        guardar("Evento de percusión", EstadoNoticia.BORRADOR);

        mockMvc.perform(get("/api/noticias").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.noticias.length()").value(2));
        mockMvc.perform(get("/api/noticias").header("X-Rut-Usuario", RUT).param("estado", "BORRADOR"))
                .andExpect(jsonPath("$._embedded.noticias.length()").value(1));
        mockMvc.perform(get("/api/noticias").header("X-Rut-Usuario", RUT).param("titulo", "VERANO"))
                .andExpect(jsonPath("$._embedded.noticias.length()").value(1));
    }

    @Test
    void adminListForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("GESTIONAR_NOTICIAS"));

        mockMvc.perform(get("/api/noticias").header("X-Rut-Usuario", RUT))
                .andExpect(status().isForbidden());
    }

    @Test
    void findByIdAndNotFound() throws Exception {
        Noticia n = guardar("Oferta", EstadoNoticia.BORRADOR);

        mockMvc.perform(get("/api/noticias/" + n.getIdNoticia()).header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Oferta"));
        mockMvc.perform(get("/api/noticias/999999").header("X-Rut-Usuario", RUT))
                .andExpect(status().isNotFound());
    }

    @Test
    void updateNews() throws Exception {
        Noticia n = guardar("Viejo", EstadoNoticia.BORRADOR);

        mockMvc.perform(put("/api/noticias/" + n.getIdNoticia()).header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"titulo\":\"Nuevo\",\"contenido\":\"Texto\",\"categoria\":\"EVENTO\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.titulo").value("Nuevo"))
                .andExpect(jsonPath("$.categoria").value("EVENTO"));
    }

    @Test
    void activateAndDeactivate() throws Exception {
        Noticia n = guardar("Oferta", EstadoNoticia.BORRADOR);
        String base = "/api/noticias/" + n.getIdNoticia();

        mockMvc.perform(patch(base + "/activar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("ACTIVADA"));
        mockMvc.perform(patch(base + "/activar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch(base + "/desactivar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("DESACTIVADA"));
        mockMvc.perform(patch(base + "/desactivar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deleteNews() throws Exception {
        Noticia n = guardar("Oferta", EstadoNoticia.ACTIVADA);

        mockMvc.perform(delete("/api/noticias/" + n.getIdNoticia()).header("X-Rut-Usuario", RUT))
                .andExpect(status().isNoContent());
        mockMvc.perform(get("/api/noticias/" + n.getIdNoticia()).header("X-Rut-Usuario", RUT))
                .andExpect(status().isNotFound());
    }
}
