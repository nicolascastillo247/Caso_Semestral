package chibson.contenido.controller;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.model.InformacionInstitucional;
import chibson.contenido.service.InformacionInstitucionalService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(InformacionInstitucionalController.class)
@ActiveProfiles("test")
class InformacionInstitucionalControllerTest {
    private static final String RUT = "12345678-5";

    @MockitoBean
    private InformacionInstitucionalService service;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @Autowired
    private MockMvc mvc;

    private InformacionInstitucional info() {
        return new InformacionInstitucional(1L, "Misión", "Visión", "contacto@chibson.cl", "+56911111111", "Santiago");
    }

    @Test
    void getIsPublic() throws Exception {
        when(service.obtenerInformacion()).thenReturn(info());

        mvc.perform(get("/api/institucional"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.correo").value("contacto@chibson.cl"));
    }

    @Test
    void updateSaves() throws Exception {
        when(service.actualizarInformacion(any(InformacionInstitucional.class), eq(RUT))).thenReturn(info());

        mvc.perform(put("/api/institucional").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mision\":\"Misión\",\"correo\":\"contacto@chibson.cl\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mision").value("Misión"));
        verify(usuariosClient).exigirPermiso(RUT, "GESTIONAR_NOTICIAS");
    }

    @Test
    void updateForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(RUT, "GESTIONAR_NOTICIAS");

        mvc.perform(put("/api/institucional").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isForbidden());
    }
}
