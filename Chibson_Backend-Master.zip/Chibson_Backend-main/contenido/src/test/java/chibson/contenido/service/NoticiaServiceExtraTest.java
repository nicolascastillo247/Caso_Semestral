package chibson.contenido.service;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.dto.DetalleCambioDTO;
import chibson.contenido.dto.NoticiaDTO;
import chibson.contenido.dto.RegistroAccionDTO;
import chibson.contenido.model.CategoriaNoticia;
import chibson.contenido.model.EstadoNoticia;
import chibson.contenido.model.Noticia;
import chibson.contenido.repository.NoticiaRepository;
import chibson.contenido.service.NoticiaService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NoticiaServiceExtraTest {
    @Mock
    private NoticiaRepository repo;
    @Mock
    private UsuariosClient usuariosClient;
    @InjectMocks
    private NoticiaService service;

    private Noticia noticia(EstadoNoticia estado) {
        Noticia n = new Noticia();
        n.setIdNoticia(1L);
        n.setTitulo("Viejo");
        n.setContenido("Texto viejo");
        n.setCategoria(CategoriaNoticia.PROMOCION);
        n.setEstado(estado);
        return n;
    }

    private NoticiaDTO dto(String titulo, String contenido, CategoriaNoticia cat) {
        return new NoticiaDTO(titulo, contenido, "img.png", cat, null, false);
    }

    @Test
    void listPublished() {
        List<Noticia> lista = List.of(noticia(EstadoNoticia.ACTIVADA));
        when(repo.findByEstadoOrderByFechaPublicacionDescIdNoticiaDesc(EstadoNoticia.ACTIVADA)).thenReturn(lista);

        assertSame(lista, service.listarPublicadas());
    }

    @Test
    void getPublished() {
        Noticia n = noticia(EstadoNoticia.ACTIVADA);
        when(repo.findByIdNoticiaAndEstado(1L, EstadoNoticia.ACTIVADA)).thenReturn(Optional.of(n));

        assertSame(n, service.obtenerPublicada(1L));
    }

    @Test
    void findByIdNotFound() {
        when(repo.findById(5L)).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> service.findById(5L));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void editChanges() {
        Noticia n = noticia(EstadoNoticia.BORRADOR);
        when(repo.findById(1L)).thenReturn(Optional.of(n));
        when(repo.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));
        NoticiaDTO d = dto(" Nuevo ", " Texto nuevo ", CategoriaNoticia.EVENTO);
        d.setFechaPublicacion(LocalDate.of(2026, 1, 5));

        Noticia res = service.editarNoticia(1L, d, "12345678-5");

        assertEquals("Nuevo", res.getTitulo());
        assertEquals(LocalDate.of(2026, 1, 5), res.getFechaPublicacion());
        ArgumentCaptor<RegistroAccionDTO> cap = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(cap.capture());
        assertEquals("MODIFICAR", cap.getValue().getTipo());
        assertEquals(5, cap.getValue().getCambios().size());
    }

    @Test
    void editNoChanges() {
        Noticia n = noticia(EstadoNoticia.BORRADOR);
        n.setImagenUrl("img.png");
        when(repo.findById(1L)).thenReturn(Optional.of(n));
        when(repo.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));

        service.editarNoticia(1L, dto("Viejo", "Texto viejo", CategoriaNoticia.PROMOCION), "12345678-5");

        ArgumentCaptor<RegistroAccionDTO> cap = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(cap.capture());
        assertTrue(cap.getValue().getCambios().isEmpty());
    }

    @Test
    void editRemovesImage() {
        Noticia n = noticia(EstadoNoticia.BORRADOR);
        n.setImagenUrl("old.png");
        when(repo.findById(1L)).thenReturn(Optional.of(n));
        when(repo.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));
        NoticiaDTO d = dto("Viejo", "Texto viejo", CategoriaNoticia.PROMOCION);
        d.setImagenUrl("  ");

        Noticia res = service.editarNoticia(1L, d, "12345678-5");

        assertNull(res.getImagenUrl());
    }

    @Test
    void createNoContent() {
        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> service.crearNoticia(dto("Titulo", " ", CategoriaNoticia.PROMOCION), "1-9"));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void createNullTitle() {
        assertThrows(ResponseStatusException.class,
                () -> service.crearNoticia(dto(null, "Texto", CategoriaNoticia.PROMOCION), "1-9"));
    }

    @Test
    void createNullContent() {
        assertThrows(ResponseStatusException.class,
                () -> service.crearNoticia(dto("Titulo", null, CategoriaNoticia.PROMOCION), "1-9"));
    }

    @Test
    void createPublishedWithDate() {
        when(repo.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));
        NoticiaDTO d = new NoticiaDTO("Titulo", "Texto", null, CategoriaNoticia.EVENTO,
                LocalDate.of(2026, 3, 1), true);

        Noticia res = service.crearNoticia(d, "1-9");

        assertEquals(EstadoNoticia.ACTIVADA, res.getEstado());
        assertEquals(LocalDate.of(2026, 3, 1), res.getFechaPublicacion());
    }

    @Test
    void createDraftWithDate() {
        when(repo.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));
        NoticiaDTO d = new NoticiaDTO("Titulo", "Texto", null, CategoriaNoticia.EVENTO,
                LocalDate.of(2026, 3, 1), null);

        Noticia res = service.crearNoticia(d, "1-9");

        assertEquals(EstadoNoticia.BORRADOR, res.getEstado());
        assertEquals(LocalDate.of(2026, 3, 1), res.getFechaPublicacion());
    }

    @Test
    void activateKeepsDate() {
        Noticia n = noticia(EstadoNoticia.DESACTIVADA);
        n.setFechaPublicacion(LocalDate.of(2025, 1, 1));
        when(repo.findById(1L)).thenReturn(Optional.of(n));
        when(repo.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));

        Noticia res = service.activarNoticia(1L, "1-9");

        assertEquals(LocalDate.of(2025, 1, 1), res.getFechaPublicacion());
    }

    @Test
    void dtoDefaults() {
        RegistroAccionDTO vacio = new RegistroAccionDTO();
        assertTrue(vacio.getCambios().isEmpty());

        List<DetalleCambioDTO> cambios = new ArrayList<>();
        RegistroAccionDTO r = new RegistroAccionDTO("1-9", "CREAR", "Noticias", "desc", cambios);
        assertEquals("1-9", r.getRutAdministrador());
        assertEquals("CREAR", r.getTipo());
        assertEquals("Noticias", r.getModulo());
        assertEquals("desc", r.getDescripcion());
        assertEquals(r, new RegistroAccionDTO("1-9", "CREAR", "Noticias", "desc", cambios));
        assertTrue(r.toString().contains("CREAR"));
    }
}
