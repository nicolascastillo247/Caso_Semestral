package chibson.contenido.service;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.dto.NoticiaDTO;
import chibson.contenido.dto.RegistroAccionDTO;
import chibson.contenido.model.CategoriaNoticia;
import chibson.contenido.model.EstadoNoticia;
import chibson.contenido.model.Noticia;
import chibson.contenido.repository.NoticiaRepository;
import chibson.contenido.service.NoticiaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NoticiaServiceTest {
    @Mock
    private NoticiaRepository noticiaRepository;
    @Mock
    private UsuariosClient usuariosClient;
    @InjectMocks
    private NoticiaService noticiaService;

    private NoticiaDTO datos;

    @BeforeEach
    void setUp() {
        datos = new NoticiaDTO("  Nueva guitarra  ", "Llegó el stock", "", CategoriaNoticia.PROMOCION, null, false);
    }

    private Noticia noticia(Long id, EstadoNoticia estado) {
        Noticia n = new Noticia();
        n.setIdNoticia(id);
        n.setTitulo("Oferta de verano");
        n.setContenido("Contenido");
        n.setCategoria(CategoriaNoticia.PROMOCION);
        n.setEstado(estado);
        return n;
    }

    @Test
    void createDraft() {
        when(noticiaRepository.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));

        Noticia creada = noticiaService.crearNoticia(datos, "12345678-5");

        assertEquals(EstadoNoticia.BORRADOR, creada.getEstado());
        assertNull(creada.getFechaPublicacion());
        assertEquals("Nueva guitarra", creada.getTitulo());
        assertNull(creada.getImagenUrl());
    }

    @Test
    void createPublished() {
        datos.setPublicar(true);
        when(noticiaRepository.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));

        Noticia creada = noticiaService.crearNoticia(datos, "12345678-5");

        assertEquals(EstadoNoticia.ACTIVADA, creada.getEstado());
        assertEquals(LocalDate.now(), creada.getFechaPublicacion());
        ArgumentCaptor<RegistroAccionDTO> accion = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(accion.capture());
        assertEquals("CREAR", accion.getValue().getTipo());
    }

    @Test
    void createNoTitle() {
        datos.setTitulo("   ");

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> noticiaService.crearNoticia(datos, "12345678-5"));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
        verify(noticiaRepository, never()).save(any());
    }

    @Test
    void createLongTitle() {
        datos.setTitulo("a".repeat(151));

        assertThrows(ResponseStatusException.class, () -> noticiaService.crearNoticia(datos, "12345678-5"));
    }

    @Test
    void createNoCategory() {
        datos.setCategoria(null);

        assertThrows(ResponseStatusException.class, () -> noticiaService.crearNoticia(datos, "12345678-5"));
    }

    @Test
    void activateDraft() {
        Noticia borrador = noticia(1L, EstadoNoticia.BORRADOR);
        when(noticiaRepository.findById(1L)).thenReturn(Optional.of(borrador));
        when(noticiaRepository.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));

        Noticia activada = noticiaService.activarNoticia(1L, "12345678-5");

        assertEquals(EstadoNoticia.ACTIVADA, activada.getEstado());
        assertEquals(LocalDate.now(), activada.getFechaPublicacion());
    }

    @Test
    void activateTwice() {
        when(noticiaRepository.findById(1L)).thenReturn(Optional.of(noticia(1L, EstadoNoticia.ACTIVADA)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> noticiaService.activarNoticia(1L, "12345678-5"));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void deactivateInactive() {
        when(noticiaRepository.findById(2L)).thenReturn(Optional.of(noticia(2L, EstadoNoticia.BORRADOR)));

        assertThrows(ResponseStatusException.class, () -> noticiaService.desactivarNoticia(2L, "12345678-5"));
        verify(noticiaRepository, never()).save(any());
    }

    @Test
    void deactivate() {
        when(noticiaRepository.findById(3L)).thenReturn(Optional.of(noticia(3L, EstadoNoticia.ACTIVADA)));
        when(noticiaRepository.save(any(Noticia.class))).thenAnswer(i -> i.getArgument(0));

        Noticia resultado = noticiaService.desactivarNoticia(3L, "12345678-5");

        assertEquals(EstadoNoticia.DESACTIVADA, resultado.getEstado());
    }

    @Test
    void getPublishedNotFound() {
        when(noticiaRepository.findByIdNoticiaAndEstado(9L, EstadoNoticia.ACTIVADA)).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> noticiaService.obtenerPublicada(9L));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void listFilters() {
        Noticia a = noticia(1L, EstadoNoticia.ACTIVADA);
        Noticia b = noticia(2L, EstadoNoticia.BORRADOR);
        b.setTitulo("Evento de percusión");
        b.setCategoria(CategoriaNoticia.EVENTO);
        when(noticiaRepository.findAllByOrderByIdNoticiaDesc()).thenReturn(List.of(b, a));

        assertEquals(2, noticiaService.listarNoticias(null, null, null).size());
        assertEquals(1, noticiaService.listarNoticias(CategoriaNoticia.EVENTO, null, null).size());
        assertEquals(1, noticiaService.listarNoticias(null, EstadoNoticia.ACTIVADA, null).size());
        assertEquals(1, noticiaService.listarNoticias(null, null, "PERCUS").size());
        assertEquals(0, noticiaService.listarNoticias(CategoriaNoticia.EVENTO, EstadoNoticia.ACTIVADA, null).size());
    }

    @Test
    void delete() {
        Noticia existente = noticia(4L, EstadoNoticia.ACTIVADA);
        when(noticiaRepository.findById(4L)).thenReturn(Optional.of(existente));

        noticiaService.eliminarNoticia(4L, "12345678-5");

        verify(noticiaRepository).delete(existente);
        ArgumentCaptor<RegistroAccionDTO> accion = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(accion.capture());
        assertNotNull(accion.getValue());
        assertEquals("ELIMINAR", accion.getValue().getTipo());
    }
}
