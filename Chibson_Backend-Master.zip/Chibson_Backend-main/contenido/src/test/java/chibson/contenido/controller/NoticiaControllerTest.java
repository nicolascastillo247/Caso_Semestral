package chibson.contenido.controller;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.dto.NoticiaDTO;
import chibson.contenido.model.CategoriaNoticia;
import chibson.contenido.model.EstadoNoticia;
import chibson.contenido.model.Noticia;
import chibson.contenido.service.NoticiaService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NoticiaController.class)
@ActiveProfiles("test")
class NoticiaControllerTest {
    private static final String RUT = "12345678-5";
    private static final String CUERPO = "{\"titulo\":\"Oferta\",\"contenido\":\"Descuentos\",\"categoria\":\"PROMOCION\",\"publicar\":true}";

    @MockitoBean
    private NoticiaService noticiaService;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @Autowired
    private MockMvc mvc;

    private Noticia noticia(Long id) {
        Noticia n = new Noticia();
        n.setIdNoticia(id);
        n.setTitulo("Oferta");
        n.setContenido("Descuentos");
        n.setCategoria(CategoriaNoticia.PROMOCION);
        n.setEstado(EstadoNoticia.ACTIVADA);
        return n;
    }

    @Test
    void listPublished() throws Exception {
        when(noticiaService.listarPublicadas()).thenReturn(List.of(noticia(1L)));

        mvc.perform(get("/api/noticias/publicadas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.noticias[0].titulo").value("Oferta"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._embedded.noticias[0]._links.self.href").exists());
        verify(usuariosClient, never()).exigirPermiso(any(), any());
    }

    @Test
    void getPublished() throws Exception {
        when(noticiaService.obtenerPublicada(1L)).thenReturn(noticia(1L));

        mvc.perform(get("/api/noticias/publicadas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idNoticia").value(1))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.publicadas.href").exists());
    }

    @Test
    void getPublishedNotFound() throws Exception {
        when(noticiaService.obtenerPublicada(9L))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe"));

        mvc.perform(get("/api/noticias/publicadas/9")).andExpect(status().isNotFound());
    }

    @Test
    void listAdminFilters() throws Exception {
        when(noticiaService.listarNoticias(CategoriaNoticia.EVENTO, EstadoNoticia.BORRADOR, "feria"))
                .thenReturn(List.of(noticia(2L)));

        mvc.perform(get("/api/noticias").header("X-Rut-Usuario", RUT)
                        .param("categoria", "EVENTO").param("estado", "BORRADOR").param("titulo", "feria"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.noticias[0].idNoticia").value(2));
        verify(usuariosClient).exigirPermiso(RUT, "GESTIONAR_NOTICIAS");
    }

    @Test
    void listForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(RUT, "GESTIONAR_NOTICIAS");

        mvc.perform(get("/api/noticias").header("X-Rut-Usuario", RUT)).andExpect(status().isForbidden());
    }

    @Test
    void listUnauthorized() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Debe iniciar sesión"))
                .when(usuariosClient).exigirPermiso(null, "GESTIONAR_NOTICIAS");

        mvc.perform(get("/api/noticias")).andExpect(status().isUnauthorized());
    }

    @Test
    void findById() throws Exception {
        when(noticiaService.findById(3L)).thenReturn(noticia(3L));

        mvc.perform(get("/api/noticias/3").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idNoticia").value(3));
    }

    @Test
    void create201() throws Exception {
        when(noticiaService.crearNoticia(any(NoticiaDTO.class), eq(RUT))).thenReturn(noticia(4L));

        mvc.perform(post("/api/noticias").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idNoticia").value(4));
    }

    @Test
    void createInvalid400() throws Exception {
        when(noticiaService.crearNoticia(any(NoticiaDTO.class), eq(RUT)))
                .thenThrow(new ResponseStatusException(HttpStatus.BAD_REQUEST, "El título es obligatorio"));

        mvc.perform(post("/api/noticias").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void update() throws Exception {
        when(noticiaService.editarNoticia(eq(5L), any(NoticiaDTO.class), eq(RUT))).thenReturn(noticia(5L));

        mvc.perform(put("/api/noticias/5").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idNoticia").value(5));
    }

    @Test
    void activateDeactivate() throws Exception {
        when(noticiaService.activarNoticia(6L, RUT)).thenReturn(noticia(6L));
        when(noticiaService.desactivarNoticia(6L, RUT)).thenReturn(noticia(6L));

        mvc.perform(patch("/api/noticias/6/activar").header("X-Rut-Usuario", RUT)).andExpect(status().isOk());
        mvc.perform(patch("/api/noticias/6/desactivar").header("X-Rut-Usuario", RUT)).andExpect(status().isOk());
    }

    @Test
    void delete204() throws Exception {
        mvc.perform(delete("/api/noticias/7").header("X-Rut-Usuario", RUT)).andExpect(status().isNoContent());

        verify(noticiaService).eliminarNoticia(7L, RUT);
    }
}
