package chibson.contenido;

import chibson.contenido.repository.InformacionInstitucionalRepository;
import chibson.contenido.repository.NoticiaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LimpiezaBaseDatos {
    @Autowired
    private NoticiaRepository noticiaRepository;

    @Autowired
    private InformacionInstitucionalRepository informacionInstitucionalRepository;

    public void limpiar() {
        noticiaRepository.deleteAll();
        informacionInstitucionalRepository.deleteAll();
    }
}
