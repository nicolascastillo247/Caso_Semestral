package chibson.contenido.dto;

import chibson.contenido.model.CategoriaNoticia;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoticiaDTO {
    private String titulo;
    private String contenido;
    private String imagenUrl;
    private CategoriaNoticia categoria;

    private LocalDate fechaPublicacion;

    private Boolean publicar;
}
