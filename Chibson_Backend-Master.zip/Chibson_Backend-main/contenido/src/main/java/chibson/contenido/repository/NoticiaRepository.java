package chibson.contenido.repository;

import chibson.contenido.model.EstadoNoticia;
import chibson.contenido.model.Noticia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NoticiaRepository extends JpaRepository<Noticia, Long> {
    List<Noticia> findByEstadoOrderByFechaPublicacionDescIdNoticiaDesc(EstadoNoticia estado);

    Optional<Noticia> findByIdNoticiaAndEstado(Long idNoticia, EstadoNoticia estado);

    List<Noticia> findAllByOrderByIdNoticiaDesc();
}
