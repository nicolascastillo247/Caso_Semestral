package chibson.contenido.model;

public enum CategoriaNoticia {
    PROMOCION,
    EVENTO,
    ANUNCIO
}
