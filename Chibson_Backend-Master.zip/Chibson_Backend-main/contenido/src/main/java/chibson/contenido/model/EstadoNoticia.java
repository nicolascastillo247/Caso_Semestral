package chibson.contenido.model;

public enum EstadoNoticia {
    BORRADOR,
    ACTIVADA,
    DESACTIVADA
}
