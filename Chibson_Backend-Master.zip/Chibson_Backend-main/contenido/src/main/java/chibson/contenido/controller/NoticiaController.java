package chibson.contenido.controller;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.dto.NoticiaDTO;
import chibson.contenido.model.CategoriaNoticia;
import chibson.contenido.model.EstadoNoticia;
import chibson.contenido.model.Noticia;
import chibson.contenido.service.NoticiaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/noticias")
@Tag(name = "Noticias", description = "Noticias públicas y su administración")
public class NoticiaController {
    private static final String RUT = "X-Rut-Usuario";

    private static final String PERMISO = "GESTIONAR_NOTICIAS";

    private final NoticiaService noticiaService;
    private final UsuariosClient usuariosClient;

    public NoticiaController(NoticiaService noticiaService, UsuariosClient usuariosClient) {
        this.noticiaService = noticiaService;
        this.usuariosClient = usuariosClient;
    }

    @GetMapping("/publicadas")
    @Operation(summary = "Lista las noticias publicadas")
    public CollectionModel<EntityModel<Noticia>> listarPublicadas() {
        return coleccion(noticiaService.listarPublicadas(),
                linkTo(NoticiaController.class).slash("publicadas").withSelfRel());
    }

    @GetMapping("/publicadas/{id}")
    @Operation(summary = "Detalle de una noticia publicada")
    public EntityModel<Noticia> obtenerPublicada(@PathVariable Long id) {
        return modelo(noticiaService.obtenerPublicada(id));
    }

    @GetMapping
    @Operation(summary = "Lista todas las noticias con filtros (administración)")
    public CollectionModel<EntityModel<Noticia>> listarNoticias(@RequestHeader(value = RUT, required = false) String rut,
                                                                @RequestParam(required = false) CategoriaNoticia categoria,
                                                                @RequestParam(required = false) EstadoNoticia estado,
                                                                @RequestParam(required = false) String titulo) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return coleccion(noticiaService.listarNoticias(categoria, estado, titulo),
                linkTo(NoticiaController.class).withSelfRel());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca una noticia por id (administración)")
    public EntityModel<Noticia> findById(@RequestHeader(value = RUT, required = false) String rut, @PathVariable Long id) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(noticiaService.findById(id));
    }

    @PostMapping
    @Operation(summary = "Crea una noticia como publicada o borrador")
    public ResponseEntity<EntityModel<Noticia>> crearNoticia(@RequestHeader(value = RUT, required = false) String rut,
                                                             @RequestBody NoticiaDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(noticiaService.crearNoticia(datos, rut)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Edita una noticia")
    public EntityModel<Noticia> editarNoticia(@RequestHeader(value = RUT, required = false) String rut,
                                              @PathVariable Long id, @RequestBody NoticiaDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(noticiaService.editarNoticia(id, datos, rut));
    }

    @PatchMapping("/{id}/activar")
    @Operation(summary = "Publica una noticia")
    public EntityModel<Noticia> activarNoticia(@RequestHeader(value = RUT, required = false) String rut,
                                               @PathVariable Long id) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(noticiaService.activarNoticia(id, rut));
    }

    @PatchMapping("/{id}/desactivar")
    @Operation(summary = "Oculta una noticia")
    public EntityModel<Noticia> desactivarNoticia(@RequestHeader(value = RUT, required = false) String rut,
                                                  @PathVariable Long id) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(noticiaService.desactivarNoticia(id, rut));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Elimina una noticia")
    public ResponseEntity<Void> eliminarNoticia(@RequestHeader(value = RUT, required = false) String rut,
                                                @PathVariable Long id) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        noticiaService.eliminarNoticia(id, rut);
        return ResponseEntity.noContent().build();
    }

    private EntityModel<Noticia> modelo(Noticia noticia) {
        return EntityModel.of(noticia,
                linkTo(NoticiaController.class).slash(noticia.getIdNoticia()).withSelfRel(),
                linkTo(NoticiaController.class).slash("publicadas").withRel("publicadas"));
    }

    private CollectionModel<EntityModel<Noticia>> coleccion(List<Noticia> noticias, Link self) {
        return CollectionModel.of(noticias.stream().map(this::modelo).toList(), self);
    }
}
