package chibson.contenido.controller;

import chibson.contenido.client.UsuariosClient;
import chibson.contenido.model.InformacionInstitucional;
import chibson.contenido.service.InformacionInstitucionalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/institucional")
@Tag(name = "Información institucional", description = "Contenido de la página Nosotros")
public class InformacionInstitucionalController {
    private final InformacionInstitucionalService service;
    private final UsuariosClient usuariosClient;

    public InformacionInstitucionalController(InformacionInstitucionalService service, UsuariosClient usuariosClient) {
        this.service = service;
        this.usuariosClient = usuariosClient;
    }

    @GetMapping
    @Operation(summary = "Obtiene la información institucional")
    public EntityModel<InformacionInstitucional> obtenerInformacion() {
        return modelo(service.obtenerInformacion());
    }

    @PutMapping
    @Operation(summary = "Crea o actualiza la información institucional")
    public EntityModel<InformacionInstitucional> actualizarInformacion(
            @RequestHeader(value = "X-Rut-Usuario", required = false) String rut,
            @RequestBody InformacionInstitucional datos) {
        usuariosClient.exigirPermiso(rut, "GESTIONAR_NOTICIAS");
        return modelo(service.actualizarInformacion(datos, rut));
    }

    private EntityModel<InformacionInstitucional> modelo(InformacionInstitucional info) {
        return EntityModel.of(info,
                linkTo(InformacionInstitucionalController.class).withSelfRel(),
                linkTo(NoticiaController.class).slash("publicadas").withRel("noticias"));
    }
}
