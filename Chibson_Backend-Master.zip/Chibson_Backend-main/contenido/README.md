# ms-contenido

Noticias (publicadas y borradores) e información institucional de la página Nosotros.

- **Puerto:** 8085
- **Base de datos:** `chibson_contenido` en MySQL (se crea sola al arrancar)
- **Swagger:** http://localhost:8085/swagger-ui.html
- **Llama a:** ms-usuarios (permisos e historial).
- **Lo usan:** Solo el frontend.

## Ejecutar

```
.\mvnw spring-boot:run
```

O todo el backend junto con `iniciar-todo.ps1` desde la carpeta raíz.

## Pruebas

```
.\mvnw clean test
```

El informe de cobertura queda en `target/site/jacoco/index.html`.

Las pruebas no usan MySQL: los `*ControllerIT` levantan la aplicación completa con H2 en memoria (perfil `test`) y limpian las tablas antes de cada prueba con `LimpiezaBaseDatos`. Los servicios externos se reemplazan con `@MockitoBean`.

| Tipo | Clases | Qué prueba |
|---|---|---|
| Servicio | `service/*Test` | Reglas de negocio con Mockito, sin Spring. |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest`: rutas, códigos HTTP, JSON y enlaces HATEOAS con el servicio simulado. |
| Integración | `controller/*ControllerIT` | `@SpringBootTest` + MockMvc + H2: flujo completo hasta la base de datos. |

## Endpoints

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| GET | `/api/institucional` | Obtiene la información institucional | No |
| PUT | `/api/institucional` | Crea o actualiza la información institucional | Sí |
| GET | `/api/noticias/publicadas` | Lista las noticias publicadas | No |
| GET | `/api/noticias/publicadas/{id}` | Detalle de una noticia publicada | No |
| GET | `/api/noticias` | Lista todas las noticias con filtros (administración) | Sí |
| GET | `/api/noticias/{id}` | Busca una noticia por id (administración) | Sí |
| POST | `/api/noticias` | Crea una noticia como publicada o borrador | Sí |
| PUT | `/api/noticias/{id}` | Edita una noticia | Sí |
| PATCH | `/api/noticias/{id}/activar` | Publica una noticia | Sí |
| PATCH | `/api/noticias/{id}/desactivar` | Oculta una noticia | Sí |
| DELETE | `/api/noticias/{id}` | Elimina una noticia | Sí |

Las respuestas de un recurso traen `_links` (HATEOAS). Las listas vienen dentro de `_embedded`. Los endpoints de uso interno (contar, existe, verificar, datos, stock, resumen) responden JSON simple porque los consumen otros microservicios.

Colección de Postman: `chibson-contenido.postman_collection.json` (en esta carpeta).
