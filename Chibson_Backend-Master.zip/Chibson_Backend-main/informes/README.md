# ms-informes

Reportes de ventas, productos, soporte y resumen general. No tiene base de datos: arma los reportes con datos que pide a los otros servicios y los guarda en memoria.

- **Puerto:** 8086
- **Base de datos:** ninguna
- **Swagger:** http://localhost:8086/swagger-ui.html
- **Llama a:** ms-ventas, ms-productos, ms-soporte y ms-usuarios.
- **Lo usan:** Solo el frontend.

## Ejecutar

```
.\mvnw spring-boot:run
```

O todo el backend junto con `iniciar-todo.ps1` desde la carpeta raíz.

## Pruebas

```
.\mvnw clean test
```

El informe de cobertura queda en `target/site/jacoco/index.html`.

| Tipo | Clases | Qué prueba |
|---|---|---|
| Servicio | `service/*Test` | Reglas de negocio con Mockito, sin Spring. |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest`: rutas, códigos HTTP, JSON y enlaces HATEOAS con el servicio simulado. |

## Endpoints

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/reportes` | Genera un reporte manual | Sí |
| GET | `/api/reportes` | Lista los reportes con filtros por tipo, origen y fechas | Sí |
| GET | `/api/reportes/{id}` | Detalle de un reporte | Sí |
| DELETE | `/api/reportes/{id}` | Elimina un reporte | Sí |

Las respuestas de un recurso traen `_links` (HATEOAS). Las listas vienen dentro de `_embedded`. Los endpoints de uso interno (contar, existe, verificar, datos, stock, resumen) responden JSON simple porque los consumen otros microservicios.

Colección de Postman: `chibson-informes.postman_collection.json` (en esta carpeta).
