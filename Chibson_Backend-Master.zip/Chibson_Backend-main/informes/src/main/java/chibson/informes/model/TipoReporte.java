package chibson.informes.model;

public enum TipoReporte {
    VENTAS_POR_PERIODO,
    ESTADO_PEDIDOS,
    PRODUCTOS_MAS_VENDIDOS,
    RESUMEN_GENERAL
}
