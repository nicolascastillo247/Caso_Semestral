package chibson.informes.service;

public final class Permisos {
    public static final String VER_INFORMES = "VER_INFORMES";

    private Permisos() {
    }
}
