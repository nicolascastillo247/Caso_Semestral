package chibson.informes.repository;

import chibson.informes.model.OrigenReporte;
import chibson.informes.model.Periodo;
import chibson.informes.model.Reporte;
import chibson.informes.model.TipoReporte;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class ReporteRepository {
    private final Map<Long, Reporte> reportes = new ConcurrentHashMap<>();
    private final AtomicLong secuencia = new AtomicLong();

    public Reporte save(Reporte reporte) {
        if (reporte.getIdReporte() == null) {
            reporte.setIdReporte(secuencia.incrementAndGet());
        }
        reportes.put(reporte.getIdReporte(), reporte);
        return reporte;
    }

    public Optional<Reporte> findById(Long id) {
        return Optional.ofNullable(reportes.get(id));
    }

    public List<Reporte> findAllByOrderByFechaCreacionDesc() {
        return reportes.values().stream()
                .sorted(Comparator.comparing(Reporte::getFechaCreacion).reversed())
                .toList();
    }

    public void delete(Reporte reporte) {
        reportes.remove(reporte.getIdReporte());
    }

    public boolean existsByTipoAndPeriodoAndOrigenAndFechaDesde(TipoReporte tipo, Periodo periodo,
                                                                OrigenReporte origen, LocalDate fechaDesde) {
        return reportes.values().stream().anyMatch(r -> r.getTipo() == tipo && r.getPeriodo() == periodo
                && r.getOrigen() == origen && fechaDesde.equals(r.getFechaDesde()));
    }
}
