package chibson.informes.model;

public enum Periodo {
    DIARIO,

    SEMANAL,

    MENSUAL,

    ANUAL,

    PERSONALIZADO
}
