package chibson.informes.dto;

import chibson.informes.model.Periodo;
import chibson.informes.model.TipoReporte;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenerarReporteDTO {
    private TipoReporte tipo;
    private Periodo periodo;
    private LocalDate desde;
    private LocalDate hasta;

    private String categoria;
}
