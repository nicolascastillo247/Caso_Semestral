package chibson.informes.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class Reporte {
    private Long idReporte;
    private TipoReporte tipo;
    private Periodo periodo;
    private LocalDate fechaDesde;
    private LocalDate fechaHasta;

    private String categoria;
    private OrigenReporte origen;

    private String rutAdministrador;
    private LocalDateTime fechaCreacion;

    private Integer totalVentas;

    private Long numeroPedidos;

    private Integer ticketPromedio;

    private String mensaje;
    private List<FilaReporte> filas = new ArrayList<>();

    public FilaReporte agregarFila(String seccion, String etiqueta, Long cantidad, Integer monto) {
        FilaReporte fila = new FilaReporte();
        fila.setOrden(filas.size() + 1);
        fila.setSeccion(seccion);
        fila.setEtiqueta(etiqueta);
        fila.setCantidad(cantidad);
        fila.setMonto(monto);
        fila.setReporte(this);
        filas.add(fila);
        return fila;
    }
}
