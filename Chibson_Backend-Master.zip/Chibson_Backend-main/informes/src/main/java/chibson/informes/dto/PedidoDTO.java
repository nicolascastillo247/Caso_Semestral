package chibson.informes.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
public class PedidoDTO {
    private Long numeroPedido;
    private LocalDateTime fecha;
    private String estado;
    private Integer total;
    private String region;
    private Boolean pagado;
    private List<ItemDTO> items;
    private List<ReembolsoDTO> reembolsos;

    public PedidoDTO() {
        this.items = new ArrayList<>();
        this.reembolsos = new ArrayList<>();
    }

    public boolean esVenta() {
        return Boolean.TRUE.equals(pagado) && !"CANCELADO".equals(estado);
    }
}
