package chibson.informes.model;

public enum OrigenReporte {
    MANUAL,
    AUTOMATICO
}
