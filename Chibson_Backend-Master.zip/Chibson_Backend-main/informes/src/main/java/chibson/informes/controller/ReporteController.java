package chibson.informes.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import chibson.informes.dto.GenerarReporteDTO;
import chibson.informes.dto.ReporteListadoDTO;
import chibson.informes.model.OrigenReporte;
import chibson.informes.model.Reporte;
import chibson.informes.model.TipoReporte;
import chibson.informes.service.ReporteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/reportes")
@Tag(name = "Reportes", description = "Generación y consulta de reportes")
public class ReporteController {
    private static final String RUT = "X-Rut-Usuario";

    private final ReporteService reporteService;

    public ReporteController(ReporteService reporteService) {
        this.reporteService = reporteService;
    }

    @PostMapping
    @Operation(summary = "Genera un reporte manual")
    public ResponseEntity<EntityModel<Reporte>> generar(@RequestHeader(value = RUT, required = false) String rut,
                                                        @RequestBody GenerarReporteDTO datos) {
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(reporteService.generarManual(rut, datos)));
    }

    @GetMapping
    @Operation(summary = "Lista los reportes con filtros por tipo, origen y fechas")
    public CollectionModel<EntityModel<ReporteListadoDTO>> listar(
            @RequestHeader(value = RUT, required = false) String rut,
            @RequestParam(required = false) TipoReporte tipo,
            @RequestParam(required = false) OrigenReporte origen,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return CollectionModel.of(reporteService.listar(rut, tipo, origen, desde, hasta).stream()
                        .map(r -> EntityModel.of(r,
                                linkTo(ReporteController.class).slash(r.getIdReporte()).withSelfRel()))
                        .toList(),
                linkTo(ReporteController.class).withSelfRel());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Detalle de un reporte")
    public EntityModel<Reporte> obtener(@RequestHeader(value = RUT, required = false) String rut,
                                        @PathVariable Long id) {
        return modelo(reporteService.obtener(rut, id));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Elimina un reporte")
    public ResponseEntity<Void> eliminar(@RequestHeader(value = RUT, required = false) String rut,
                                         @PathVariable Long id) {
        reporteService.eliminar(rut, id);
        return ResponseEntity.noContent().build();
    }

    private EntityModel<Reporte> modelo(Reporte reporte) {
        return EntityModel.of(reporte,
                linkTo(ReporteController.class).slash(reporte.getIdReporte()).withSelfRel(),
                linkTo(ReporteController.class).withRel("reportes"));
    }
}
