package chibson.informes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class InformesApplication {
	public static void main(String[] args) {
		SpringApplication.run(InformesApplication.class, args);
	}
}
