package chibson.informes.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class FilaReporte {
    private Long idFila;
    private Integer orden;
    private String seccion;

    private String etiqueta;

    private String valor;

    private Long cantidad;

    private Integer monto;

    private String referencia;

    @JsonIgnore
    private Reporte reporte;
}
