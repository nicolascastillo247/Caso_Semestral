package chibson.informes.client;

import chibson.informes.client.ProductosClient;
import chibson.informes.client.SoporteClient;
import chibson.informes.client.UsuariosClient;
import chibson.informes.client.VentasClient;
import chibson.informes.dto.PedidoDTO;
import chibson.informes.dto.ProductoDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class InformesClientsTest {
    private static final String RUT = "12345678-5";

    @Mock
    private RestTemplate restTemplate;

    private ProductosClient productos;
    private SoporteClient soporte;
    private UsuariosClient usuarios;
    private VentasClient ventas;

    @BeforeEach
    void setUp() {
        productos = new ProductosClient(restTemplate, "http://localhost:8082");
        soporte = new SoporteClient(restTemplate, "http://localhost:8084");
        usuarios = new UsuariosClient(restTemplate, "http://localhost:8081");
        ventas = new VentasClient(restTemplate, "http://localhost:8083");
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    @Test
    void lowStock() {
        when(restTemplate.getForObject(anyString(), eq(ProductoDTO[].class)))
                .thenReturn(new ProductoDTO[]{new ProductoDTO("GTR-0001", "Strato", "GUITARRA", 1, 3)});

        assertEquals(1, productos.obtenerStockBajo().size());
    }

    @Test
    void lowStockNull() {
        when(restTemplate.getForObject(anyString(), eq(ProductoDTO[].class))).thenReturn(null);

        assertTrue(productos.obtenerStockBajo().isEmpty());
    }

    @Test
    void lowStockDown503() {
        when(restTemplate.getForObject(anyString(), eq(ProductoDTO[].class))).thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> productos.obtenerStockBajo())));
    }

    @Test
    void openTickets() {
        when(restTemplate.getForObject(anyString(), eq(Long.class))).thenReturn(4L);

        assertEquals(4L, soporte.contarTicketsAbiertos());
    }

    @Test
    void supportDown() {
        when(restTemplate.getForObject(anyString(), eq(Long.class))).thenThrow(new ResourceAccessException("caído"));

        assertNull(soporte.contarTicketsAbiertos());
    }

    @Test
    void permissionNoRut401() {
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(" ", "VER_INFORMES"))));
        assertThrows(ResponseStatusException.class, () -> usuarios.exigirPermiso(null, "VER_INFORMES"));
    }

    @Test
    void permissionCases() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("OK"))).thenReturn(true);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("NO"))).thenReturn(false);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("CAIDO")))
                .thenThrow(new ResourceAccessException("caído"));

        assertDoesNotThrow(() -> usuarios.exigirPermiso(" " + RUT + " ", "OK"));
        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(RUT, "NO"))));
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(RUT, "CAIDO"))));
    }

    @Test
    void newClients() {
        when(restTemplate.getForObject(anyString(), eq(Long.class), eq("2026-02-01"), eq("2026-02-28"))).thenReturn(9L);

        assertEquals(9L, usuarios.contarClientesRegistrados(LocalDate.of(2026, 2, 1), LocalDate.of(2026, 2, 28)));
    }

    @Test
    void newClientsDown() {
        when(restTemplate.getForObject(anyString(), eq(Long.class), eq("2026-02-01"), eq("2026-02-28")))
                .thenThrow(new ResourceAccessException("caído"));

        assertNull(usuarios.contarClientesRegistrados(LocalDate.of(2026, 2, 1), LocalDate.of(2026, 2, 28)));
    }

    @Test
    void ordersWithDates() {
        when(restTemplate.getForObject(anyString(), eq(PedidoDTO[].class), eq("2026-02-01"), eq("2026-02-28")))
                .thenReturn(new PedidoDTO[]{new PedidoDTO()});

        assertEquals(1, ventas.obtenerPedidos(LocalDate.of(2026, 2, 1), LocalDate.of(2026, 2, 28)).size());
    }

    @Test
    void ordersNoDates() {
        when(restTemplate.getForObject(anyString(), eq(PedidoDTO[].class), eq(""), eq(""))).thenReturn(null);

        assertTrue(ventas.obtenerPedidos(null, null).isEmpty());
    }

    @Test
    void salesDown503() {
        when(restTemplate.getForObject(anyString(), eq(PedidoDTO[].class), eq(""), eq("")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> ventas.obtenerPedidos(null, null))));
    }

    @Test
    void pendingReturns() {
        when(restTemplate.getForObject(anyString(), eq(Long.class))).thenReturn(2L);

        assertEquals(2L, ventas.contarDevolucionesPendientes());
    }

    @Test
    void pendingReturnsDown() {
        when(restTemplate.getForObject(anyString(), eq(Long.class))).thenThrow(new ResourceAccessException("caído"));

        assertNull(ventas.contarDevolucionesPendientes());
    }
}
