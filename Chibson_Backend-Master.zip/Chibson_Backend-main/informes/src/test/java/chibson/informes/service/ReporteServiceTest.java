package chibson.informes.service;

import chibson.informes.client.UsuariosClient;
import chibson.informes.dto.GenerarReporteDTO;
import chibson.informes.model.OrigenReporte;
import chibson.informes.model.Periodo;
import chibson.informes.model.Reporte;
import chibson.informes.model.TipoReporte;
import chibson.informes.repository.ReporteRepository;
import chibson.informes.service.GeneradorReportes;
import chibson.informes.service.Permisos;
import chibson.informes.service.ReporteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.YearMonth;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ReporteServiceTest {
    private static final String ADMIN = "12345678-5";

    @Mock
    private GeneradorReportes generador;
    @Mock
    private UsuariosClient usuariosClient;

    private ReporteRepository repositorio;
    private ReporteService servicio;

    @BeforeEach
    void setUp() {
        repositorio = new ReporteRepository();
        servicio = new ReporteService(repositorio, generador, usuariosClient);
    }

    private GenerarReporteDTO datos(TipoReporte tipo, Periodo periodo, LocalDate desde, LocalDate hasta, String categoria) {
        return new GenerarReporteDTO(tipo, periodo, desde, hasta, categoria);
    }

    @Test
    void manualMonthly() {
        Reporte r = servicio.generarManual(ADMIN,
                datos(TipoReporte.VENTAS_POR_PERIODO, Periodo.MENSUAL, LocalDate.of(2026, 10, 15), null, null));

        assertEquals(LocalDate.of(2026, 10, 1), r.getFechaDesde());
        assertEquals(LocalDate.of(2026, 10, 31), r.getFechaHasta());
        assertEquals(OrigenReporte.MANUAL, r.getOrigen());
        assertEquals(ADMIN, r.getRutAdministrador());
        assertNotNull(r.getIdReporte());
        verify(generador).ventasPorPeriodo(r);
    }

    @Test
    void manualWeekly() {
        Reporte r = servicio.generarManual(ADMIN,
                datos(TipoReporte.ESTADO_PEDIDOS, Periodo.SEMANAL, LocalDate.of(2026, 10, 15), null, null));

        assertEquals(LocalDate.of(2026, 10, 12), r.getFechaDesde());
        assertEquals(LocalDate.of(2026, 10, 18), r.getFechaHasta());
        verify(generador).estadoPedidos(r);
    }

    @Test
    void manualYearlyDaily() {
        Reporte anual = servicio.generarManual(ADMIN,
                datos(TipoReporte.VENTAS_POR_PERIODO, Periodo.ANUAL, LocalDate.of(2026, 6, 1), null, null));
        Reporte diario = servicio.generarManual(ADMIN,
                datos(TipoReporte.VENTAS_POR_PERIODO, Periodo.DIARIO, LocalDate.of(2026, 6, 1), null, null));

        assertEquals(LocalDate.of(2026, 1, 1), anual.getFechaDesde());
        assertEquals(LocalDate.of(2026, 12, 31), anual.getFechaHasta());
        assertEquals(diario.getFechaDesde(), diario.getFechaHasta());
    }

    @Test
    void topProductsCategory() {
        Reporte r = servicio.generarManual(ADMIN, datos(TipoReporte.PRODUCTOS_MAS_VENDIDOS, Periodo.MENSUAL,
                LocalDate.of(2026, 10, 1), null, " guitarra "));

        assertEquals("GUITARRA", r.getCategoria());
        verify(generador).productosMasVendidos(r);
    }

    @Test
    void customRange() {
        assertThrows(ResponseStatusException.class, () -> servicio.generarManual(ADMIN,
                datos(TipoReporte.VENTAS_POR_PERIODO, Periodo.PERSONALIZADO, LocalDate.of(2026, 10, 1), null, null)));
        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> servicio.generarManual(ADMIN,
                datos(TipoReporte.VENTAS_POR_PERIODO, Periodo.PERSONALIZADO,
                        LocalDate.of(2026, 10, 20), LocalDate.of(2026, 10, 1), null)));
        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void summaryNotManual() {
        assertThrows(ResponseStatusException.class, () -> servicio.generarManual(ADMIN,
                datos(TipoReporte.RESUMEN_GENERAL, Periodo.MENSUAL, null, null, null)));
    }

    @Test
    void missingTypeOrPeriod() {
        assertThrows(ResponseStatusException.class,
                () -> servicio.generarManual(ADMIN, datos(null, Periodo.MENSUAL, null, null, null)));
        assertThrows(ResponseStatusException.class,
                () -> servicio.generarManual(ADMIN, datos(TipoReporte.ESTADO_PEDIDOS, null, null, null, null)));
    }

    @Test
    void noPermission() {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso"))
                .when(usuariosClient).exigirPermiso(ADMIN, Permisos.VER_INFORMES);

        assertThrows(ResponseStatusException.class, () -> servicio.generarManual(ADMIN,
                datos(TipoReporte.ESTADO_PEDIDOS, Periodo.MENSUAL, null, null, null)));
        verify(generador, never()).estadoPedidos(any());
        assertEquals(0, repositorio.findAllByOrderByFechaCreacionDesc().size());
    }

    @Test
    void weeklyNoDuplicate() {
        LocalDate lunes = LocalDate.of(2026, 10, 12);

        Reporte primero = servicio.generarResumenSemanal(lunes);
        Reporte segundo = servicio.generarResumenSemanal(lunes);

        assertNotNull(primero);
        assertNull(segundo);
        assertEquals(OrigenReporte.AUTOMATICO, primero.getOrigen());
        assertEquals(lunes.plusDays(6), primero.getFechaHasta());
        assertEquals(1, repositorio.findAllByOrderByFechaCreacionDesc().size());
    }

    @Test
    void monthlyNoDuplicate() {
        Reporte primero = servicio.generarResumenMensual(YearMonth.of(2026, 9));
        Reporte segundo = servicio.generarResumenMensual(YearMonth.of(2026, 9));

        assertEquals(LocalDate.of(2026, 9, 1), primero.getFechaDesde());
        assertEquals(LocalDate.of(2026, 9, 30), primero.getFechaHasta());
        assertNull(segundo);
        verify(generador).resumenGeneral(primero, LocalDate.of(2026, 8, 1), LocalDate.of(2026, 8, 31));
    }

    @Test
    void getAndDelete() {
        Reporte r = servicio.generarManual(ADMIN,
                datos(TipoReporte.ESTADO_PEDIDOS, Periodo.MENSUAL, LocalDate.of(2026, 10, 1), null, null));

        assertEquals(r.getIdReporte(), servicio.obtener(ADMIN, r.getIdReporte()).getIdReporte());
        servicio.eliminar(ADMIN, r.getIdReporte());

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> servicio.obtener(ADMIN, r.getIdReporte()));
        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void listFilters() {
        servicio.generarManual(ADMIN, datos(TipoReporte.ESTADO_PEDIDOS, Periodo.MENSUAL, LocalDate.of(2026, 10, 1), null, null));
        servicio.generarManual(ADMIN, datos(TipoReporte.VENTAS_POR_PERIODO, Periodo.MENSUAL, LocalDate.of(2026, 10, 1), null, null));
        servicio.generarResumenSemanal(LocalDate.of(2026, 10, 12));

        assertEquals(3, servicio.listar(ADMIN, null, null, null, null).size());
        assertEquals(1, servicio.listar(ADMIN, TipoReporte.ESTADO_PEDIDOS, null, null, null).size());
        assertEquals(2, servicio.listar(ADMIN, null, OrigenReporte.MANUAL, null, null).size());
        assertThrows(ResponseStatusException.class, () -> servicio.listar(ADMIN, null, null,
                LocalDate.of(2026, 10, 20), LocalDate.of(2026, 10, 1)));
    }
}
