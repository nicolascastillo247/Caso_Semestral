package chibson.informes.service;

import chibson.informes.dto.PedidoDTO;
import chibson.informes.dto.ReembolsoDTO;
import chibson.informes.service.Calculos;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CalculosTest {
    private PedidoDTO pedido(long numero, LocalDateTime fecha, String estado, int total, boolean pagado,
                             List<ReembolsoDTO> reembolsos) {
        return new PedidoDTO(numero, fecha, estado, total, "Metropolitana", pagado, List.of(), reembolsos);
    }

    @Test
    void onlyPaidSales() {
        LocalDateTime hoy = LocalDateTime.of(2026, 10, 10, 12, 0);
        PedidoDTO pagado = pedido(1, hoy, "PAGADO", 1000, true, List.of());
        PedidoDTO cancelado = pedido(2, hoy, "CANCELADO", 2000, true, List.of());
        PedidoDTO pendiente = pedido(3, hoy, "PENDIENTE", 3000, false, List.of());

        List<PedidoDTO> ventas = Calculos.ventasEntre(List.of(pagado, cancelado, pendiente),
                LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31));

        assertEquals(List.of(pagado), ventas);
    }

    @Test
    void rangeIncludesEnds() {
        LocalDate desde = LocalDate.of(2026, 10, 1);
        LocalDate hasta = LocalDate.of(2026, 10, 31);

        assertTrue(Calculos.entre(LocalDateTime.of(2026, 10, 1, 0, 0), desde, hasta));
        assertTrue(Calculos.entre(LocalDateTime.of(2026, 10, 31, 23, 59), desde, hasta));
        assertFalse(Calculos.entre(LocalDateTime.of(2026, 9, 30, 23, 59), desde, hasta));
        assertFalse(Calculos.entre(LocalDateTime.of(2026, 11, 1, 0, 0), desde, hasta));
    }

    @Test
    void noLimits() {
        assertTrue(Calculos.entre(LocalDateTime.of(2020, 1, 1, 0, 0), null, null));
    }

    @Test
    void netTotal() {
        LocalDateTime fecha = LocalDateTime.of(2026, 10, 10, 12, 0);
        List<PedidoDTO> ventas = List.of(
                pedido(1, fecha, "ENTREGADO", 10000, true, List.of()),
                pedido(2, fecha, "PAGADO", 5000, true, List.of()));
        List<ReembolsoDTO> reembolsos = List.of(new ReembolsoDTO(fecha, "GTR-0001", 1, 3000));

        assertEquals(15000, Calculos.sumarTotales(ventas));
        assertEquals(3000, Calculos.sumarReembolsos(reembolsos));
        assertEquals(1, Calculos.unidadesReembolsadas(reembolsos));
        assertEquals(12000, Calculos.totalNeto(ventas, reembolsos));
    }

    @Test
    void refundsByDate() {
        LocalDateTime dentro = LocalDateTime.of(2026, 10, 10, 12, 0);
        LocalDateTime fuera = LocalDateTime.of(2026, 8, 10, 12, 0);
        PedidoDTO p = pedido(1, fuera, "ENTREGADO", 10000, true, List.of(
                new ReembolsoDTO(dentro, "GTR-0001", 1, 2000),
                new ReembolsoDTO(fuera, "GTR-0001", 1, 4000),
                new ReembolsoDTO(null, "GTR-0001", 1, 9000)));

        List<ReembolsoDTO> lista = Calculos.reembolsosEntre(List.of(p), LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31));

        assertEquals(1, lista.size());
        assertEquals(2000, lista.get(0).getMonto());
    }

    @Test
    void averageTicket() {
        assertEquals(0, Calculos.ticketPromedio(1000, 0));
        assertEquals(3333, Calculos.ticketPromedio(10000, 3));
        assertEquals(3334, Calculos.ticketPromedio(10001, 3));
    }

    @Test
    void variation() {
        assertEquals(50.0, Calculos.variacion(150, 100));
        assertEquals(-25.0, Calculos.variacion(75, 100));
        assertEquals(33.3, Calculos.variacion(4, 3));
    }

    @Test
    void variationNull() {
        assertNull(Calculos.variacion(100, 0));
    }
}
