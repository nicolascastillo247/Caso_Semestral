package chibson.informes.controller;

import chibson.informes.dto.GenerarReporteDTO;
import chibson.informes.dto.ReporteListadoDTO;
import chibson.informes.model.OrigenReporte;
import chibson.informes.model.Periodo;
import chibson.informes.model.Reporte;
import chibson.informes.model.TipoReporte;
import chibson.informes.service.ReporteService;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ReporteController.class)
@ActiveProfiles("test")
class ReporteControllerTest {
    private static final String ADMIN = "12345678-5";

    @MockitoBean
    private ReporteService reporteService;

    @Autowired
    private MockMvc mvc;

    private Reporte reporte(Long id) {
        Reporte r = new Reporte();
        r.setIdReporte(id);
        r.setTipo(TipoReporte.VENTAS_POR_PERIODO);
        r.setTotalVentas(1000);
        r.agregarFila("TOTALES", "Ventas netas", 1L, 1000);
        return r;
    }

    @Test
    void generate201() throws Exception {
        when(reporteService.generarManual(eq(ADMIN), any(GenerarReporteDTO.class))).thenReturn(reporte(1L));

        mvc.perform(post("/api/reportes").header("X-Rut-Usuario", ADMIN).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tipo\":\"VENTAS_POR_PERIODO\",\"periodo\":\"MENSUAL\",\"desde\":\"2026-02-01\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idReporte").value(1))
                .andExpect(jsonPath("$.filas[0].etiqueta").value("Ventas netas"));
    }

    @Test
    void generateForbidden() throws Exception {
        when(reporteService.generarManual(eq(ADMIN), any(GenerarReporteDTO.class)))
                .thenThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"));

        mvc.perform(post("/api/reportes").header("X-Rut-Usuario", ADMIN).contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void listFilters() throws Exception {
        ReporteListadoDTO fila = new ReporteListadoDTO(2L, TipoReporte.RESUMEN_GENERAL, Periodo.SEMANAL,
                LocalDate.of(2026, 2, 2), LocalDate.of(2026, 2, 8), OrigenReporte.AUTOMATICO, null, null);
        when(reporteService.listar(ADMIN, TipoReporte.RESUMEN_GENERAL, OrigenReporte.AUTOMATICO,
                LocalDate.of(2026, 2, 1), LocalDate.of(2026, 2, 28))).thenReturn(List.of(fila));

        mvc.perform(get("/api/reportes").header("X-Rut-Usuario", ADMIN).param("tipo", "RESUMEN_GENERAL")
                        .param("origen", "AUTOMATICO").param("desde", "2026-02-01").param("hasta", "2026-02-28"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.reportes[0].idReporte").value(2))
                .andExpect(jsonPath("$._embedded.reportes[0].origen").value("AUTOMATICO"));
    }

    @Test
    void getAndDelete() throws Exception {
        when(reporteService.obtener(ADMIN, 3L)).thenReturn(reporte(3L));

        mvc.perform(get("/api/reportes/3").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idReporte").value(3))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.reportes.href").exists());
        mvc.perform(delete("/api/reportes/3").header("X-Rut-Usuario", ADMIN)).andExpect(status().isNoContent());

        verify(reporteService).eliminar(ADMIN, 3L);
    }

    @Test
    void notFound404() throws Exception {
        when(reporteService.obtener(ADMIN, 9L)).thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe"));

        mvc.perform(get("/api/reportes/9").header("X-Rut-Usuario", ADMIN)).andExpect(status().isNotFound());
    }
}
