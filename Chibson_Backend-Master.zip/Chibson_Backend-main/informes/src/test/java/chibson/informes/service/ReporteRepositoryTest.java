package chibson.informes.service;

import chibson.informes.model.OrigenReporte;
import chibson.informes.model.Periodo;
import chibson.informes.model.Reporte;
import chibson.informes.model.TipoReporte;
import chibson.informes.repository.ReporteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ReporteRepositoryTest {
    private ReporteRepository repositorio;

    @BeforeEach
    void setUp() {
        repositorio = new ReporteRepository();
    }

    private Reporte reporte(OrigenReporte origen, LocalDate desde, LocalDateTime creacion) {
        Reporte r = new Reporte();
        r.setTipo(TipoReporte.RESUMEN_GENERAL);
        r.setPeriodo(Periodo.SEMANAL);
        r.setOrigen(origen);
        r.setFechaDesde(desde);
        r.setFechaHasta(desde.plusDays(6));
        r.setFechaCreacion(creacion);
        return r;
    }

    @Test
    void saveAssignsIds() {
        Reporte a = repositorio.save(reporte(OrigenReporte.MANUAL, LocalDate.of(2026, 10, 5), LocalDateTime.now()));
        Reporte b = repositorio.save(reporte(OrigenReporte.MANUAL, LocalDate.of(2026, 10, 12), LocalDateTime.now()));

        assertEquals(1L, a.getIdReporte());
        assertEquals(2L, b.getIdReporte());
        assertNotEquals(a.getIdReporte(), b.getIdReporte());
    }

    @Test
    void saveExisting() {
        Reporte a = repositorio.save(reporte(OrigenReporte.MANUAL, LocalDate.of(2026, 10, 5), LocalDateTime.now()));
        repositorio.save(a);

        assertEquals(1, repositorio.findAllByOrderByFechaCreacionDesc().size());
    }

    @Test
    void newestFirst() {
        LocalDateTime ahora = LocalDateTime.now();
        Reporte viejo = repositorio.save(reporte(OrigenReporte.MANUAL, LocalDate.of(2026, 9, 1), ahora.minusDays(5)));
        Reporte nuevo = repositorio.save(reporte(OrigenReporte.MANUAL, LocalDate.of(2026, 10, 1), ahora));

        List<Reporte> lista = repositorio.findAllByOrderByFechaCreacionDesc();

        assertEquals(nuevo.getIdReporte(), lista.get(0).getIdReporte());
        assertEquals(viejo.getIdReporte(), lista.get(1).getIdReporte());
    }

    @Test
    void findAndDelete() {
        Reporte r = repositorio.save(reporte(OrigenReporte.MANUAL, LocalDate.of(2026, 10, 5), LocalDateTime.now()));

        assertTrue(repositorio.findById(r.getIdReporte()).isPresent());
        repositorio.delete(r);
        assertTrue(repositorio.findById(r.getIdReporte()).isEmpty());
    }

    @Test
    void detectsExistingAuto() {
        LocalDate lunes = LocalDate.of(2026, 10, 12);
        repositorio.save(reporte(OrigenReporte.AUTOMATICO, lunes, LocalDateTime.now()));

        assertTrue(repositorio.existsByTipoAndPeriodoAndOrigenAndFechaDesde(
                TipoReporte.RESUMEN_GENERAL, Periodo.SEMANAL, OrigenReporte.AUTOMATICO, lunes));
        assertFalse(repositorio.existsByTipoAndPeriodoAndOrigenAndFechaDesde(
                TipoReporte.RESUMEN_GENERAL, Periodo.SEMANAL, OrigenReporte.AUTOMATICO, lunes.plusWeeks(1)));
        assertFalse(repositorio.existsByTipoAndPeriodoAndOrigenAndFechaDesde(
                TipoReporte.RESUMEN_GENERAL, Periodo.SEMANAL, OrigenReporte.MANUAL, lunes));
    }
}
