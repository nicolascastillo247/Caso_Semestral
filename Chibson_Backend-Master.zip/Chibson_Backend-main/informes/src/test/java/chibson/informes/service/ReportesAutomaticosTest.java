package chibson.informes.service;

import chibson.informes.client.VentasClient;
import chibson.informes.dto.PedidoDTO;
import chibson.informes.model.Reporte;
import chibson.informes.service.ReporteService;
import chibson.informes.service.ReportesAutomaticos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ReportesAutomaticosTest {
    @Mock
    private ReporteService reporteService;
    @Mock
    private VentasClient ventasClient;

    private PedidoDTO pedidoHaceUnAnio() {
        PedidoDTO p = new PedidoDTO();
        p.setFecha(LocalDateTime.now().minusYears(1));
        return p;
    }

    @Test
    void runGeneratesPending() {
        when(ventasClient.obtenerPedidos(null, null)).thenReturn(List.of(pedidoHaceUnAnio()));
        when(reporteService.generarResumenSemanal(any(LocalDate.class))).thenReturn(new Reporte());
        when(reporteService.generarResumenMensual(any(YearMonth.class))).thenReturn(new Reporte());

        new ReportesAutomaticos(reporteService, ventasClient, true).run();

        verify(reporteService, atLeast(50)).generarResumenSemanal(any(LocalDate.class));
        verify(reporteService, atLeast(11)).generarResumenMensual(any(YearMonth.class));
    }

    @Test
    void runContinuesOnError() {
        when(ventasClient.obtenerPedidos(null, null)).thenReturn(List.of(pedidoHaceUnAnio()));
        when(reporteService.generarResumenSemanal(any(LocalDate.class))).thenThrow(new RuntimeException("falló"));
        when(reporteService.generarResumenMensual(any(YearMonth.class))).thenThrow(new RuntimeException("falló"));

        assertDoesNotThrow(() -> new ReportesAutomaticos(reporteService, ventasClient, true).run());

        verify(reporteService, atLeast(50)).generarResumenSemanal(any(LocalDate.class));
    }

    @Test
    void noOrders() {
        when(ventasClient.obtenerPedidos(null, null)).thenReturn(List.of());

        new ReportesAutomaticos(reporteService, ventasClient, true).run();

        verifyNoInteractions(reporteService);
    }

    @Test
    void salesDown() {
        when(ventasClient.obtenerPedidos(null, null))
                .thenThrow(new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "caído"));

        assertDoesNotThrow(() -> new ReportesAutomaticos(reporteService, ventasClient, true).run());

        verifyNoInteractions(reporteService);
    }

    @Test
    void disabled() {
        ReportesAutomaticos auto = new ReportesAutomaticos(reporteService, ventasClient, false);

        auto.run();
        auto.resumenSemanal();
        auto.resumenMensual();

        verifyNoInteractions(reporteService);
        verifyNoInteractions(ventasClient);
    }

    @Test
    void weeklyPrevWeek() {
        new ReportesAutomaticos(reporteService, ventasClient, true).resumenSemanal();

        verify(reporteService).generarResumenSemanal(LocalDate.now().with(DayOfWeek.MONDAY).minusWeeks(1));
        verify(reporteService, never()).generarResumenMensual(any());
    }

    @Test
    void monthlyPrevMonth() {
        new ReportesAutomaticos(reporteService, ventasClient, true).resumenMensual();

        verify(reporteService).generarResumenMensual(YearMonth.now().minusMonths(1));
    }
}
