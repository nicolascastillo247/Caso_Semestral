package chibson.informes.service;

import chibson.informes.client.ProductosClient;
import chibson.informes.client.SoporteClient;
import chibson.informes.client.UsuariosClient;
import chibson.informes.client.VentasClient;
import chibson.informes.dto.ItemDTO;
import chibson.informes.dto.PedidoDTO;
import chibson.informes.dto.ProductoDTO;
import chibson.informes.dto.ReembolsoDTO;
import chibson.informes.model.FilaReporte;
import chibson.informes.model.Reporte;
import chibson.informes.service.GeneradorReportes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GeneradorReportesTest {
    @Mock
    private VentasClient ventasClient;
    @Mock
    private ProductosClient productosClient;
    @Mock
    private UsuariosClient usuariosClient;
    @Mock
    private SoporteClient soporteClient;

    private GeneradorReportes generador;

    private static final LocalDate DESDE = LocalDate.of(2026, 2, 1);
    private static final LocalDate HASTA = LocalDate.of(2026, 2, 28);

    @BeforeEach
    void setUp() {
        generador = new GeneradorReportes(ventasClient, productosClient, usuariosClient, soporteClient);
    }

    private Reporte reporte(LocalDate desde, LocalDate hasta) {
        Reporte r = new Reporte();
        r.setFechaDesde(desde);
        r.setFechaHasta(hasta);
        return r;
    }

    private PedidoDTO pedido(long numero, LocalDate fecha, String estado, int total, String region, String sku,
                             String nombre, String categoria, int cantidad, int precio) {
        PedidoDTO p = new PedidoDTO();
        p.setNumeroPedido(numero);
        p.setFecha(fecha.atTime(10, 0));
        p.setEstado(estado);
        p.setTotal(total);
        p.setRegion(region);
        p.setPagado(true);
        p.getItems().add(new ItemDTO(sku, nombre, categoria, cantidad, precio));
        return p;
    }

    private PedidoDTO guitarra(long numero, LocalDate fecha) {
        return pedido(numero, fecha, "PAGADO", 100000, "Metropolitana", "GTR-0001", "Strato", "GUITARRA", 1, 100000);
    }

    private List<FilaReporte> filas(Reporte r, String seccion) {
        return r.getFilas().stream().filter(f -> seccion.equals(f.getSeccion())).toList();
    }

    private FilaReporte fila(Reporte r, String seccion, String etiqueta) {
        return filas(r, seccion).stream().filter(f -> etiqueta.equals(f.getEtiqueta())).findFirst().orElseThrow();
    }

    @Test
    void salesWithRefunds() {
        PedidoDTO p1 = guitarra(1, LocalDate.of(2026, 2, 10));
        p1.getReembolsos().add(new ReembolsoDTO(LocalDateTime.of(2026, 2, 12, 9, 0), "GTR-0001", 1, 40000));
        PedidoDTO p2 = guitarra(2, LocalDate.of(2026, 2, 11));
        PedidoDTO cancelado = pedido(3, LocalDate.of(2026, 2, 11), "CANCELADO", 70000, null, "X", "X", "X", 1, 70000);
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of(p1, p2, cancelado));
        Reporte r = reporte(DESDE, HASTA);

        generador.ventasPorPeriodo(r);

        assertEquals(160000, r.getTotalVentas());
        assertEquals(2L, r.getNumeroPedidos());
        assertEquals(80000, r.getTicketPromedio());
        assertEquals(200000, fila(r, "TOTALES", "Ventas brutas").getMonto());
        assertEquals(-40000, fila(r, "TOTALES", "Reembolsos").getMonto());
        assertEquals(3, filas(r, "POR_DIA").size());
        assertEquals(-40000, fila(r, "POR_DIA", "2026-02-12").getMonto());
        assertNull(r.getMensaje());
    }

    @Test
    void salesByMonth() {
        LocalDate desde = LocalDate.of(2026, 1, 1);
        LocalDate hasta = LocalDate.of(2026, 12, 31);
        when(ventasClient.obtenerPedidos(desde, hasta))
                .thenReturn(List.of(guitarra(1, LocalDate.of(2026, 2, 10)), guitarra(2, LocalDate.of(2026, 2, 20)),
                        guitarra(3, LocalDate.of(2026, 5, 1))));
        Reporte r = reporte(desde, hasta);

        generador.ventasPorPeriodo(r);

        assertEquals(2, filas(r, "POR_MES").size());
        assertEquals(2L, fila(r, "POR_MES", "2026-02").getCantidad());
        assertTrue(filas(r, "POR_DIA").isEmpty());
    }

    @Test
    void salesEmpty() {
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of());
        Reporte r = reporte(DESDE, HASTA);

        generador.ventasPorPeriodo(r);

        assertEquals(0, r.getTotalVentas());
        assertEquals(0, r.getTicketPromedio());
        assertNotNull(r.getMensaje());
    }

    @Test
    void ordersByStatus() {
        PedidoDTO a = guitarra(1, LocalDate.of(2026, 2, 10));
        PedidoDTO b = pedido(2, LocalDate.of(2026, 2, 11), "ENTREGADO", 50000, null, "X", "X", "X", 1, 50000);
        PedidoDTO fuera = guitarra(3, LocalDate.of(2026, 3, 11));
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of(a, b, fuera));
        Reporte r = reporte(DESDE, HASTA);

        generador.estadoPedidos(r);

        assertEquals(2L, r.getNumeroPedidos());
        assertEquals(6, filas(r, "RESUMEN").size());
        assertEquals(1L, fila(r, "RESUMEN", "PAGADO").getCantidad());
        assertEquals(1, filas(r, "PAGADO").size());
        FilaReporte detalle = filas(r, "PAGADO").get(0);
        assertEquals("1", detalle.getReferencia());
        assertEquals("2026-02-10 · Metropolitana", detalle.getValor());
        assertEquals("2026-02-11", filas(r, "ENTREGADO").get(0).getValor());
    }

    @Test
    void ordersEmpty() {
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of());
        Reporte r = reporte(DESDE, HASTA);

        generador.estadoPedidos(r);

        assertNotNull(r.getMensaje());
        assertEquals(0L, r.getNumeroPedidos());
    }

    @Test
    void topProducts() {
        PedidoDTO a = pedido(1, LocalDate.of(2026, 2, 10), "PAGADO", 300000, null, "BAJ-0001", "Bajo", "BAJO", 3, 100000);
        PedidoDTO b = guitarra(2, LocalDate.of(2026, 2, 11));
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of(a, b));
        Reporte r = reporte(DESDE, HASTA);

        generador.productosMasVendidos(r);

        List<FilaReporte> ranking = filas(r, "RANKING");
        assertEquals(2, ranking.size());
        assertEquals("Bajo", ranking.get(0).getEtiqueta());
        assertEquals("BAJ-0001", ranking.get(0).getReferencia());
        assertEquals("BAJO", ranking.get(0).getValor());
        assertEquals(400000, r.getTotalVentas());
        assertEquals(2L, r.getNumeroPedidos());
    }

    @Test
    void topProductsCategory() {
        PedidoDTO a = pedido(1, LocalDate.of(2026, 2, 10), "PAGADO", 300000, null, "BAJ-0001", "Bajo", "BAJO", 3, 100000);
        PedidoDTO b = guitarra(2, LocalDate.of(2026, 2, 11));
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of(a, b));
        Reporte r = reporte(DESDE, HASTA);
        r.setCategoria("GUITARRA");

        generador.productosMasVendidos(r);

        assertEquals(1, filas(r, "RANKING").size());
        assertEquals(1L, r.getNumeroPedidos());
    }

    @Test
    void topProductsEmpty() {
        when(ventasClient.obtenerPedidos(DESDE, HASTA)).thenReturn(List.of());
        Reporte r = reporte(DESDE, HASTA);
        r.setCategoria("VIENTO");

        generador.productosMasVendidos(r);

        assertTrue(r.getMensaje().contains("VIENTO"));
    }

    private final LocalDate ANT_DESDE = LocalDate.of(2026, 1, 1);
    private final LocalDate ANT_HASTA = LocalDate.of(2026, 1, 31);

    @Test
    void summaryFull() {
        PedidoDTO anterior = pedido(1, LocalDate.of(2026, 1, 15), "ENTREGADO", 50000, "Biobío", "GTR-0001", "Strato", "GUITARRA", 1, 50000);
        PedidoDTO actual = guitarra(2, LocalDate.of(2026, 2, 10));
        PedidoDTO sinRegion = pedido(3, LocalDate.of(2026, 2, 12), "EN_PROCESO", 20000, null, "PER-0001", "Cajón", "PERCUSION", 1, 20000);
        List<PedidoDTO> todos = List.of(anterior, actual, sinRegion);
        when(ventasClient.obtenerPedidos(ANT_DESDE, HASTA)).thenReturn(todos);
        when(ventasClient.obtenerPedidos(null, null)).thenReturn(todos);
        when(usuariosClient.contarClientesRegistrados(DESDE, HASTA)).thenReturn(5L);
        when(productosClient.obtenerStockBajo()).thenReturn(List.of(new ProductoDTO("GTR-0002", "Telecaster", "GUITARRA", 1, 3)));
        when(soporteClient.contarTicketsAbiertos()).thenReturn(7L);
        when(ventasClient.contarDevolucionesPendientes()).thenReturn(2L);
        Reporte r = reporte(DESDE, HASTA);

        generador.resumenGeneral(r, ANT_DESDE, ANT_HASTA);

        assertEquals(120000, r.getTotalVentas());
        assertEquals(2L, r.getNumeroPedidos());
        assertEquals(60000, r.getTicketPromedio());
        assertEquals("+140.0 %", fila(r, "INDICADORES", "Variación respecto al periodo anterior").getValor());
        assertEquals("Strato", fila(r, "INDICADORES", "Producto más vendido").getValor());
        assertEquals(5L, fila(r, "INDICADORES", "Clientes nuevos").getCantidad());
        assertEquals(2L, fila(r, "INDICADORES", "Pedidos pendientes de despacho (pagados o en proceso)").getCantidad());
        assertEquals(1L, fila(r, "INDICADORES", "Productos con stock bajo").getCantidad());
        assertEquals(7L, fila(r, "INDICADORES", "Tickets de soporte abiertos").getCantidad());
        assertEquals(2L, fila(r, "INDICADORES", "Devoluciones pendientes").getCantidad());
        assertEquals(2, filas(r, "TOP_5").size());
        assertEquals(2, filas(r, "POR_CATEGORIA").size());
        assertEquals("Metropolitana", filas(r, "POR_REGION").get(0).getEtiqueta());
        assertEquals("Sin región", filas(r, "POR_REGION").get(1).getEtiqueta());
        FilaReporte stock = filas(r, "STOCK_BAJO").get(0);
        assertEquals("GTR-0002", stock.getReferencia());
        assertEquals("mínimo 3", stock.getValor());
        assertNull(r.getMensaje());
    }

    @Test
    void summaryServicesDown() {
        when(ventasClient.obtenerPedidos(ANT_DESDE, HASTA)).thenReturn(List.of());
        when(ventasClient.obtenerPedidos(null, null)).thenThrow(new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "caído"));
        when(usuariosClient.contarClientesRegistrados(DESDE, HASTA)).thenReturn(null);
        when(productosClient.obtenerStockBajo()).thenThrow(new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "caído"));
        when(soporteClient.contarTicketsAbiertos()).thenReturn(null);
        when(ventasClient.contarDevolucionesPendientes()).thenReturn(null);
        Reporte r = reporte(DESDE, HASTA);

        generador.resumenGeneral(r, ANT_DESDE, ANT_HASTA);

        assertEquals(0, r.getTotalVentas());
        assertEquals("Sin ventas en el periodo anterior", fila(r, "INDICADORES", "Variación respecto al periodo anterior").getValor());
        assertEquals("Sin ventas en el periodo", fila(r, "INDICADORES", "Producto más vendido").getValor());
        assertEquals("Sin datos: ms-usuarios no respondió", fila(r, "INDICADORES", "Clientes nuevos").getValor());
        assertEquals("Sin datos: ms-ventas no respondió",
                fila(r, "INDICADORES", "Pedidos pendientes de despacho (pagados o en proceso)").getValor());
        assertEquals("Sin datos: ms-productos no respondió", fila(r, "INDICADORES", "Productos con stock bajo").getValor());
        assertEquals("Sin datos: ms-soporte no respondió", fila(r, "INDICADORES", "Tickets de soporte abiertos").getValor());
        assertTrue(filas(r, "STOCK_BAJO").isEmpty());
        assertNotNull(r.getMensaje());
    }

    @Test
    void lowStockNullAsZero() {
        when(ventasClient.obtenerPedidos(ANT_DESDE, HASTA)).thenReturn(new ArrayList<>());
        when(ventasClient.obtenerPedidos(null, null)).thenReturn(new ArrayList<>());
        when(usuariosClient.contarClientesRegistrados(DESDE, HASTA)).thenReturn(0L);
        when(productosClient.obtenerStockBajo()).thenReturn(List.of(new ProductoDTO("GTR-0002", "Telecaster", "GUITARRA", null, 3)));
        when(soporteClient.contarTicketsAbiertos()).thenReturn(0L);
        when(ventasClient.contarDevolucionesPendientes()).thenReturn(0L);
        Reporte r = reporte(DESDE, HASTA);

        generador.resumenGeneral(r, ANT_DESDE, ANT_HASTA);

        assertEquals(0L, filas(r, "STOCK_BAJO").get(0).getCantidad());
    }
}
