# Chibson Instruments · Backend

Backend de la tienda de instrumentos musicales Chibson. Son 6 microservicios Spring Boot y un API Gateway, cada uno en su carpeta con el patrón Controller-Service-Repository.

| Carpeta | Servicio | Puerto | Base de datos | Qué hace |
|---|---|---|---|---|
| `gateway` | API Gateway | 8080 | — | Entrada única, rutas, CORS y validación del token |
| `usuarios` | ms-usuarios | 8081 | `chibson_usuarios` | Registro, login, perfil, usuarios, roles, notificaciones, historial |
| `productos` | ms-productos | 8082 | `chibson_productos` | Catálogo, fichas técnicas, stock, reseñas |
| `ventas` | ms-ventas | 8083 | `chibson_ventas` | Checkout, pagos, pedidos, devoluciones, ventas |
| `soporte` | ms-soporte | 8084 | `chibson_soporte` | Tickets de soporte |
| `contenido` | ms-contenido | 8085 | `chibson_contenido` | Noticias e información institucional |
| `informes` | ms-informes | 8086 | — (en memoria) | Reportes y resumen general |

Cada carpeta tiene su `README.md` con sus endpoints. El detalle de todas las rutas está en `Documentacion/Puertos_y_Rutas.md`.

## Tecnologías

Java 25 · Spring Boot 4.1 · Spring Data JPA · MySQL (XAMPP) · H2 para pruebas · Spring HATEOAS · springdoc OpenAPI (Swagger) · Spring Cloud Gateway · Lombok · JUnit 5 + Mockito · JaCoCo.

## Requisitos

- JDK 25 (`JAVA_HOME` apuntando a él).
- MySQL de XAMPP en el puerto 3306, usuario `root` sin contraseña. Las bases y tablas se crean solas.
- VS Code con "Extension Pack for Java". No instalar la extensión aparte "Lombok Annotations Support for VS Code": la de Red Hat ya trae Lombok y la otra rompe los constructores (ver `CAMBIOS.md`).

## Levantar todo

Desde esta carpeta, en PowerShell:

```
.\iniciar-todo.ps1      # abre una ventana por servicio, en orden, y espera a que cada uno responda
.\verificar-todo.ps1    # revisa MySQL, Swagger de cada servicio y el paso por el gateway
.\detener-todo.ps1      # detiene los procesos Java de los puertos 8080 a 8086
```

También están como tareas de VS Code: Ctrl+Shift+P → "Tasks: Run Task" → "Iniciar todo", "Verificar todo" o "Detener todo".

A mano: `.\mvnw spring-boot:run` en cada carpeta, primero `usuarios` y al final `gateway`.

## Cómo funciona

**Sesión.** `POST /api/auth/login` entrega un token. El frontend llama siempre al gateway con `Authorization: Bearer <token>`; el gateway valida el token y le pasa al microservicio el encabezado `X-Rut-Usuario` con el RUT. Cada microservicio pregunta a ms-usuarios (`/api/roles/verificar`) si ese RUT tiene el permiso que pide el endpoint. Si se llama directo al puerto de un microservicio (por ejemplo desde Postman), se manda `X-Rut-Usuario` a mano.

**Comunicación entre servicios.** Los microservicios se llaman entre sí con `RestTemplate` (paquete `client`). Por ejemplo, ms-ventas pide el precio a ms-productos y le ordena descontar stock al aprobarse el pago; todos registran las acciones de los administradores en ms-usuarios.

**HATEOAS.** Las respuestas de un recurso traen `_links` con su propia URL y las acciones relacionadas, y las listas vienen dentro de `_embedded` (por ejemplo `_embedded.productos`). Los endpoints de uso interno entre microservicios (contar, existe, verificar, datos, stock, bajo-stock, resumen) responden JSON simple para que los clientes `RestTemplate` sigan funcionando igual.

**Swagger.** Cada microservicio publica su documentación en `http://localhost:<puerto>/swagger-ui.html` (8081 a 8086), con cada endpoint descrito y la opción de probarlo.

## Pruebas y cobertura

En cada carpeta:

```
.\mvnw clean test
```

| Tipo | Ubicación | Herramientas | Qué prueba |
|---|---|---|---|
| Unitarias de servicio | `src/test/java/.../service` | JUnit 5 + Mockito | Reglas de negocio con los repositorios y clientes simulados |
| Unitarias de cliente | `src/test/java/.../client` | Mockito | Llamadas `RestTemplate` a otros servicios y manejo de errores |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest` + `@MockitoBean` | Rutas, códigos HTTP, JSON y enlaces HATEOAS |
| Integración | `controller/*ControllerIT` | `@SpringBootTest` + MockMvc + H2 | Flujo completo hasta la base de datos (perfil `test`, `LimpiezaBaseDatos`) |

El informe de JaCoCo queda en `target/site/jacoco/index.html`. En VS Code la cobertura se ve en el Explorador al ejecutar las pruebas con cobertura desde el panel Pruebas (ver `CAMBIOS.md`).

## Postman

- `Documentacion/Chibson.postman_collection.json`: todas las colecciones en una, una carpeta por servicio.
- `Documentacion/Ejemplos_Postman.md`: login, encabezados, ejemplos de cuerpo y respuestas.
- Cada microservicio tiene además su colección en su carpeta.

## Estructura

```
Chibson_Backend-main/
├── gateway/  usuarios/  productos/  ventas/  soporte/  contenido/  informes/
│   └── src/main/java/chibson/<servicio>/
│       ├── controller/   endpoints REST (HATEOAS + Swagger)
│       ├── service/      reglas de negocio
│       ├── repository/   Spring Data JPA
│       ├── model/        entidades
│       ├── dto/          datos de entrada y salida
│       ├── client/       llamadas a otros microservicios
│       └── config/       RestTemplate y Swagger
├── Documentacion/        rutas, ejemplos y colección de Postman
├── iniciar-todo.ps1  detener-todo.ps1  verificar-todo.ps1
├── CAMBIOS.md            cambios hechos al código original
└── .vscode/              configuración de pruebas y tareas
```
