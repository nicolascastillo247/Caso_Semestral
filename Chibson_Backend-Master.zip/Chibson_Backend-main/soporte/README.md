# ms-soporte

Tickets de soporte: el cliente los crea, ve y cierra con calificación; el administrador los responde y cambia su estado.

- **Puerto:** 8084
- **Base de datos:** `chibson_soporte` en MySQL (se crea sola al arrancar)
- **Swagger:** http://localhost:8084/swagger-ui.html
- **Llama a:** ms-usuarios (permisos, datos del cliente, notificaciones e historial).
- **Lo usan:** ms-informes (cantidad de tickets abiertos).

## Ejecutar

```
.\mvnw spring-boot:run
```

O todo el backend junto con `iniciar-todo.ps1` desde la carpeta raíz.

## Pruebas

```
.\mvnw clean test
```

El informe de cobertura queda en `target/site/jacoco/index.html`.

Las pruebas no usan MySQL: los `*ControllerIT` levantan la aplicación completa con H2 en memoria (perfil `test`) y limpian las tablas antes de cada prueba con `LimpiezaBaseDatos`. Los servicios externos se reemplazan con `@MockitoBean`.

| Tipo | Clases | Qué prueba |
|---|---|---|
| Servicio | `service/*Test` | Reglas de negocio con Mockito, sin Spring. |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest`: rutas, códigos HTTP, JSON y enlaces HATEOAS con el servicio simulado. |
| Integración | `controller/*ControllerIT` | `@SpringBootTest` + MockMvc + H2: flujo completo hasta la base de datos. |

## Endpoints

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/tickets` | El cliente crea un ticket | Sí |
| GET | `/api/tickets/mis-tickets` | Tickets del cliente que hace la petición | Sí |
| GET | `/api/tickets/mis-tickets/{numero}` | Detalle de un ticket del cliente con sus respuestas | Sí |
| PATCH | `/api/tickets/mis-tickets/{numero}/cerrar` | El cliente cierra un ticket resuelto y lo califica | Sí |
| GET | `/api/tickets` | Lista todos los tickets, opcionalmente por estado (administración) | Sí |
| GET | `/api/tickets/{numero}` | Detalle de un ticket (administración) | Sí |
| POST | `/api/tickets/{numero}/respuestas` | Responde un ticket | Sí |
| PATCH | `/api/tickets/{numero}/estado` | Cambia el estado de un ticket | Sí |
| DELETE | `/api/tickets/{numero}` | Elimina un ticket | Sí |
| GET | `/api/tickets/abiertos/contar` | Cuenta los tickets sin resolver (uso interno de ms-informes) | No |

Las respuestas de un recurso traen `_links` (HATEOAS). Las listas vienen dentro de `_embedded`. Los endpoints de uso interno (contar, existe, verificar, datos, stock, resumen) responden JSON simple porque los consumen otros microservicios.

Colección de Postman: `chibson-soporte.postman_collection.json` (en esta carpeta).
