package chibson.soporte.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import chibson.soporte.dto.CierreDTO;
import chibson.soporte.dto.EstadoDTO;
import chibson.soporte.dto.RespuestaDTO;
import chibson.soporte.dto.TicketDTO;
import chibson.soporte.dto.TicketRespuestaDTO;
import chibson.soporte.model.EstadoTicket;
import chibson.soporte.service.TicketService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/tickets")
@Tag(name = "Tickets", description = "Soporte al cliente")
public class TicketController {
    private static final String RUT = "X-Rut-Usuario";

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping
    @Operation(summary = "El cliente crea un ticket")
    public ResponseEntity<EntityModel<TicketRespuestaDTO>> crearTicket(
            @RequestHeader(value = RUT, required = false) String rut, @RequestBody TicketDTO datos) {
        return ResponseEntity.status(HttpStatus.CREATED).body(modeloCliente(ticketService.crearTicket(rut, datos)));
    }

    @GetMapping("/mis-tickets")
    @Operation(summary = "Tickets del cliente que hace la petición")
    public CollectionModel<EntityModel<TicketRespuestaDTO>> misTickets(
            @RequestHeader(value = RUT, required = false) String rut) {
        return CollectionModel.of(ticketService.listarPorCliente(rut).stream().map(this::modeloCliente).toList(),
                linkTo(TicketController.class).slash("mis-tickets").withSelfRel());
    }

    @GetMapping("/mis-tickets/{numero}")
    @Operation(summary = "Detalle de un ticket del cliente con sus respuestas")
    public EntityModel<TicketRespuestaDTO> miTicket(@RequestHeader(value = RUT, required = false) String rut,
                                                    @PathVariable Long numero) {
        return modeloCliente(ticketService.obtenerDetalleCliente(numero, rut));
    }

    @PatchMapping("/mis-tickets/{numero}/cerrar")
    @Operation(summary = "El cliente cierra un ticket resuelto y lo califica")
    public EntityModel<TicketRespuestaDTO> cerrar(@RequestHeader(value = RUT, required = false) String rut,
                                                  @PathVariable Long numero,
                                                  @RequestBody(required = false) CierreDTO datos) {
        return modeloCliente(ticketService.cerrarYCalificar(numero, rut, datos));
    }

    @GetMapping
    @Operation(summary = "Lista todos los tickets, opcionalmente por estado (administración)")
    public CollectionModel<EntityModel<TicketRespuestaDTO>> listar(
            @RequestHeader(value = RUT, required = false) String rut,
            @RequestParam(required = false) EstadoTicket estado) {
        return CollectionModel.of(ticketService.listarTickets(rut, estado).stream().map(this::modeloAdmin).toList(),
                linkTo(TicketController.class).withSelfRel());
    }

    @GetMapping("/{numero}")
    @Operation(summary = "Detalle de un ticket (administración)")
    public EntityModel<TicketRespuestaDTO> detalle(@RequestHeader(value = RUT, required = false) String rut,
                                                   @PathVariable Long numero) {
        return modeloAdmin(ticketService.obtenerDetalle(numero, rut));
    }

    @PostMapping("/{numero}/respuestas")
    @Operation(summary = "Responde un ticket")
    public EntityModel<TicketRespuestaDTO> responder(@RequestHeader(value = RUT, required = false) String rut,
                                                     @PathVariable Long numero, @RequestBody RespuestaDTO datos) {
        return modeloAdmin(ticketService.responderTicket(numero, datos, rut));
    }

    @PatchMapping("/{numero}/estado")
    @Operation(summary = "Cambia el estado de un ticket")
    public EntityModel<TicketRespuestaDTO> actualizarEstado(@RequestHeader(value = RUT, required = false) String rut,
                                                            @PathVariable Long numero, @RequestBody EstadoDTO datos) {
        return modeloAdmin(ticketService.actualizarEstado(numero, datos.getEstado(), rut));
    }

    @DeleteMapping("/{numero}")
    @Operation(summary = "Elimina un ticket")
    public ResponseEntity<Void> eliminar(@RequestHeader(value = RUT, required = false) String rut,
                                         @PathVariable Long numero) {
        ticketService.eliminarTicket(numero, rut);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/abiertos/contar")
    @Operation(summary = "Cuenta los tickets sin resolver (uso interno de ms-informes)")
    public long contarAbiertos() {
        return ticketService.contarAbiertos();
    }

    private EntityModel<TicketRespuestaDTO> modeloCliente(TicketRespuestaDTO ticket) {
        return modelo(ticket, linkTo(TicketController.class).slash("mis-tickets").slash(ticket.getNumeroTicket())
                .withSelfRel(), linkTo(TicketController.class).slash("mis-tickets").withRel("misTickets"));
    }

    private EntityModel<TicketRespuestaDTO> modeloAdmin(TicketRespuestaDTO ticket) {
        return modelo(ticket, linkTo(TicketController.class).slash(ticket.getNumeroTicket()).withSelfRel(),
                linkTo(TicketController.class).withRel("tickets"));
    }

    private EntityModel<TicketRespuestaDTO> modelo(TicketRespuestaDTO ticket, Link self, Link lista) {
        return EntityModel.of(ticket, self, lista);
    }
}
