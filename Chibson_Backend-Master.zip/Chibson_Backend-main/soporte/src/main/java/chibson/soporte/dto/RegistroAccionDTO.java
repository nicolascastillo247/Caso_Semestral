package chibson.soporte.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
public class RegistroAccionDTO {
    private String rutAdministrador;

    private String tipo;
    private String modulo;
    private String descripcion;
    private List<DetalleCambioDTO> cambios;

    public RegistroAccionDTO() {
        this.cambios = new ArrayList<>();
    }
}
