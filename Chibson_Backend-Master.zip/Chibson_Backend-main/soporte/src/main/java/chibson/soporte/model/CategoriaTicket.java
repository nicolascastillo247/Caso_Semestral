package chibson.soporte.model;

public enum CategoriaTicket {
    DESPACHO,
    GARANTIA,
    PAGO,
    PEDIDO,
    OTRO
}
