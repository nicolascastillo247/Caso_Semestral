package chibson.soporte.dto;

import chibson.soporte.model.CategoriaTicket;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TicketDTO {
    private String asunto;
    private CategoriaTicket categoria;
    private String descripcion;

    private String adjuntoUrl;
}
