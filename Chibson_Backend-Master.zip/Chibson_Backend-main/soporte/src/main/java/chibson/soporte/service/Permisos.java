package chibson.soporte.service;

public final class Permisos {
    public static final String GESTIONAR_SOPORTE = "GESTIONAR_SOPORTE";

    private Permisos() {
    }
}
