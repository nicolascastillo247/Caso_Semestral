package chibson.soporte.dto;

import chibson.soporte.model.EstadoTicket;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RespuestaDTO {
    private String contenido;
    private EstadoTicket estado;
}
