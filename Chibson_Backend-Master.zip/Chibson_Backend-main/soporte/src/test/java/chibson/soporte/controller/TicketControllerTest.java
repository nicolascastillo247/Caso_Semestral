package chibson.soporte.controller;

import chibson.soporte.dto.CierreDTO;
import chibson.soporte.dto.RespuestaDTO;
import chibson.soporte.dto.TicketDTO;
import chibson.soporte.dto.TicketRespuestaDTO;
import chibson.soporte.model.CategoriaTicket;
import chibson.soporte.model.EstadoTicket;
import chibson.soporte.service.TicketService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(TicketController.class)
@ActiveProfiles("test")
class TicketControllerTest {
    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";

    @MockitoBean
    private TicketService ticketService;

    @Autowired
    private MockMvc mvc;

    private TicketRespuestaDTO respuesta(Long numero, EstadoTicket estado) {
        TicketRespuestaDTO r = new TicketRespuestaDTO();
        r.setNumeroTicket(numero);
        r.setRutCliente(CLIENTE);
        r.setAsunto("Mi pedido no llega");
        r.setCategoria(CategoriaTicket.DESPACHO);
        r.setEstado(estado);
        r.setMensajes(new ArrayList<>());
        return r;
    }

    @Test
    void create201() throws Exception {
        when(ticketService.crearTicket(eq(CLIENTE), any(TicketDTO.class))).thenReturn(respuesta(1L, EstadoTicket.ABIERTO));

        mvc.perform(post("/api/tickets").header("X-Rut-Usuario", CLIENTE)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"asunto\":\"Mi pedido no llega\",\"categoria\":\"DESPACHO\",\"descripcion\":\"Hace una semana\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.numeroTicket").value(1))
                .andExpect(jsonPath("$.estado").value("ABIERTO"));
    }

    @Test
    void createUnauthorized() throws Exception {
        when(ticketService.crearTicket(eq(null), any(TicketDTO.class)))
                .thenThrow(new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Debe iniciar sesión"));

        mvc.perform(post("/api/tickets").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void myTickets() throws Exception {
        when(ticketService.listarPorCliente(CLIENTE)).thenReturn(List.of(respuesta(1L, EstadoTicket.ABIERTO)));

        mvc.perform(get("/api/tickets/mis-tickets").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.tickets[0].numeroTicket").value(1));
    }

    @Test
    void myTicket() throws Exception {
        when(ticketService.obtenerDetalleCliente(2L, CLIENTE)).thenReturn(respuesta(2L, EstadoTicket.EN_PROCESO));

        mvc.perform(get("/api/tickets/mis-tickets/2").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("EN_PROCESO"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.misTickets.href").exists());
    }

    @Test
    void otherClientTicket404() throws Exception {
        when(ticketService.obtenerDetalleCliente(3L, CLIENTE))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe el ticket #3"));

        mvc.perform(get("/api/tickets/mis-tickets/3").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isNotFound());
    }

    @Test
    void closeWithRating() throws Exception {
        when(ticketService.cerrarYCalificar(eq(4L), eq(CLIENTE), any(CierreDTO.class)))
                .thenReturn(respuesta(4L, EstadoTicket.CERRADO));

        mvc.perform(patch("/api/tickets/mis-tickets/4/cerrar").header("X-Rut-Usuario", CLIENTE)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"calificacion\":5,\"comentario\":\"Excelente\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CERRADO"));
    }

    @Test
    void closeNoBody() throws Exception {
        when(ticketService.cerrarYCalificar(4L, CLIENTE, null)).thenReturn(respuesta(4L, EstadoTicket.CERRADO));

        mvc.perform(patch("/api/tickets/mis-tickets/4/cerrar").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk());
    }

    @Test
    void adminListStatus() throws Exception {
        when(ticketService.listarTickets(ADMIN, EstadoTicket.ABIERTO)).thenReturn(List.of(respuesta(5L, EstadoTicket.ABIERTO)));

        mvc.perform(get("/api/tickets").header("X-Rut-Usuario", ADMIN).param("estado", "ABIERTO"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.tickets[0].numeroTicket").value(5));
    }

    @Test
    void adminDetail() throws Exception {
        when(ticketService.obtenerDetalle(6L, ADMIN)).thenReturn(respuesta(6L, EstadoTicket.RESUELTO));

        mvc.perform(get("/api/tickets/6").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.numeroTicket").value(6));
    }

    @Test
    void reply() throws Exception {
        when(ticketService.responderTicket(eq(7L), any(RespuestaDTO.class), eq(ADMIN)))
                .thenReturn(respuesta(7L, EstadoTicket.EN_PROCESO));

        mvc.perform(post("/api/tickets/7/respuestas").header("X-Rut-Usuario", ADMIN)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"contenido\":\"Lo estamos revisando\",\"estado\":\"EN_PROCESO\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("EN_PROCESO"));
    }

    @Test
    void updateStatus() throws Exception {
        when(ticketService.actualizarEstado(8L, EstadoTicket.RESUELTO, ADMIN))
                .thenReturn(respuesta(8L, EstadoTicket.RESUELTO));

        mvc.perform(patch("/api/tickets/8/estado").header("X-Rut-Usuario", ADMIN)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"estado\":\"RESUELTO\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("RESUELTO"));
    }

    @Test
    void delete204() throws Exception {
        mvc.perform(delete("/api/tickets/9").header("X-Rut-Usuario", ADMIN)).andExpect(status().isNoContent());

        verify(ticketService).eliminarTicket(9L, ADMIN);
    }

    @Test
    void countOpen() throws Exception {
        when(ticketService.contarAbiertos()).thenReturn(4L);

        mvc.perform(get("/api/tickets/abiertos/contar"))
                .andExpect(status().isOk())
                .andExpect(content().string("4"));
    }
}
