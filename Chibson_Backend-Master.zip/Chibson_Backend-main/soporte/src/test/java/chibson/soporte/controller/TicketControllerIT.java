package chibson.soporte.controller;

import chibson.soporte.LimpiezaBaseDatos;
import chibson.soporte.client.UsuariosClient;
import chibson.soporte.dto.UsuarioDTO;
import chibson.soporte.model.CategoriaTicket;
import chibson.soporte.model.EstadoTicket;
import chibson.soporte.model.Ticket;
import chibson.soporte.repository.TicketRepository;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class TicketControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String CLIENTE = "11111111-1";
    private static final String OTRO = "22222222-2";
    private static final String ADMIN = "12345678-5";
    private static final String CUERPO = "{\"asunto\":\"Mi pedido no llega\",\"categoria\":\"DESPACHO\",\"descripcion\":\"Hace una semana\"}";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private TicketRepository ticketRepository;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
        UsuarioDTO ana = new UsuarioDTO(CLIENTE, "Ana", "Pérez", "ACTIVO");
        when(usuariosClient.obtenerUsuario(CLIENTE)).thenReturn(ana);
        when(usuariosClient.buscarUsuario(anyString())).thenReturn(ana);
    }

    private Ticket guardar(String rut, EstadoTicket estado) {
        Ticket t = new Ticket();
        t.setRutCliente(rut);
        t.setAsunto("Asunto");
        t.setCategoria(CategoriaTicket.PAGO);
        t.setDescripcion("Descripcion");
        t.setEstado(estado);
        t.setFechaCreacion(LocalDateTime.now());
        return ticketRepository.save(t);
    }

    @Test
    void createTicket201() throws Exception {
        mockMvc.perform(post("/api/tickets").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(CUERPO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.numeroTicket").exists())
                .andExpect(jsonPath("$.estado").value("ABIERTO"))
                .andExpect(jsonPath("$.nombreCliente").value("Ana Pérez"));
    }

    @Test
    void createWithoutSubject400() throws Exception {
        mockMvc.perform(post("/api/tickets").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"categoria\":\"PAGO\",\"descripcion\":\"x\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void myTicketsOnlyOwn() throws Exception {
        guardar(CLIENTE, EstadoTicket.ABIERTO);
        guardar(OTRO, EstadoTicket.ABIERTO);

        mockMvc.perform(get("/api/tickets/mis-tickets").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.tickets.length()").value(1));
    }

    @Test
    void myTicketDetailAndOtherClient404() throws Exception {
        Ticket propio = guardar(CLIENTE, EstadoTicket.ABIERTO);
        Ticket ajeno = guardar(OTRO, EstadoTicket.ABIERTO);

        mockMvc.perform(get("/api/tickets/mis-tickets/" + propio.getNumeroTicket()).header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.asunto").value("Asunto"));
        mockMvc.perform(get("/api/tickets/mis-tickets/" + ajeno.getNumeroTicket()).header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isNotFound());
    }

    @Test
    void closeResolvedWithRating() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.RESUELTO);

        mockMvc.perform(patch("/api/tickets/mis-tickets/" + t.getNumeroTicket() + "/cerrar")
                        .header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"calificacion\":5,\"comentario\":\"Excelente\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CERRADO"))
                .andExpect(jsonPath("$.calificacion").value(5));
    }

    @Test
    void closeNotResolved400() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.ABIERTO);

        mockMvc.perform(patch("/api/tickets/mis-tickets/" + t.getNumeroTicket() + "/cerrar")
                        .header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isBadRequest());
    }

    @Test
    void adminListWithStatusFilter() throws Exception {
        guardar(CLIENTE, EstadoTicket.ABIERTO);
        guardar(CLIENTE, EstadoTicket.RESUELTO);

        mockMvc.perform(get("/api/tickets").header("X-Rut-Usuario", ADMIN))
                .andExpect(jsonPath("$._embedded.tickets.length()").value(2));
        mockMvc.perform(get("/api/tickets").header("X-Rut-Usuario", ADMIN).param("estado", "RESUELTO"))
                .andExpect(jsonPath("$._embedded.tickets.length()").value(1));
    }

    @Test
    void adminForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("GESTIONAR_SOPORTE"));

        mockMvc.perform(get("/api/tickets").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isForbidden());
    }

    @Test
    void adminDetailAndNotFound() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.ABIERTO);

        mockMvc.perform(get("/api/tickets/" + t.getNumeroTicket()).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreCliente").value("Ana Pérez"));
        mockMvc.perform(get("/api/tickets/999999").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void replyChangesStatus() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.ABIERTO);

        mockMvc.perform(post("/api/tickets/" + t.getNumeroTicket() + "/respuestas").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"contenido\":\"Estamos revisando\",\"estado\":\"EN_PROCESO\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("EN_PROCESO"))
                .andExpect(jsonPath("$.mensajes.length()").value(1));
    }

    @Test
    void replyEmpty400() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.ABIERTO);

        mockMvc.perform(post("/api/tickets/" + t.getNumeroTicket() + "/respuestas").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"contenido\":\" \"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateStatus() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.ABIERTO);
        String url = "/api/tickets/" + t.getNumeroTicket() + "/estado";

        mockMvc.perform(patch(url).header("X-Rut-Usuario", ADMIN).contentType(JSON).content("{\"estado\":\"RESUELTO\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("RESUELTO"))
                .andExpect(jsonPath("$.fechaResolucion").exists());
        mockMvc.perform(patch(url).header("X-Rut-Usuario", ADMIN).contentType(JSON).content("{\"estado\":\"RESUELTO\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deleteTicket() throws Exception {
        Ticket t = guardar(CLIENTE, EstadoTicket.ABIERTO);

        mockMvc.perform(delete("/api/tickets/" + t.getNumeroTicket()).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNoContent());
        mockMvc.perform(get("/api/tickets/" + t.getNumeroTicket()).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void countOpen() throws Exception {
        guardar(CLIENTE, EstadoTicket.ABIERTO);
        guardar(CLIENTE, EstadoTicket.EN_PROCESO);
        guardar(CLIENTE, EstadoTicket.CERRADO);

        mockMvc.perform(get("/api/tickets/abiertos/contar"))
                .andExpect(status().isOk())
                .andExpect(content().string("2"));
    }
}
