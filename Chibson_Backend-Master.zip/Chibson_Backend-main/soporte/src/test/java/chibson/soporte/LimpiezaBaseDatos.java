package chibson.soporte;

import chibson.soporte.repository.MensajeTicketRepository;
import chibson.soporte.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LimpiezaBaseDatos {
    @Autowired
    private MensajeTicketRepository mensajeTicketRepository;

    @Autowired
    private TicketRepository ticketRepository;

    public void limpiar() {
        mensajeTicketRepository.deleteAll();
        ticketRepository.deleteAll();
    }
}
