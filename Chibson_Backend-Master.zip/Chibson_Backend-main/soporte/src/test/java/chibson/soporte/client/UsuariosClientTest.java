package chibson.soporte.client;

import chibson.soporte.client.UsuariosClient;
import chibson.soporte.dto.NotificacionDTO;
import chibson.soporte.dto.RegistroAccionDTO;
import chibson.soporte.dto.UsuarioDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsuariosClientTest {
    private static final String RUT = "11111111-1";

    @Mock
    private RestTemplate restTemplate;

    private UsuariosClient client;

    @BeforeEach
    void setUp() {
        client = new UsuariosClient(restTemplate, "http://localhost:8081");
    }

    @Test
    void permissionNoRut401() {
        assertEquals(HttpStatus.UNAUTHORIZED, assertThrows(ResponseStatusException.class,
                () -> client.exigirPermiso(null, "GESTIONAR_SOPORTE")).getStatusCode());
    }

    @Test
    void permissionGranted() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("GESTIONAR_SOPORTE"))).thenReturn(true);

        assertDoesNotThrow(() -> client.exigirPermiso(RUT, "GESTIONAR_SOPORTE"));
    }

    @Test
    void permissionDenied403() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("GESTIONAR_SOPORTE"))).thenReturn(false);

        assertEquals(HttpStatus.FORBIDDEN, assertThrows(ResponseStatusException.class,
                () -> client.exigirPermiso(RUT, "GESTIONAR_SOPORTE")).getStatusCode());
    }

    @Test
    void permissionDown503() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("GESTIONAR_SOPORTE")))
                .thenThrow(new ResourceAccessException("sin conexión"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, assertThrows(ResponseStatusException.class,
                () -> client.exigirPermiso(RUT, "GESTIONAR_SOPORTE")).getStatusCode());
    }

    @Test
    void getUserNoRut401() {
        assertEquals(HttpStatus.UNAUTHORIZED, assertThrows(ResponseStatusException.class,
                () -> client.obtenerUsuario(" ")).getStatusCode());
    }

    @Test
    void getActiveUser() {
        UsuarioDTO activo = new UsuarioDTO(RUT, "Ana", "Pérez", "ACTIVO");
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT))).thenReturn(activo);

        assertEquals(activo, client.obtenerUsuario(" " + RUT + " "));
    }

    @Test
    void getInactiveUser401() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT)))
                .thenReturn(new UsuarioDTO(RUT, "Ana", "Pérez", "DESACTIVADO"))
                .thenReturn(null);

        assertEquals(HttpStatus.UNAUTHORIZED, assertThrows(ResponseStatusException.class,
                () -> client.obtenerUsuario(RUT)).getStatusCode());
        assertEquals(HttpStatus.UNAUTHORIZED, assertThrows(ResponseStatusException.class,
                () -> client.obtenerUsuario(RUT)).getStatusCode());
    }

    @Test
    void getUserNotFound401() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT)))
                .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        assertEquals(HttpStatus.UNAUTHORIZED, assertThrows(ResponseStatusException.class,
                () -> client.obtenerUsuario(RUT)).getStatusCode());
    }

    @Test
    void getUserDown503() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT)))
                .thenThrow(new ResourceAccessException("sin conexión"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, assertThrows(ResponseStatusException.class,
                () -> client.obtenerUsuario(RUT)).getStatusCode());
    }

    @Test
    void findUserNull() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT)))
                .thenThrow(new ResourceAccessException("sin conexión"));

        assertNull(client.buscarUsuario(RUT));
    }

    @Test
    void findUser() {
        UsuarioDTO usuario = new UsuarioDTO(RUT, "Ana", "Pérez", "ACTIVO");
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT))).thenReturn(usuario);

        assertEquals(usuario, client.buscarUsuario(RUT));
    }

    @Test
    void sendNotification() {
        client.enviarNotificacion(RUT, "Hola", "ticket:1");

        verify(restTemplate).postForObject(eq("http://localhost:8081/api/notificaciones"),
                eq(new NotificacionDTO(RUT, "Hola", "ticket:1")), eq(Void.class));
    }

    @Test
    void notificationFailure() {
        when(restTemplate.postForObject(anyString(), any(NotificacionDTO.class), eq(Void.class)))
                .thenThrow(new ResourceAccessException("sin conexión"));

        assertDoesNotThrow(() -> client.enviarNotificacion(RUT, "Hola", "ticket:1"));
    }

    @Test
    void logAction() {
        RegistroAccionDTO accion = new RegistroAccionDTO("12345678-5", "MODIFICAR", "Soporte", "Respondió", new ArrayList<>());

        client.registrarAccion(accion);
        verify(restTemplate).postForObject("http://localhost:8081/api/acciones", accion, Void.class);

        when(restTemplate.postForObject(anyString(), eq(accion), eq(Void.class)))
                .thenThrow(new ResourceAccessException("sin conexión"));
        assertDoesNotThrow(() -> client.registrarAccion(accion));
    }
}
