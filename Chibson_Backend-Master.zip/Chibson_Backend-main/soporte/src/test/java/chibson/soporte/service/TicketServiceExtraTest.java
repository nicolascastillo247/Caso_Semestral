package chibson.soporte.service;

import chibson.soporte.client.UsuariosClient;
import chibson.soporte.dto.CierreDTO;
import chibson.soporte.dto.DetalleCambioDTO;
import chibson.soporte.dto.EstadoDTO;
import chibson.soporte.dto.NotificacionDTO;
import chibson.soporte.dto.RegistroAccionDTO;
import chibson.soporte.dto.RespuestaDTO;
import chibson.soporte.dto.TicketDTO;
import chibson.soporte.dto.TicketRespuestaDTO;
import chibson.soporte.dto.UsuarioDTO;
import chibson.soporte.model.CategoriaTicket;
import chibson.soporte.model.EstadoTicket;
import chibson.soporte.model.Ticket;
import chibson.soporte.repository.TicketRepository;
import chibson.soporte.service.TicketService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TicketServiceExtraTest {
    private static final String CLI = "11111111-1";
    private static final String ADM = "12345678-5";

    @Mock
    private TicketRepository repo;
    @Mock
    private UsuariosClient usuariosClient;
    @InjectMocks
    private TicketService service;

    private UsuarioDTO cliente() {
        return new UsuarioDTO(CLI, "Ana", "Pérez", "ACTIVO");
    }

    private Ticket ticket(Long n, EstadoTicket estado) {
        Ticket t = new Ticket();
        t.setNumeroTicket(n);
        t.setRutCliente(CLI);
        t.setAsunto("Asunto");
        t.setCategoria(CategoriaTicket.PAGO);
        t.setDescripcion("Desc");
        t.setEstado(estado);
        t.setFechaCreacion(LocalDateTime.now());
        return t;
    }

    private void expect400(Runnable r) {
        ResponseStatusException e = assertThrows(ResponseStatusException.class, r::run);
        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void createLongSubject() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        expect400(() -> service.crearTicket(CLI,
                new TicketDTO("x".repeat(151), CategoriaTicket.PAGO, "d", null)));
    }

    @Test
    void createNoDescription() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        expect400(() -> service.crearTicket(CLI, new TicketDTO("Asunto", CategoriaTicket.PAGO, " ", null)));
    }

    @Test
    void createWithAttachment() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO r = service.crearTicket(CLI,
                new TicketDTO("Asunto", CategoriaTicket.PAGO, "Desc", " http://x/a.png "));

        assertEquals("http://x/a.png", r.getAdjuntoUrl());
        assertEquals("Ana Pérez", r.getNombreCliente());
    }

    @Test
    void listByClient() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.findByRutClienteOrderByFechaCreacionDesc(CLI))
                .thenReturn(List.of(ticket(1L, EstadoTicket.ABIERTO), ticket(2L, EstadoTicket.CERRADO)));

        assertEquals(2, service.listarPorCliente(CLI).size());
    }

    @Test
    void clientDetail() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.ABIERTO)));

        assertEquals(1L, service.obtenerDetalleCliente(1L, CLI).getNumeroTicket());
    }

    @Test
    void closeNullData() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.RESUELTO)));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO r = service.cerrarYCalificar(1L, CLI, null);

        assertEquals(EstadoTicket.CERRADO, r.getEstado());
        assertNull(r.getCalificacion());
        assertNull(r.getComentarioCalificacion());
    }

    @Test
    void closeLongComment() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.RESUELTO)));

        expect400(() -> service.cerrarYCalificar(1L, CLI, new CierreDTO(5, "x".repeat(501))));
    }

    @Test
    void closeRatingTooLow() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.RESUELTO)));

        expect400(() -> service.cerrarYCalificar(1L, CLI, new CierreDTO(0, null)));
    }

    @Test
    void closeCommentOnly() {
        when(usuariosClient.obtenerUsuario(CLI)).thenReturn(cliente());
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.RESUELTO)));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO r = service.cerrarYCalificar(1L, CLI, new CierreDTO(null, " Gracias "));

        assertEquals("Gracias", r.getComentarioCalificacion());
    }

    @Test
    void adminListAll() {
        when(repo.findAllByOrderByFechaCreacionAsc())
                .thenReturn(List.of(ticket(1L, EstadoTicket.ABIERTO), ticket(2L, EstadoTicket.ABIERTO)));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        List<TicketRespuestaDTO> lista = service.listarTickets(ADM, null);

        assertEquals(2, lista.size());
        assertEquals("Ana Pérez", lista.get(1).getNombreCliente());
    }

    @Test
    void adminListByStatus() {
        when(repo.findByEstadoOrderByFechaCreacionAsc(EstadoTicket.RESUELTO))
                .thenReturn(List.of(ticket(3L, EstadoTicket.RESUELTO)));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(null);

        List<TicketRespuestaDTO> lista = service.listarTickets(ADM, EstadoTicket.RESUELTO);

        assertEquals(1, lista.size());
        assertNull(lista.get(0).getNombreCliente());
    }

    @Test
    void adminDetail() {
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.ABIERTO)));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        assertEquals("Asunto", service.obtenerDetalle(1L, ADM).getAsunto());
    }

    @Test
    void replyOnlyMessage() {
        Ticket t = ticket(1L, EstadoTicket.ABIERTO);
        when(repo.findById(1L)).thenReturn(Optional.of(t));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        TicketRespuestaDTO r = service.responderTicket(1L, new RespuestaDTO(" Hola ", null), ADM);

        assertEquals(1, r.getMensajes().size());
        assertEquals(EstadoTicket.ABIERTO, r.getEstado());
        verify(usuariosClient).enviarNotificacion(CLI, "Su ticket #1 fue respondido", "ticket:1");
    }

    @Test
    void replySameStatus() {
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.ABIERTO)));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        service.responderTicket(1L, new RespuestaDTO("Hola", EstadoTicket.ABIERTO), ADM);

        verify(usuariosClient).enviarNotificacion(CLI, "Su ticket #1 fue respondido", "ticket:1");
    }

    @Test
    void replyWithStatusChange() {
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.ABIERTO)));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        TicketRespuestaDTO r = service.responderTicket(1L, new RespuestaDTO("Listo", EstadoTicket.RESUELTO), ADM);

        assertEquals(EstadoTicket.RESUELTO, r.getEstado());
        assertNotNull(r.getFechaResolucion());
    }

    @Test
    void updateStatusResolved() {
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.EN_PROCESO)));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        TicketRespuestaDTO r = service.actualizarEstado(1L, EstadoTicket.RESUELTO, ADM);

        assertEquals(EstadoTicket.RESUELTO, r.getEstado());
        assertNotNull(r.getFechaResolucion());
        verify(usuariosClient).enviarNotificacion(anyString(), anyString(), anyString());
        verify(usuariosClient).registrarAccion(any(RegistroAccionDTO.class));
    }

    @Test
    void updateStatusKeepsDate() {
        Ticket t = ticket(1L, EstadoTicket.RESUELTO);
        LocalDateTime fecha = LocalDateTime.of(2026, 1, 1, 10, 0);
        t.setFechaResolucion(fecha);
        when(repo.findById(1L)).thenReturn(Optional.of(t));
        when(repo.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));
        when(usuariosClient.buscarUsuario(CLI)).thenReturn(cliente());

        TicketRespuestaDTO r = service.actualizarEstado(1L, EstadoTicket.CERRADO, ADM);

        assertEquals(fecha, r.getFechaResolucion());
    }

    @Test
    void updateStatusNull() {
        expect400(() -> service.actualizarEstado(1L, null, ADM));
    }

    @Test
    void updateStatusClosed() {
        when(repo.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.CERRADO)));

        expect400(() -> service.actualizarEstado(1L, EstadoTicket.ABIERTO, ADM));
    }

    @Test
    void deleteTicket() {
        Ticket t = ticket(1L, EstadoTicket.ABIERTO);
        when(repo.findById(1L)).thenReturn(Optional.of(t));

        service.eliminarTicket(1L, ADM);

        verify(repo).delete(t);
        verify(usuariosClient).registrarAccion(any(RegistroAccionDTO.class));
    }

    @Test
    void countOpen() {
        when(repo.countByEstadoIn(any())).thenReturn(4L);

        assertEquals(4L, service.contarAbiertos());
    }

    @Test
    void dtos() {
        assertEquals(EstadoTicket.CERRADO, new EstadoDTO(EstadoTicket.CERRADO).getEstado());
        EstadoDTO e = new EstadoDTO();
        e.setEstado(EstadoTicket.ABIERTO);
        assertEquals(EstadoTicket.ABIERTO, e.getEstado());

        NotificacionDTO n = new NotificacionDTO();
        n.setRutUsuario(CLI);
        n.setMensaje("m");
        n.setReferencia("r");
        assertEquals(new NotificacionDTO(CLI, "m", "r"), n);

        assertEquals("Ana Pérez", cliente().nombreCompleto());
        assertTrue(new RegistroAccionDTO().getCambios().isEmpty());
        assertEquals(new DetalleCambioDTO("c", "a", "b"), new DetalleCambioDTO("c", "a", "b"));
        assertEquals(new TicketDTO("a", CategoriaTicket.OTRO, "d", null),
                new TicketDTO("a", CategoriaTicket.OTRO, "d", null));
        assertEquals(new RespuestaDTO("a", null), new RespuestaDTO("a", null));
        assertEquals(new CierreDTO(1, "c"), new CierreDTO(1, "c"));
    }
}
