package chibson.soporte.service;

import chibson.soporte.client.UsuariosClient;
import chibson.soporte.dto.CierreDTO;
import chibson.soporte.dto.RespuestaDTO;
import chibson.soporte.dto.TicketDTO;
import chibson.soporte.dto.TicketRespuestaDTO;
import chibson.soporte.dto.UsuarioDTO;
import chibson.soporte.model.CategoriaTicket;
import chibson.soporte.model.EstadoTicket;
import chibson.soporte.model.Ticket;
import chibson.soporte.repository.TicketRepository;
import chibson.soporte.service.Permisos;
import chibson.soporte.service.TicketService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TicketServiceTest {
    private static final String RUT_CLIENTE = "11111111-1";
    private static final String RUT_ADMIN = "12345678-5";

    @Mock
    private TicketRepository ticketRepository;
    @Mock
    private UsuariosClient usuariosClient;
    @InjectMocks
    private TicketService ticketService;

    private UsuarioDTO cliente() {
        return new UsuarioDTO(RUT_CLIENTE, "Ana", "Pérez", "ACTIVO");
    }

    private Ticket ticket(Long numero, EstadoTicket estado) {
        Ticket t = new Ticket();
        t.setNumeroTicket(numero);
        t.setRutCliente(RUT_CLIENTE);
        t.setAsunto("Mi pedido no llega");
        t.setCategoria(CategoriaTicket.DESPACHO);
        t.setDescripcion("Hace una semana");
        t.setEstado(estado);
        t.setFechaCreacion(LocalDateTime.now());
        return t;
    }

    @Test
    void createOpen() {
        when(usuariosClient.obtenerUsuario(RUT_CLIENTE)).thenReturn(cliente());
        when(ticketRepository.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO creado = ticketService.crearTicket(RUT_CLIENTE,
                new TicketDTO("  Mi pedido no llega ", CategoriaTicket.DESPACHO, "Hace una semana", ""));

        assertEquals(EstadoTicket.ABIERTO, creado.getEstado());
        assertEquals(RUT_CLIENTE, creado.getRutCliente());
        assertEquals("Mi pedido no llega", creado.getAsunto());
        assertNull(creado.getAdjuntoUrl());
        assertEquals("Ana Pérez", creado.getNombreCliente());
    }

    @Test
    void createNoCategory() {
        when(usuariosClient.obtenerUsuario(RUT_CLIENTE)).thenReturn(cliente());

        assertThrows(ResponseStatusException.class, () -> ticketService.crearTicket(RUT_CLIENTE,
                new TicketDTO("Asunto", null, "Descripción", null)));
        verify(ticketRepository, never()).save(any());
    }

    @Test
    void createNoSubject() {
        when(usuariosClient.obtenerUsuario(RUT_CLIENTE)).thenReturn(cliente());

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> ticketService.crearTicket(
                RUT_CLIENTE, new TicketDTO("  ", CategoriaTicket.PAGO, "Descripción", null)));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void otherClientTicket() {
        when(usuariosClient.obtenerUsuario("22222222-2"))
                .thenReturn(new UsuarioDTO("22222222-2", "Luis", "Soto", "ACTIVO"));
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.ABIERTO)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> ticketService.obtenerDetalleCliente(1L, "22222222-2"));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void closeOnlyResolved() {
        when(usuariosClient.obtenerUsuario(RUT_CLIENTE)).thenReturn(cliente());
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.EN_PROCESO)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> ticketService.cerrarYCalificar(1L, RUT_CLIENTE, new CierreDTO(5, "Bien")));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
        verify(ticketRepository, never()).save(any());
    }

    @Test
    void closeSavesRating() {
        when(usuariosClient.obtenerUsuario(RUT_CLIENTE)).thenReturn(cliente());
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.RESUELTO)));
        when(ticketRepository.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO cerrado = ticketService.cerrarYCalificar(1L, RUT_CLIENTE, new CierreDTO(4, " Buen trato "));

        assertEquals(EstadoTicket.CERRADO, cerrado.getEstado());
        assertEquals(4, cerrado.getCalificacion());
        assertEquals("Buen trato", cerrado.getComentarioCalificacion());
    }

    @Test
    void ratingRange() {
        when(usuariosClient.obtenerUsuario(RUT_CLIENTE)).thenReturn(cliente());
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(ticket(1L, EstadoTicket.RESUELTO)));

        assertThrows(ResponseStatusException.class,
                () -> ticketService.cerrarYCalificar(1L, RUT_CLIENTE, new CierreDTO(6, null)));
        assertThrows(ResponseStatusException.class,
                () -> ticketService.cerrarYCalificar(1L, RUT_CLIENTE, new CierreDTO(0, null)));
    }

    @Test
    void replyNotifies() {
        Ticket abierto = ticket(7L, EstadoTicket.ABIERTO);
        when(ticketRepository.findById(7L)).thenReturn(Optional.of(abierto));
        when(ticketRepository.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO respuesta = ticketService.responderTicket(7L,
                new RespuestaDTO("Estamos revisando", EstadoTicket.EN_PROCESO), RUT_ADMIN);

        assertEquals(1, respuesta.getMensajes().size());
        assertEquals(EstadoTicket.EN_PROCESO, respuesta.getEstado());
        verify(usuariosClient).exigirPermiso(RUT_ADMIN, Permisos.GESTIONAR_SOPORTE);
        verify(usuariosClient).enviarNotificacion(anyString(), anyString(), anyString());
        verify(usuariosClient).registrarAccion(any());
    }

    @Test
    void replyClosed() {
        when(ticketRepository.findById(7L)).thenReturn(Optional.of(ticket(7L, EstadoTicket.CERRADO)));

        assertThrows(ResponseStatusException.class,
                () -> ticketService.responderTicket(7L, new RespuestaDTO("Hola", null), RUT_ADMIN));
        verify(ticketRepository, never()).save(any());
    }

    @Test
    void replyEmpty() {
        assertThrows(ResponseStatusException.class,
                () -> ticketService.responderTicket(7L, new RespuestaDTO("  ", null), RUT_ADMIN));
    }

    @Test
    void resolveReopen() {
        Ticket t = ticket(8L, EstadoTicket.EN_PROCESO);
        when(ticketRepository.findById(8L)).thenReturn(Optional.of(t));
        when(ticketRepository.save(any(Ticket.class))).thenAnswer(i -> i.getArgument(0));

        TicketRespuestaDTO resuelto = ticketService.actualizarEstado(8L, EstadoTicket.RESUELTO, RUT_ADMIN);
        assertNotNull(resuelto.getFechaResolucion());

        TicketRespuestaDTO reabierto = ticketService.actualizarEstado(8L, EstadoTicket.ABIERTO, RUT_ADMIN);
        assertNull(reabierto.getFechaResolucion());
    }

    @Test
    void sameStatus() {
        when(ticketRepository.findById(8L)).thenReturn(Optional.of(ticket(8L, EstadoTicket.ABIERTO)));

        assertThrows(ResponseStatusException.class,
                () -> ticketService.actualizarEstado(8L, EstadoTicket.ABIERTO, RUT_ADMIN));
    }

    @Test
    void deleteNoPermission() {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso"))
                .when(usuariosClient).exigirPermiso(RUT_CLIENTE, Permisos.GESTIONAR_SOPORTE);

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> ticketService.eliminarTicket(1L, RUT_CLIENTE));

        assertEquals(HttpStatus.FORBIDDEN, e.getStatusCode());
        verify(ticketRepository, never()).delete(any());
    }

    @Test
    void notFound404() {
        when(ticketRepository.findById(99L)).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> ticketService.obtenerDetalle(99L, RUT_ADMIN));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
}
