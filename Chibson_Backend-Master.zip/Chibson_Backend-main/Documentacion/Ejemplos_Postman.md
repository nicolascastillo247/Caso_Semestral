# Ejemplos para Postman

Importa `Documentacion/Chibson.postman_collection.json` (o la colección de cada microservicio, que está en su carpeta). La colección completa tiene una carpeta por servicio y las variables ya cargadas (`usuarios`, `productos`, `ventas`, `soporte`, `contenido`, `informes`, `gateway`, `rutAdmin`, etc.).

Antes de empezar: MySQL encendido en XAMPP y los servicios arriba (`iniciar-todo.ps1`). Las bases se crean solas.

## 1. Iniciar sesión

`POST http://localhost:8081/api/auth/login`

```json
{
  "correo": "admin@chibson.cl",
  "password": "Admin1234"
}
```

Responde 200 con el RUT, el rol, los permisos y un `token`. El administrador `12345678-5` se crea al arrancar ms-usuarios.

## 2. Cómo decir quién llama

| Llamando a… | Encabezado |
|---|---|
| El puerto del microservicio (8081 a 8086) | `X-Rut-Usuario: 12345678-5` |
| El gateway (8080) | `Authorization: Bearer <token del login>` |

El gateway borra cualquier `X-Rut-Usuario` que venga del cliente y lo arma él a partir del token. En la carpeta "API Gateway" el login guarda el token en la variable `{{token}}` automáticamente.

## 3. Crear un producto

`POST http://localhost:8082/api/productos` con `X-Rut-Usuario: 12345678-5`

```json
{
  "modelo": "Les Paul Standard",
  "marca": "Epiphone",
  "descripcion": "Guitarra eléctrica.",
  "precio": 800000,
  "categoria": "GUITARRA",
  "imagenUrl": "img/lespaul.png",
  "stockDisponible": 5,
  "stockMinimo": 2
}
```

Responde 201. El SKU (por ejemplo `GTR-0001`) lo genera el servicio.

## 4. Cómo se ven las respuestas (HATEOAS)

Un recurso trae sus datos y un bloque `_links`:

```json
{
  "sku": "GTR-0001",
  "modelo": "Les Paul Standard",
  "...": "...",
  "_links": {
    "self":      { "href": "http://localhost:8082/api/productos/GTR-0001" },
    "stock":     { "href": "http://localhost:8082/api/productos/GTR-0001/stock" },
    "resenas":   { "href": "http://localhost:8082/api/resenas/producto/GTR-0001" },
    "productos": { "href": "http://localhost:8082/api/productos" }
  }
}
```

Una lista viene dentro de `_embedded`, con el nombre de la colección:

```json
{
  "_embedded": {
    "productos": [ { "sku": "GTR-0001", "...": "...", "_links": { "...": "..." } } ]
  },
  "_links": { "self": { "href": "http://localhost:8082/api/productos" } }
}
```

Si la lista está vacía no aparece `_embedded`. Si la petición pasa por el gateway, los enlaces usan la dirección del gateway (`localhost:8080`) gracias a `server.forward-headers-strategy=framework`.

## 5. Comprar

`POST http://localhost:8083/api/pedidos/checkout` con el `X-Rut-Usuario` de un cliente registrado

```json
{
  "items": [ { "sku": "GTR-0001", "cantidad": 2 } ],
  "metodoPago": "TRANSFERENCIA",
  "usarDireccionDistinta": false
}
```

201 si el pago se aprueba (descuenta stock en ms-productos), 402 si se rechaza y 409 si no hay stock.

## 6. Crear un ticket

`POST http://localhost:8084/api/tickets` con el `X-Rut-Usuario` del cliente

```json
{
  "asunto": "Mi pedido no ha llegado",
  "categoria": "DESPACHO",
  "descripcion": "Compré una guitarra hace 8 días y sigue en estado ENVIADO.",
  "adjuntoUrl": "img/comprobante.png"
}
```

## 7. Códigos de error

| Código | Cuándo |
|---|---|
| 400 | Faltan datos o no son válidos (el mensaje dice cuál) |
| 401 | No hay sesión (falta `X-Rut-Usuario` o el token) |
| 403 | El usuario no tiene el permiso |
| 404 | No existe |
| 409 | Conflicto: sin stock, producto con pedidos, etc. |

## 8. Swagger

Cada microservicio tiene su documentación interactiva en `http://localhost:<puerto>/swagger-ui.html` (8081 a 8086). Desde ahí también se pueden probar los endpoints.
