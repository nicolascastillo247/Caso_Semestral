# Puertos y rutas

Todas las rutas se pueden llamar directo al puerto del microservicio o por el gateway en `http://localhost:8080` (misma ruta).

"Sesión: Sí" significa que el endpoint necesita saber quién llama: directo al puerto se manda el encabezado `X-Rut-Usuario`; por el gateway se manda `Authorization: Bearer <token>` (el token lo entrega el login).

| Servicio | Puerto | Base de datos (MySQL) | Swagger |
|---|---|---|---|
| gateway | 8080 | — | — |
| ms-usuarios | 8081 | chibson_usuarios | http://localhost:8081/swagger-ui.html |
| ms-productos | 8082 | chibson_productos | http://localhost:8082/swagger-ui.html |
| ms-ventas | 8083 | chibson_ventas | http://localhost:8083/swagger-ui.html |
| ms-soporte | 8084 | chibson_soporte | http://localhost:8084/swagger-ui.html |
| ms-contenido | 8085 | chibson_contenido | http://localhost:8085/swagger-ui.html |
| ms-informes | 8086 | — (en memoria) | http://localhost:8086/swagger-ui.html |

## ms-usuarios (8081)

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/auth/registro` | Registra un cliente nuevo | No |
| POST | `/api/auth/login` | Inicia sesión con correo y contraseña; entrega el token | No |
| POST | `/api/auth/recuperar` | Recupera la contraseña con el RUT y el correo | No |
| PUT | `/api/auth/password` | Cambia la contraseña del usuario con sesión | Sí |
| POST | `/api/notificaciones` | Crea un aviso para un usuario (uso interno de otros microservicios) | No |
| GET | `/api/notificaciones` | Avisos del usuario con sesión, del más nuevo al más antiguo | Sí |
| PATCH | `/api/notificaciones/{id}/leida` | Marca un aviso como leído | Sí |
| POST | `/api/acciones` | Registra una acción (uso interno de otros microservicios) | No |
| GET | `/api/acciones` | Lista el historial con filtros por texto, tipo, administrador y fechas | Sí |
| GET | `/api/acciones/{id}` | Detalle de una acción con sus cambios | Sí |
| GET | `/api/acciones/administrador/{rut}` | Acciones de un administrador | Sí |
| GET | `/api/roles` | Lista los roles con sus permisos | Sí |
| GET | `/api/roles/permisos` | Lista todos los permisos disponibles | Sí |
| PUT | `/api/roles/{idRol}/permisos` | Reemplaza los permisos de un rol | Sí |
| GET | `/api/roles/verificar` | Indica si un usuario tiene un permiso (uso interno de otros microservicios) | No |
| GET | `/api/usuarios/perfil` | Datos de Mi perfil | Sí |
| PUT | `/api/usuarios/perfil` | Actualiza los datos de Mi perfil | Sí |
| GET | `/api/usuarios/{rut}/datos` | Datos públicos de un usuario (uso interno de ventas y soporte) | No |
| GET | `/api/usuarios/registrados/contar` | Cuenta los clientes registrados entre dos fechas (uso interno de ms-informes) | No |
| GET | `/api/usuarios` | Lista los usuarios con filtros por rol, estado y texto | Sí |
| GET | `/api/usuarios/{rut}` | Busca un usuario por RUT | Sí |
| POST | `/api/usuarios` | Crea un usuario desde el panel | Sí |
| PUT | `/api/usuarios/{rut}` | Edita un usuario | Sí |
| PATCH | `/api/usuarios/{rut}/rol` | Asigna un rol a un usuario | Sí |
| PATCH | `/api/usuarios/{rut}/desactivar` | Desactiva un usuario | Sí |
| PATCH | `/api/usuarios/{rut}/reactivar` | Reactiva un usuario | Sí |
| DELETE | `/api/usuarios/{rut}` | Elimina un usuario sin pedidos | Sí |

## ms-productos (8082)

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| GET | `/api/productos` | Catálogo: lista los productos activos | No |
| GET | `/api/productos/{sku}` | Detalle de un producto activo | No |
| GET | `/api/productos/categorias` | Lista las categorías disponibles | No |
| GET | `/api/productos/admin` | Lista todos los productos con filtros (administración) | Sí |
| GET | `/api/productos/admin/{sku}` | Busca un producto por SKU, aunque esté desactivado (administración) | Sí |
| POST | `/api/productos` | Crea un producto | Sí |
| PUT | `/api/productos/{sku}` | Edita un producto | Sí |
| PATCH | `/api/productos/{sku}/desactivar` | Desactiva un producto (deja de verse en el catálogo) | Sí |
| PATCH | `/api/productos/{sku}/reactivar` | Reactiva un producto | Sí |
| DELETE | `/api/productos/{sku}` | Elimina un producto sin pedidos asociados | Sí |
| POST | `/api/productos/{sku}/ficha-tecnica` | Agrega la ficha técnica a un producto | Sí |
| PUT | `/api/productos/{sku}/ficha-tecnica` | Edita la ficha técnica de un producto | Sí |
| POST | `/api/resenas` | Crea una reseña de un producto comprado | Sí |
| GET | `/api/resenas/producto/{sku}` | Reseñas aprobadas de un producto con su promedio | No |
| GET | `/api/resenas/admin` | Lista todas las reseñas con filtros (administración) | Sí |
| PATCH | `/api/resenas/{id}/moderar` | Aprueba o rechaza una reseña | Sí |
| PATCH | `/api/resenas/{id}/ocultar` | Oculta una reseña | Sí |
| PUT | `/api/resenas/{id}/respuesta` | Responde una reseña | Sí |
| DELETE | `/api/resenas/{id}` | Elimina una reseña | Sí |
| GET | `/api/productos/{sku}/stock` | Consulta el stock de un producto | No |
| POST | `/api/productos/{sku}/descontar` | Descuenta stock por una venta (uso interno de ms-ventas) | No |
| POST | `/api/productos/{sku}/reponer` | Repone stock por cancelación o devolución (uso interno de ms-ventas) | No |
| GET | `/api/productos/bajo-stock` | Productos activos con stock bajo (uso interno de ms-informes) | No |

## ms-ventas (8083)

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/devoluciones` | El cliente solicita una devolución | Sí |
| GET | `/api/devoluciones/mis-devoluciones` | Devoluciones del cliente que hace la petición | Sí |
| GET | `/api/devoluciones` | Lista las devoluciones, opcionalmente por estado (administración) | Sí |
| GET | `/api/devoluciones/pendientes/contar` | Cuenta las devoluciones pendientes (uso interno de ms-informes) | No |
| GET | `/api/devoluciones/{numero}` | Detalle de una devolución | Sí |
| PATCH | `/api/devoluciones/{numero}/aprobar` | Aprueba una devolución y repone el stock | Sí |
| PATCH | `/api/devoluciones/{numero}/rechazar` | Rechaza una devolución con un motivo | Sí |
| PATCH | `/api/devoluciones/{numero}/reembolsar` | Marca como reembolsada una devolución aprobada | Sí |
| POST | `/api/pedidos/checkout` | Compra el carrito: 201 si el pago se aprueba, 402 si se rechaza | Sí |
| POST | `/api/pedidos/{numero}/pagar` | Reintenta el pago de un pedido pendiente | Sí |
| GET | `/api/pedidos/mis-pedidos` | Pedidos del cliente que hace la petición | Sí |
| GET | `/api/pedidos/mis-pedidos/{numero}` | Detalle de un pedido del cliente | Sí |
| GET | `/api/pedidos` | Lista los pedidos, opcionalmente por estado (administración) | Sí |
| GET | `/api/pedidos/{numero}` | Detalle de un pedido (administración) | Sí |
| PATCH | `/api/pedidos/{numero}/estado` | Cambia el estado de un pedido | Sí |
| PATCH | `/api/pedidos/{numero}/cancelar` | Cancela un pedido con un motivo y repone el stock | Sí |
| DELETE | `/api/pedidos/{numero}` | Elimina un pedido | Sí |
| GET | `/api/pedidos/cliente/{rut}/existe` | Indica si un cliente tiene pedidos (uso interno de ms-usuarios) | No |
| GET | `/api/pedidos/producto/{sku}/existe` | Indica si un producto tiene pedidos (uso interno de ms-productos) | No |
| GET | `/api/pedidos/cliente/{rut}/recibio/{sku}` | Indica si un cliente recibió un producto (uso interno de ms-productos) | No |
| GET | `/api/pedidos/resumen` | Resumen de pedidos entre fechas (uso interno de ms-informes) | No |
| GET | `/api/ventas` | Lista las ventas con filtros por texto, método de pago y fechas | Sí |
| GET | `/api/ventas/{numero}` | Detalle de una venta | Sí |

## ms-soporte (8084)

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/tickets` | El cliente crea un ticket | Sí |
| GET | `/api/tickets/mis-tickets` | Tickets del cliente que hace la petición | Sí |
| GET | `/api/tickets/mis-tickets/{numero}` | Detalle de un ticket del cliente con sus respuestas | Sí |
| PATCH | `/api/tickets/mis-tickets/{numero}/cerrar` | El cliente cierra un ticket resuelto y lo califica | Sí |
| GET | `/api/tickets` | Lista todos los tickets, opcionalmente por estado (administración) | Sí |
| GET | `/api/tickets/{numero}` | Detalle de un ticket (administración) | Sí |
| POST | `/api/tickets/{numero}/respuestas` | Responde un ticket | Sí |
| PATCH | `/api/tickets/{numero}/estado` | Cambia el estado de un ticket | Sí |
| DELETE | `/api/tickets/{numero}` | Elimina un ticket | Sí |
| GET | `/api/tickets/abiertos/contar` | Cuenta los tickets sin resolver (uso interno de ms-informes) | No |

## ms-contenido (8085)

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| GET | `/api/institucional` | Obtiene la información institucional | No |
| PUT | `/api/institucional` | Crea o actualiza la información institucional | Sí |
| GET | `/api/noticias/publicadas` | Lista las noticias publicadas | No |
| GET | `/api/noticias/publicadas/{id}` | Detalle de una noticia publicada | No |
| GET | `/api/noticias` | Lista todas las noticias con filtros (administración) | Sí |
| GET | `/api/noticias/{id}` | Busca una noticia por id (administración) | Sí |
| POST | `/api/noticias` | Crea una noticia como publicada o borrador | Sí |
| PUT | `/api/noticias/{id}` | Edita una noticia | Sí |
| PATCH | `/api/noticias/{id}/activar` | Publica una noticia | Sí |
| PATCH | `/api/noticias/{id}/desactivar` | Oculta una noticia | Sí |
| DELETE | `/api/noticias/{id}` | Elimina una noticia | Sí |

## ms-informes (8086)

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/reportes` | Genera un reporte manual | Sí |
| GET | `/api/reportes` | Lista los reportes con filtros por tipo, origen y fechas | Sí |
| GET | `/api/reportes/{id}` | Detalle de un reporte | Sí |
| DELETE | `/api/reportes/{id}` | Elimina un reporte | Sí |
