# Cambios sobre la versión original

## 1. Puertos según el diagrama de arquitectura
| Servicio | Antes | Ahora |
|---|---|---|
| gateway | 8088 | **8080** |
| productos | 8087 | **8082** |

Se actualizaron `application.yml` del gateway, `application.properties` de productos, ventas e informes (URL de ms-productos) y las colecciones de Postman.

## 2. ms-informes sin base de datos propia
- Se quitaron JPA, H2 y MySQL del `pom.xml` y la base `chibson_informes`.
- `Reporte` y `FilaReporte` ya no son entidades; `ReporteRepository` guarda los reportes en memoria.
- Los reportes se pierden al reiniciar, pero los automáticos (semanal y mensual) se vuelven a generar al arrancar.

## 3. Seguridad
- **Contraseñas con hash** (PBKDF2-HMAC-SHA256, sal aleatoria, 120.000 iteraciones) en `PasswordHasher`. Se aplica al registrar, crear usuario, recuperar, cambiar contraseña y al admin inicial. Las contraseñas antiguas sin hash siguen funcionando para no bloquear cuentas.
- **Token firmado**: `POST /api/auth/login` ahora devuelve `token` (HMAC-SHA256, 8 horas).
- **Gateway**: `AutenticacionFilter` valida `Authorization: Bearer <token>`, borra cualquier `X-Rut-Usuario` que mande el cliente y pone el RUT del token. Token inválido o vencido: 401.
- El secreto (`seguridad.token.secreto`) está en `usuarios` y en `gateway`; deben ser iguales. Cámbielo antes de usarlo fuera del curso.
- **Frontend**: guardar `token` del login y enviar `Authorization: Bearer <token>` (ya no `X-Rut-Usuario`) cuando llame al gateway.
- Limitación: llamando directo a un microservicio (por ejemplo desde Postman en su puerto) se sigue pudiendo mandar `X-Rut-Usuario`.

## 4. Pruebas (JUnit 5 + Mockito + MockMvc + H2, no necesitan MySQL ni otros servicios)
Misma organización que el proyecto de referencia: tres tipos de prueba, cada uno en su subpaquete de `src/test/java/chibson/<módulo>/`.

| Tipo | Paquete | Qué prueba | Herramientas |
|---|---|---|---|
| Servicio | `service/` | Lógica de negocio aislada, con repositorios y clientes simulados | JUnit 5 + Mockito |
| Cliente | `client/` | Llamadas a otros microservicios, con `RestTemplate` simulado | JUnit 5 + Mockito |
| Controlador | `controller/*ControllerTest` | Endpoints, códigos HTTP y JSON, un archivo por controlador | `@WebMvcTest` + `MockMvc` + `@MockitoBean` |
| Integración | `controller/*ControllerIT` | Controlador, servicio, repositorio y base H2 en memoria, con otros microservicios simulados | `@SpringBootTest` + `MockMvc` + H2 |

- Las pruebas usan el perfil `test` (`@ActiveProfiles("test")`, `src/test/resources/application-test.properties`).
- `LimpiezaBaseDatos` (en `src/test/java/chibson/<módulo>/`) vacía la base H2 antes de cada prueba de integración.
- Los `*IT` están incluidos en `mvn test` (plugin Surefire en el `pom.xml`).
- `gateway` e `informes` no tienen base de datos, por eso no llevan `*ControllerIT`.

Ejecutar los de un módulo (sin levantar Spring ni la base):

```
cd usuarios
.\mvnw test -Dtest="*ServiceTest,PasswordHasherTest,ValidacionesTest,TokenServiceTest"
```

Los `*ApplicationTests` (`@SpringBootTest`) usan H2 y también pasan sin MySQL; en informes y gateway no hay base.

## No se tocó
- Stock dentro de `Producto` (sin clase `Inventario`), como se pidió dejarlo.

## 5. Cobertura de pruebas (JaCoCo)
- Cada `pom.xml` incluye `jacoco-maven-plugin` 0.8.14 (compatible con Java 25).
- Cada módulo tiene `lombok.config` con `lombok.addLombokGeneratedAnnotation = true`, para que los getters/setters que genera Lombok no cuenten como código sin probar.
- Ejecutar: `.\mvnw clean test` y abrir `target\site\jacoco\index.html`.
- En VS Code: panel Pruebas → ejecutar con cobertura todos los módulos a la vez; el % aparece en el Explorador. No mezclar con `mvnw` sin borrar antes las carpetas `target`, porque los dos compilan en la misma carpeta.

## Versión de Java
- Los `pom.xml` compilan con `java.version` 25. Si VS Code marca error en `@AllArgsConstructor` o las pruebas fallan con `VerifyError: Constructor must call super() or this() before return`, la causa es la extensión "Lombok Annotations Support for VS Code": hay que desinstalarla (la extensión Java de Red Hat ya trae Lombok), borrar las carpetas `target` y ejecutar "Java: Clean Java Language Server Workspace".

## 6. HATEOAS, Swagger, scripts y documentación (como el proyecto de referencia)
- **HATEOAS** (`spring-boot-starter-hateoas`): los controllers devuelven `EntityModel` (un recurso con `_links`) y `CollectionModel` (listas dentro de `_embedded`). Los nombres de las listas se fijan con `@Relation` en cada DTO o entidad (`productos`, `pedidos`, `tickets`, etc.).
- Los endpoints internos entre microservicios (contar, existe, verificar, `/{rut}/datos`, stock, bajo-stock, resumen) y las listas fijas (categorías, permisos) siguen respondiendo JSON simple, para no romper los `RestTemplate`.
- **Frontend:** las listas ahora vienen en `respuesta._embedded.<nombre>` en vez de un arreglo directo. Las páginas que recorren listas tienen que leer ese campo (si la lista está vacía, `_embedded` no viene).
- `server.forward-headers-strategy=framework` en cada servicio, para que los enlaces usen la dirección del gateway cuando la petición pasa por él.
- **Swagger** (`springdoc-openapi-starter-webmvc-ui` 3.1.0, compatible con Spring Boot 4.1): `@Tag` en cada controller, `@Operation` en cada endpoint y `config/OpenApiConfig` con el título de cada servicio. Se abre en `http://localhost:<puerto>/swagger-ui.html`.
- Pruebas: los `*ControllerTest` y `*ControllerIT` revisan las listas en `$._embedded.<nombre>` y algunos enlaces `_links`.
- Scripts `iniciar-todo.ps1`, `detener-todo.ps1`, `verificar-todo.ps1` y tareas en `.vscode/tasks.json`.
- `README.md` general y uno por microservicio; carpeta `Documentacion` con `Puertos_y_Rutas.md`, `Ejemplos_Postman.md` y la colección de Postman unificada.

## 7. Mensajes de error
- En Spring Boot 4 la propiedad `server.error.include-message` pasó a llamarse `spring.web.error.include-message`. Con el nombre antiguo se ignoraba y las respuestas de error no traían el campo `message`. Se renombró en los `application.properties` (main y test).
- Ahora un error responde, por ejemplo: `{"status":403,"error":"Forbidden","message":"No tiene permiso para realizar esta acción.","path":"/api/usuarios"}`. ms-ventas también vuelve a mostrar el mensaje real que devuelve ms-productos (por ejemplo, stock insuficiente).

## 8. Limpieza final
- Se quitaron los comentarios del código (Java, properties, yml, pom y scripts).
- Las colecciones de Postman ya no indican la HU de cada petición.
