# ms-productos

Catálogo de instrumentos, administración de productos y fichas técnicas, stock y reseñas.

- **Puerto:** 8082
- **Base de datos:** `chibson_productos` en MySQL (se crea sola al arrancar)
- **Swagger:** http://localhost:8082/swagger-ui.html
- **Llama a:** ms-usuarios (permisos e historial) y ms-ventas (si un producto tiene pedidos y si un cliente recibió el producto que quiere reseñar).
- **Lo usan:** ms-ventas (precio y stock, descontar y reponer stock) y ms-informes (productos con stock bajo).

## Ejecutar

```
.\mvnw spring-boot:run
```

O todo el backend junto con `iniciar-todo.ps1` desde la carpeta raíz.

## Pruebas

```
.\mvnw clean test
```

El informe de cobertura queda en `target/site/jacoco/index.html`.

Las pruebas no usan MySQL: los `*ControllerIT` levantan la aplicación completa con H2 en memoria (perfil `test`) y limpian las tablas antes de cada prueba con `LimpiezaBaseDatos`. Los servicios externos se reemplazan con `@MockitoBean`.

| Tipo | Clases | Qué prueba |
|---|---|---|
| Servicio | `service/*Test` | Reglas de negocio con Mockito, sin Spring. |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest`: rutas, códigos HTTP, JSON y enlaces HATEOAS con el servicio simulado. |
| Integración | `controller/*ControllerIT` | `@SpringBootTest` + MockMvc + H2: flujo completo hasta la base de datos. |

## Endpoints

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| GET | `/api/productos` | Catálogo: lista los productos activos | No |
| GET | `/api/productos/{sku}` | Detalle de un producto activo | No |
| GET | `/api/productos/categorias` | Lista las categorías disponibles | No |
| GET | `/api/productos/admin` | Lista todos los productos con filtros (administración) | Sí |
| GET | `/api/productos/admin/{sku}` | Busca un producto por SKU, aunque esté desactivado (administración) | Sí |
| POST | `/api/productos` | Crea un producto | Sí |
| PUT | `/api/productos/{sku}` | Edita un producto | Sí |
| PATCH | `/api/productos/{sku}/desactivar` | Desactiva un producto (deja de verse en el catálogo) | Sí |
| PATCH | `/api/productos/{sku}/reactivar` | Reactiva un producto | Sí |
| DELETE | `/api/productos/{sku}` | Elimina un producto sin pedidos asociados | Sí |
| POST | `/api/productos/{sku}/ficha-tecnica` | Agrega la ficha técnica a un producto | Sí |
| PUT | `/api/productos/{sku}/ficha-tecnica` | Edita la ficha técnica de un producto | Sí |
| POST | `/api/resenas` | Crea una reseña de un producto comprado | Sí |
| GET | `/api/resenas/producto/{sku}` | Reseñas aprobadas de un producto con su promedio | No |
| GET | `/api/resenas/admin` | Lista todas las reseñas con filtros (administración) | Sí |
| PATCH | `/api/resenas/{id}/moderar` | Aprueba o rechaza una reseña | Sí |
| PATCH | `/api/resenas/{id}/ocultar` | Oculta una reseña | Sí |
| PUT | `/api/resenas/{id}/respuesta` | Responde una reseña | Sí |
| DELETE | `/api/resenas/{id}` | Elimina una reseña | Sí |
| GET | `/api/productos/{sku}/stock` | Consulta el stock de un producto | No |
| POST | `/api/productos/{sku}/descontar` | Descuenta stock por una venta (uso interno de ms-ventas) | No |
| POST | `/api/productos/{sku}/reponer` | Repone stock por cancelación o devolución (uso interno de ms-ventas) | No |
| GET | `/api/productos/bajo-stock` | Productos activos con stock bajo (uso interno de ms-informes) | No |

Las respuestas de un recurso traen `_links` (HATEOAS). Las listas vienen dentro de `_embedded`. Los endpoints de uso interno (contar, existe, verificar, datos, stock, resumen) responden JSON simple porque los consumen otros microservicios.

Colección de Postman: `chibson-productos.postman_collection.json` (en esta carpeta).
