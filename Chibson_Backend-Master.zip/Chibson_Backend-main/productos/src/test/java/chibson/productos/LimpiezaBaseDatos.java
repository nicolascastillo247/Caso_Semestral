package chibson.productos;

import chibson.productos.repository.ProductoRepository;
import chibson.productos.repository.ResenaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LimpiezaBaseDatos {
    @Autowired
    private ResenaRepository resenaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    public void limpiar() {
        resenaRepository.deleteAll();
        productoRepository.deleteAll();
    }
}
