package chibson.productos.controller;

import chibson.productos.LimpiezaBaseDatos;
import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.Producto;
import chibson.productos.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class StockControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String RUT = "12345678-5";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private ProductoRepository productoRepository;
    @MockitoBean
    private UsuariosClient usuariosClient;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Producto guardar(String sku, String modelo, EstadoProducto estado, int stock) {
        Producto p = new Producto();
        p.setSku(sku);
        p.setModelo(modelo);
        p.setMarca("Fender");
        p.setPrecio(750000);
        p.setCategoria(Categoria.GUITARRA);
        p.setEstado(estado);
        p.setImagenUrl("https://img/x.png");
        p.setStockDisponible(stock);
        p.setStockMinimo(5);
        return productoRepository.save(p);
    }

    @Test
    void queryStock() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);

        mockMvc.perform(get("/api/productos/GTR-0001/stock"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.stockDisponible").value(10))
                .andExpect(jsonPath("$.bajoStock").value(false));
        mockMvc.perform(get("/api/productos/GTR-9999/stock"))
                .andExpect(status().isNotFound());
    }

    @Test
    void discountStock() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);

        mockMvc.perform(post("/api/productos/GTR-0001/descontar").contentType(JSON)
                        .content("{\"cantidad\":4,\"numeroPedido\":7,\"rutResponsable\":\"12345678-5\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.stockDisponible").value(6));
        mockMvc.perform(get("/api/productos/GTR-0001/stock"))
                .andExpect(jsonPath("$.stockDisponible").value(6));
    }

    @Test
    void discountTooMuch409() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 3);

        mockMvc.perform(post("/api/productos/GTR-0001/descontar").contentType(JSON)
                        .content("{\"cantidad\":4,\"numeroPedido\":7}"))
                .andExpect(status().isConflict());
    }

    @Test
    void discountInvalidQuantity400() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 3);

        mockMvc.perform(post("/api/productos/GTR-0001/descontar").contentType(JSON)
                        .content("{\"cantidad\":0,\"numeroPedido\":7}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void restockReturnAndCancel() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 3);

        mockMvc.perform(post("/api/productos/GTR-0001/reponer").contentType(JSON)
                        .content("{\"cantidad\":2,\"numeroPedido\":7,\"tipo\":\"DEVOLUCION\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.stockDisponible").value(5));
        mockMvc.perform(post("/api/productos/GTR-0001/reponer").contentType(JSON)
                        .content("{\"cantidad\":1,\"numeroPedido\":8,\"tipo\":\"CANCELACION\"}"))
                .andExpect(jsonPath("$.stockDisponible").value(6));
        mockMvc.perform(post("/api/productos/GTR-0001/reponer").contentType(JSON)
                        .content("{\"cantidad\":1,\"numeroPedido\":8,\"tipo\":\"OTRO\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void lowStockList() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);
        guardar("GTR-0002", "Telecaster", EstadoProducto.ACTIVO, 2);
        guardar("GTR-0003", "Jazzmaster", EstadoProducto.INACTIVO, 0);

        mockMvc.perform(get("/api/productos/bajo-stock"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].sku").value("GTR-0002"));
    }
}
