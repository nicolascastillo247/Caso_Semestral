package chibson.productos.service;

import chibson.productos.client.UsuariosClient;
import chibson.productos.dto.MovimientoDTO;
import chibson.productos.dto.RegistroAccionDTO;
import chibson.productos.dto.StockDTO;
import chibson.productos.model.Producto;
import chibson.productos.repository.ProductoRepository;
import chibson.productos.service.StockService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StockServiceTest {
    @Mock
    private ProductoRepository productoRepository;
    @Mock
    private UsuariosClient usuariosClient;
    @InjectMocks
    private StockService stockService;

    private Producto producto(int stock, int minimo) {
        Producto p = new Producto();
        p.setSku("GTR-0001");
        p.setModelo("Stratocaster");
        p.setStockDisponible(stock);
        p.setStockMinimo(minimo);
        return p;
    }

    private MovimientoDTO movimiento(Integer cantidad, String tipo) {
        return new MovimientoDTO(cantidad, 10L, tipo, "11111111-1");
    }

    @Test
    void discountSubtracts() {
        Producto p = producto(10, 3);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));

        StockDTO stock = stockService.descontar("GTR-0001", movimiento(4, null));

        assertEquals(6, stock.getStockDisponible());
        assertEquals(6, p.getStockDisponible());
        verify(productoRepository).save(p);
        ArgumentCaptor<RegistroAccionDTO> accion = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(accion.capture());
        assertEquals("11111111-1", accion.getValue().getRutAdministrador());
        assertEquals("10", accion.getValue().getCambios().get(0).getValorAnterior());
        assertEquals("6", accion.getValue().getCambios().get(0).getValorNuevo());
    }

    @Test
    void discountTooMuch() {
        Producto p = producto(2, 1);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> stockService.descontar("GTR-0001", movimiento(3, null)));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
        assertEquals(2, p.getStockDisponible());
        verify(productoRepository, never()).save(any());
    }

    @Test
    void discountAll() {
        Producto p = producto(3, 1);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));

        StockDTO stock = stockService.descontar("GTR-0001", movimiento(3, null));

        assertEquals(0, stock.getStockDisponible());
        assertTrue(stock.getBajoStock());
    }

    @Test
    void invalidQuantity() {
        assertThrows(ResponseStatusException.class, () -> stockService.descontar("GTR-0001", movimiento(0, null)));
        assertThrows(ResponseStatusException.class, () -> stockService.descontar("GTR-0001", movimiento(-1, null)));
        assertThrows(ResponseStatusException.class, () -> stockService.descontar("GTR-0001", movimiento(null, null)));
        assertThrows(ResponseStatusException.class, () -> stockService.reponer("GTR-0001", movimiento(0, "DEVOLUCION")));
    }

    @Test
    void restockReturn() {
        Producto p = producto(5, 3);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));

        StockDTO stock = stockService.reponer("GTR-0001", movimiento(2, "DEVOLUCION"));

        assertEquals(7, stock.getStockDisponible());
        assertFalse(stock.getBajoStock());
    }

    @Test
    void restockCancel() {
        Producto p = producto(0, 3);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));

        assertEquals(1, stockService.reponer("GTR-0001", movimiento(1, "CANCELACION")).getStockDisponible());
    }

    @Test
    void restockInvalidType() {
        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> stockService.reponer("GTR-0001", movimiento(1, "REGALO")));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
        verify(productoRepository, never()).save(any());
    }

    @Test
    void noResponsible() {
        Producto p = producto(5, 1);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));

        stockService.descontar("GTR-0001", new MovimientoDTO(1, 11L, null, " "));

        ArgumentCaptor<RegistroAccionDTO> accion = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(accion.capture());
        assertEquals("SISTEMA", accion.getValue().getRutAdministrador());
    }

    @Test
    void notFound404() {
        when(productoRepository.findById("XXX-0000")).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> stockService.consultar("XXX-0000"));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void lowStockAtMinimum() {
        assertTrue(producto(5, 5).esBajoStock());
        assertTrue(producto(0, 5).estaAgotado());
        assertFalse(producto(6, 5).esBajoStock());
        assertFalse(producto(1, 5).estaAgotado());
    }
}
