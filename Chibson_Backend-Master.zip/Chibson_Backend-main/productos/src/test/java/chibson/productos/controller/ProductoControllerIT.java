package chibson.productos.controller;

import chibson.productos.LimpiezaBaseDatos;
import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.Producto;
import chibson.productos.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ProductoControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String RUT = "12345678-5";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private ProductoRepository productoRepository;
    @MockitoBean
    private UsuariosClient usuariosClient;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Producto guardar(String sku, String modelo, EstadoProducto estado, int stock) {
        Producto p = new Producto();
        p.setSku(sku);
        p.setModelo(modelo);
        p.setMarca("Fender");
        p.setPrecio(750000);
        p.setCategoria(Categoria.GUITARRA);
        p.setEstado(estado);
        p.setImagenUrl("https://img/x.png");
        p.setStockDisponible(stock);
        p.setStockMinimo(5);
        return productoRepository.save(p);
    }

    private static final String CUERPO = "{\"modelo\":\"Stratocaster\",\"marca\":\"Fender\",\"descripcion\":\"Eléctrica\",\"precio\":750000,"
            + "\"categoria\":\"GUITARRA\",\"imagenUrl\":\"https://img/strato.png\",\"stockDisponible\":10}";

    @Test
    void createGeneratesSku() throws Exception {
        mockMvc.perform(post("/api/productos").header("X-Rut-Usuario", RUT).contentType(JSON).content(CUERPO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.sku").value("GTR-0001"))
                .andExpect(jsonPath("$.estado").value("ACTIVO"));
        mockMvc.perform(post("/api/productos").header("X-Rut-Usuario", RUT).contentType(JSON).content(CUERPO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.sku").value("GTR-0002"));
    }

    @Test
    void createInvalidPrice400() throws Exception {
        mockMvc.perform(post("/api/productos").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content(CUERPO.replace("750000", "0")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("GESTIONAR_PRODUCTOS"));

        mockMvc.perform(post("/api/productos").header("X-Rut-Usuario", RUT).contentType(JSON).content(CUERPO))
                .andExpect(status().isForbidden());
    }

    @Test
    void publicCatalog() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);
        guardar("GTR-0002", "Telecaster", EstadoProducto.INACTIVO, 10);

        mockMvc.perform(get("/api/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.productos.length()").value(1))
                .andExpect(jsonPath("$._embedded.productos[0].sku").value("GTR-0001"));
        mockMvc.perform(get("/api/productos/GTR-0001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.modelo").value("Stratocaster"));
        mockMvc.perform(get("/api/productos/GTR-0002"))
                .andExpect(status().isNotFound());
        mockMvc.perform(get("/api/productos/categorias"))
                .andExpect(status().isOk());
    }

    @Test
    void adminListAndDetail() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);
        guardar("GTR-0002", "Telecaster", EstadoProducto.INACTIVO, 10);

        mockMvc.perform(get("/api/productos/admin").header("X-Rut-Usuario", RUT))
                .andExpect(jsonPath("$._embedded.productos.length()").value(2));
        mockMvc.perform(get("/api/productos/admin").header("X-Rut-Usuario", RUT).param("estado", "INACTIVO"))
                .andExpect(jsonPath("$._embedded.productos.length()").value(1));
        mockMvc.perform(get("/api/productos/admin").header("X-Rut-Usuario", RUT).param("texto", "strato"))
                .andExpect(jsonPath("$._embedded.productos.length()").value(1));
        mockMvc.perform(get("/api/productos/admin/GTR-0002").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.modelo").value("Telecaster"));
    }

    @Test
    void updateProduct() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);

        mockMvc.perform(put("/api/productos/GTR-0001").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content(CUERPO.replace("750000", "800000")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.precio").value(800000));
    }

    @Test
    void deactivateAndReactivate() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);

        mockMvc.perform(patch("/api/productos/GTR-0001/desactivar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("INACTIVO"));
        mockMvc.perform(patch("/api/productos/GTR-0001/desactivar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch("/api/productos/GTR-0001/reactivar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("ACTIVO"));
    }

    @Test
    void deleteWithoutOrders() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);
        when(ventasClient.productoTienePedidos("GTR-0001")).thenReturn(false);

        mockMvc.perform(delete("/api/productos/GTR-0001").header("X-Rut-Usuario", RUT))
                .andExpect(status().isNoContent());
        mockMvc.perform(get("/api/productos/admin/GTR-0001").header("X-Rut-Usuario", RUT))
                .andExpect(status().isNotFound());
    }

    @Test
    void deleteWithOrders409() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);
        when(ventasClient.productoTienePedidos("GTR-0001")).thenReturn(true);

        mockMvc.perform(delete("/api/productos/GTR-0001").header("X-Rut-Usuario", RUT))
                .andExpect(status().isConflict());
    }

    @Test
    void specSheetAddAndEdit() throws Exception {
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);

        mockMvc.perform(put("/api/productos/GTR-0001/ficha-tecnica").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"texto\":\"color:rojo\"}"))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/productos/GTR-0001/ficha-tecnica").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"texto\":\"color:rojo;peso:3kg\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.especificaciones.length()").value(2));
        mockMvc.perform(post("/api/productos/GTR-0001/ficha-tecnica").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"texto\":\"a:b\"}"))
                .andExpect(status().isConflict());
        mockMvc.perform(put("/api/productos/GTR-0001/ficha-tecnica").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"texto\":\"color:azul\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fichaTecnica").value("color:azul"));
    }
}
