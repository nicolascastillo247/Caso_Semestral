package chibson.productos.service;

import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.dto.ProductoDTO;
import chibson.productos.dto.ProductoRespuestaDTO;
import chibson.productos.dto.RegistroAccionDTO;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.Producto;
import chibson.productos.repository.ProductoRepository;
import chibson.productos.service.ProductoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductoServiceExtraTest {
    private static final String ADMIN = "12345678-5";
    private static final String SKU = "GTR-0001";

    @Mock
    private ProductoRepository repo;
    @Mock
    private UsuariosClient usuariosClient;
    @Mock
    private VentasClient ventasClient;
    @InjectMocks
    private ProductoService service;

    private Producto producto(String sku, String modelo, EstadoProducto estado, Categoria cat, int stock, int min) {
        Producto p = new Producto();
        p.setSku(sku);
        p.setModelo(modelo);
        p.setMarca("Fender");
        p.setPrecio(1000);
        p.setCategoria(cat);
        p.setEstado(estado);
        p.setImagenUrl("img.png");
        p.setStockDisponible(stock);
        p.setStockMinimo(min);
        return p;
    }

    private Producto base() {
        return producto(SKU, "Strato", EstadoProducto.ACTIVO, Categoria.GUITARRA, 10, 5);
    }

    private ProductoDTO dto() {
        return new ProductoDTO("Strato", "Fender", null, 1000, Categoria.GUITARRA, "img.png", 10, 5, true);
    }

    private void expect400(Runnable r) {
        ResponseStatusException e = assertThrows(ResponseStatusException.class, r::run);
        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void listActive() {
        when(repo.findByEstadoOrderByModeloAsc(EstadoProducto.ACTIVO)).thenReturn(List.of(base()));

        assertEquals(1, service.listarActivos().size());
    }

    @Test
    void getActive() {
        when(repo.findBySkuAndEstado(SKU, EstadoProducto.ACTIVO)).thenReturn(Optional.of(base()));

        assertEquals(SKU, service.obtenerActivo(SKU).getSku());
    }

    @Test
    void getActiveNotFound() {
        when(repo.findBySkuAndEstado("X", EstadoProducto.ACTIVO)).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> service.obtenerActivo("X"));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void listFilters() {
        Producto a = base();
        Producto b = producto("BAJ-0001", "Jazz Bass", EstadoProducto.INACTIVO, Categoria.BAJO, 1, 5);
        when(repo.findAllByOrderByModeloAsc()).thenReturn(List.of(a, b));

        assertEquals(2, service.listarProductos(null, null, null).size());
        assertEquals(1, service.listarProductos(EstadoProducto.INACTIVO, null, null).size());
        assertEquals(1, service.listarProductos(null, Categoria.GUITARRA, null).size());
        assertEquals(1, service.listarProductos(null, null, " jazz ").size());
        assertEquals(1, service.listarProductos(null, null, "gtr-").size());
        assertEquals(0, service.listarProductos(null, null, "zzz").size());
    }

    @Test
    void lowStock() {
        Producto bajo = producto("GTR-0002", "A", EstadoProducto.ACTIVO, Categoria.GUITARRA, 1, 5);
        Producto masBajo = producto("GTR-0003", "B", EstadoProducto.ACTIVO, Categoria.GUITARRA, 0, 5);
        Producto inactivo = producto("GTR-0004", "C", EstadoProducto.INACTIVO, Categoria.GUITARRA, 0, 5);
        when(repo.findAll()).thenReturn(List.of(bajo, base(), inactivo, masBajo));

        List<ProductoRespuestaDTO> lista = service.listarBajoStock();

        assertEquals(2, lista.size());
        assertEquals("GTR-0003", lista.get(0).getSku());
        assertTrue(lista.get(0).isAgotado());
    }

    @Test
    void reactivate() {
        Producto p = producto(SKU, "Strato", EstadoProducto.INACTIVO, Categoria.GUITARRA, 10, 5);
        when(repo.findById(SKU)).thenReturn(Optional.of(p));
        when(repo.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(EstadoProducto.ACTIVO, service.reactivarProducto(SKU, ADMIN).getEstado());
        expect400(() -> service.reactivarProducto(SKU, ADMIN));
    }

    @Test
    void updateAllChanges() {
        Producto p = base();
        when(repo.findById(SKU)).thenReturn(Optional.of(p));
        when(repo.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));
        ProductoDTO d = new ProductoDTO(" Les Paul ", " Gibson ", "Nueva", 2000, Categoria.BAJO, " new.png ", 3, 1, null);

        ProductoRespuestaDTO r = service.editarProducto(SKU, d, ADMIN);

        assertEquals("Les Paul", r.getModelo());
        assertEquals("Gibson", r.getMarca());
        ArgumentCaptor<RegistroAccionDTO> cap = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(cap.capture());
        assertEquals(8, cap.getValue().getCambios().size());
    }

    @Test
    void updateKeepsMinAndNoChanges() {
        Producto p = base();
        when(repo.findById(SKU)).thenReturn(Optional.of(p));
        when(repo.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));
        ProductoDTO d = dto();
        d.setStockMinimo(null);

        ProductoRespuestaDTO r = service.editarProducto(SKU, d, ADMIN);

        assertEquals(5, r.getStockMinimo());
        ArgumentCaptor<RegistroAccionDTO> cap = ArgumentCaptor.forClass(RegistroAccionDTO.class);
        verify(usuariosClient).registrarAccion(cap.capture());
        assertTrue(cap.getValue().getCambios().isEmpty());
    }

    @Test
    void updateNegativeValues() {
        when(repo.findById(SKU)).thenReturn(Optional.of(base()));
        ProductoDTO d = dto();
        d.setStockMinimo(-1);

        expect400(() -> service.editarProducto(SKU, d, ADMIN));
    }

    @Test
    void createNullStock() {
        ProductoDTO d = dto();
        d.setStockDisponible(null);

        expect400(() -> service.crearProducto(d, ADMIN));
    }

    @Test
    void createNegativeMin() {
        ProductoDTO d = dto();
        d.setStockMinimo(-2);

        expect400(() -> service.crearProducto(d, ADMIN));
    }

    @Test
    void createMissingCategory() {
        ProductoDTO d = dto();
        d.setCategoria(null);

        expect400(() -> service.crearProducto(d, ADMIN));
    }

    @Test
    void createNullPrice() {
        ProductoDTO d = dto();
        d.setPrecio(null);

        expect400(() -> service.crearProducto(d, ADMIN));
    }

    @Test
    void skuIgnoresNonNumeric() {
        when(repo.findBySkuStartingWith("GTR-"))
                .thenReturn(List.of(producto("GTR-ABCD", "x", EstadoProducto.ACTIVO, Categoria.GUITARRA, 1, 1)));
        when(repo.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals("GTR-0001", service.crearProducto(dto(), ADMIN).getSku());
    }

    @Test
    void addSpecSheet() {
        Producto p = base();
        when(repo.findById(SKU)).thenReturn(Optional.of(p));
        when(repo.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        ProductoRespuestaDTO r = service.agregarFichaTecnica(SKU, "color:rojo; peso:3kg;", ADMIN);

        assertEquals("color:rojo; peso:3kg", r.getFichaTecnica());
        assertEquals(2, r.getEspecificaciones().size());
    }

    @Test
    void addSpecSheetTwice() {
        Producto p = base();
        p.setFichaTecnica("color:rojo");
        when(repo.findById(SKU)).thenReturn(Optional.of(p));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> service.agregarFichaTecnica(SKU, "a:b", ADMIN));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }

    @Test
    void editSpecSheet() {
        Producto p = base();
        p.setFichaTecnica("color:rojo");
        when(repo.findById(SKU)).thenReturn(Optional.of(p));
        when(repo.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals("color:azul", service.editarFichaTecnica(SKU, "color:azul", ADMIN).getFichaTecnica());
    }

    @Test
    void editSpecSheetMissing() {
        when(repo.findById(SKU)).thenReturn(Optional.of(base()));

        expect400(() -> service.editarFichaTecnica(SKU, "a:b", ADMIN));
    }

    @Test
    void editSpecSheetInvalid() {
        Producto p = base();
        p.setFichaTecnica("color:rojo");
        when(repo.findById(SKU)).thenReturn(Optional.of(p));

        expect400(() -> service.editarFichaTecnica(SKU, "sin dos puntos", ADMIN));
    }

    @Test
    void responseWithoutSpecSheet() {
        assertNull(service.aRespuesta(base()).getFichaTecnica());
    }
}
