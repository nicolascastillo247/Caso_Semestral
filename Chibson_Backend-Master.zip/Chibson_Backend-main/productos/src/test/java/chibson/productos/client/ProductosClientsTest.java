package chibson.productos.client;

import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.dto.RegistroAccionDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductosClientsTest {
    @Mock
    private RestTemplate restTemplate;

    private UsuariosClient usuarios;
    private VentasClient ventas;

    @BeforeEach
    void setUp() {
        usuarios = new UsuariosClient(restTemplate, "http://localhost:8081");
        ventas = new VentasClient(restTemplate, "http://localhost:8083");
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    @Test
    void permissionNoRut401() {
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(" ", "X"))));
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(null, "X"))));
    }

    @Test
    void permissionGranted() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("1-9"), eq("P"))).thenReturn(true);

        assertDoesNotThrow(() -> usuarios.exigirPermiso(" 1-9 ", "P"));
    }

    @Test
    void permissionDenied403() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("1-9"), eq("P"))).thenReturn(false);

        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso("1-9", "P"))));
    }

    @Test
    void permissionDown503() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("1-9"), eq("P")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso("1-9", "P"))));
    }

    @Test
    void getName() {
        when(restTemplate.getForObject(anyString(), eq(Map.class), eq("1-9")))
                .thenReturn(Map.of("nombres", "Ana", "primerApellido", "Pérez"));

        assertEquals("Ana Pérez", usuarios.obtenerNombre(" 1-9 "));
    }

    @Test
    void getNameNoRut401() {
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerNombre(null))));
    }

    @Test
    void getNameNull401() {
        when(restTemplate.getForObject(anyString(), eq(Map.class), eq("1-9"))).thenReturn(null);

        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerNombre("1-9"))));
    }

    @Test
    void getNameNotFound401() {
        when(restTemplate.getForObject(anyString(), eq(Map.class), eq("1-9")))
                .thenThrow(HttpClientErrorException.create(HttpStatus.NOT_FOUND, "nf", null, null, null));

        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerNombre("1-9"))));
    }

    @Test
    void getNameDown503() {
        when(restTemplate.getForObject(anyString(), eq(Map.class), eq("1-9")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerNombre("1-9"))));
    }

    @Test
    void logActionDown() {
        when(restTemplate.postForObject(anyString(), any(), eq(Void.class)))
                .thenThrow(new ResourceAccessException("caído"));

        assertDoesNotThrow(() -> usuarios.registrarAccion(new RegistroAccionDTO()));
    }

    @Test
    void logAction() {
        assertDoesNotThrow(() -> usuarios.registrarAccion(new RegistroAccionDTO()));
    }

    @Test
    void productHasOrders() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("GTR-0001"))).thenReturn(true);

        assertTrue(ventas.productoTienePedidos("GTR-0001"));
    }

    @Test
    void productNoOrders() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("GTR-0001"))).thenReturn(null);

        assertFalse(ventas.productoTienePedidos("GTR-0001"));
    }

    @Test
    void clientReceived() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("1-9"), eq("GTR-0001"))).thenReturn(true);

        assertTrue(ventas.clienteRecibioProducto("1-9", "GTR-0001"));
    }

    @Test
    void salesDown503() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq("GTR-0001")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> ventas.productoTienePedidos("GTR-0001"))));
    }
}
