package chibson.productos.controller;

import chibson.productos.dto.MovimientoDTO;
import chibson.productos.dto.ProductoRespuestaDTO;
import chibson.productos.dto.StockDTO;
import chibson.productos.service.ProductoService;
import chibson.productos.service.StockService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(StockController.class)
@ActiveProfiles("test")
class StockControllerTest {
    @MockitoBean
    private StockService stockService;
    @MockitoBean
    private ProductoService productoService;

    @Autowired
    private MockMvc mvc;

    @Test
    void getStock() throws Exception {
        when(stockService.consultar("GTR-0001")).thenReturn(new StockDTO("GTR-0001", 10, 5, false));

        mvc.perform(get("/api/productos/GTR-0001/stock"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.stockDisponible").value(10))
                .andExpect(jsonPath("$.bajoStock").value(false));
    }

    @Test
    void discount() throws Exception {
        when(stockService.descontar(eq("GTR-0001"), any(MovimientoDTO.class))).thenReturn(new StockDTO("GTR-0001", 8, 5, false));

        mvc.perform(post("/api/productos/GTR-0001/descontar").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"cantidad\":2,\"numeroPedido\":10,\"rutResponsable\":\"11111111-1\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.stockDisponible").value(8));
    }

    @Test
    void discountConflict409() throws Exception {
        when(stockService.descontar(eq("GTR-0001"), any(MovimientoDTO.class)))
                .thenThrow(new ResponseStatusException(HttpStatus.CONFLICT, "Stock insuficiente"));

        mvc.perform(post("/api/productos/GTR-0001/descontar").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"cantidad\":99}"))
                .andExpect(status().isConflict());
    }

    @Test
    void restock() throws Exception {
        when(stockService.reponer(eq("GTR-0001"), any(MovimientoDTO.class))).thenReturn(new StockDTO("GTR-0001", 12, 5, false));

        mvc.perform(post("/api/productos/GTR-0001/reponer").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"cantidad\":2,\"tipo\":\"DEVOLUCION\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.stockDisponible").value(12));
    }

    @Test
    void lowStock() throws Exception {
        ProductoRespuestaDTO p = new ProductoRespuestaDTO();
        p.setSku("GTR-0002");
        p.setEspecificaciones(new ArrayList<>());
        when(productoService.listarBajoStock()).thenReturn(List.of(p));

        mvc.perform(get("/api/productos/bajo-stock"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sku").value("GTR-0002"));
    }
}
