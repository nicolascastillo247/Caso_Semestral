package chibson.productos.service;

import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.dto.ProductoDTO;
import chibson.productos.dto.ProductoRespuestaDTO;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.Producto;
import chibson.productos.repository.ProductoRepository;
import chibson.productos.service.ProductoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {
    private static final String ADMIN = "12345678-5";

    @Mock
    private ProductoRepository productoRepository;
    @Mock
    private UsuariosClient usuariosClient;
    @Mock
    private VentasClient ventasClient;
    @InjectMocks
    private ProductoService productoService;

    private ProductoDTO datos() {
        return new ProductoDTO(" Stratocaster ", "Fender", "Guitarra eléctrica", 750000, Categoria.GUITARRA,
                "https://img/strato.png", 10, null, true);
    }

    private Producto existente(String sku, EstadoProducto estado) {
        Producto p = new Producto();
        p.setSku(sku);
        p.setModelo("Stratocaster");
        p.setMarca("Fender");
        p.setPrecio(750000);
        p.setCategoria(Categoria.GUITARRA);
        p.setEstado(estado);
        p.setImagenUrl("https://img/strato.png");
        p.setStockDisponible(10);
        p.setStockMinimo(5);
        return p;
    }

    @Test
    void firstSku() {
        when(productoRepository.findBySkuStartingWith("GTR-")).thenReturn(List.of());
        when(productoRepository.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        ProductoRespuestaDTO creado = productoService.crearProducto(datos(), ADMIN);

        assertEquals("GTR-0001", creado.getSku());
        assertEquals("Stratocaster", creado.getModelo());
    }

    @Test
    void nextSku() {
        when(productoRepository.findBySkuStartingWith("GTR-"))
                .thenReturn(List.of(existente("GTR-0003", EstadoProducto.ACTIVO), existente("GTR-0007", EstadoProducto.ACTIVO)));
        when(productoRepository.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals("GTR-0008", productoService.crearProducto(datos(), ADMIN).getSku());
    }

    @Test
    void defaultMinStock() {
        when(productoRepository.findBySkuStartingWith("GTR-")).thenReturn(List.of());
        when(productoRepository.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(5, productoService.crearProducto(datos(), ADMIN).getStockMinimo());
    }

    @Test
    void createInactive() {
        ProductoDTO d = datos();
        d.setActivo(false);
        when(productoRepository.findBySkuStartingWith("GTR-")).thenReturn(List.of());
        when(productoRepository.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(EstadoProducto.INACTIVO, productoService.crearProducto(d, ADMIN).getEstado());
    }

    @Test
    void createZeroPrice() {
        ProductoDTO d = datos();
        d.setPrecio(0);

        assertThrows(ResponseStatusException.class, () -> productoService.crearProducto(d, ADMIN));
        verify(productoRepository, never()).save(any());
    }

    @Test
    void createBadStock() {
        ProductoDTO negativo = datos();
        negativo.setStockDisponible(-1);
        ProductoDTO sinStock = datos();
        sinStock.setStockDisponible(null);

        assertThrows(ResponseStatusException.class, () -> productoService.crearProducto(negativo, ADMIN));
        assertThrows(ResponseStatusException.class, () -> productoService.crearProducto(sinStock, ADMIN));
    }

    @Test
    void createMissingFields() {
        ProductoDTO sinCategoria = datos();
        sinCategoria.setCategoria(null);
        ProductoDTO sinModelo = datos();
        sinModelo.setModelo(" ");

        assertThrows(ResponseStatusException.class, () -> productoService.crearProducto(sinCategoria, ADMIN));
        assertThrows(ResponseStatusException.class, () -> productoService.crearProducto(sinModelo, ADMIN));
    }

    @Test
    void updateKeepsStock() {
        Producto p = existente("GTR-0001", EstadoProducto.ACTIVO);
        ProductoDTO d = datos();
        d.setStockDisponible(null);
        d.setPrecio(800000);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));
        when(productoRepository.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        ProductoRespuestaDTO editado = productoService.editarProducto("GTR-0001", d, ADMIN);

        assertEquals(10, editado.getStockDisponible());
        assertEquals(800000, editado.getPrecio());
    }

    @Test
    void deactivate() {
        Producto p = existente("GTR-0001", EstadoProducto.ACTIVO);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));
        when(productoRepository.save(any(Producto.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(EstadoProducto.INACTIVO, productoService.desactivarProducto("GTR-0001", ADMIN).getEstado());
        assertThrows(ResponseStatusException.class, () -> productoService.desactivarProducto("GTR-0001", ADMIN));
    }

    @Test
    void deleteWithOrders() {
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(existente("GTR-0001", EstadoProducto.ACTIVO)));
        when(ventasClient.productoTienePedidos("GTR-0001")).thenReturn(true);

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> productoService.eliminarProducto("GTR-0001", ADMIN));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
        verify(productoRepository, never()).delete(any());
    }

    @Test
    void deleteNoOrders() {
        Producto p = existente("GTR-0001", EstadoProducto.ACTIVO);
        when(productoRepository.findById("GTR-0001")).thenReturn(Optional.of(p));
        when(ventasClient.productoTienePedidos("GTR-0001")).thenReturn(false);

        productoService.eliminarProducto("GTR-0001", ADMIN);

        verify(productoRepository).delete(p);
    }

    @Test
    void notFound404() {
        when(productoRepository.findById("GTR-0099")).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> productoService.findBySku("GTR-0099"));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }
}
