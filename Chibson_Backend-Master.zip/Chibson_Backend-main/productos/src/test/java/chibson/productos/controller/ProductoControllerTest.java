package chibson.productos.controller;

import chibson.productos.client.UsuariosClient;
import chibson.productos.dto.ProductoDTO;
import chibson.productos.dto.ProductoRespuestaDTO;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.Producto;
import chibson.productos.service.ProductoService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ProductoController.class)
@ActiveProfiles("test")
class ProductoControllerTest {
    private static final String RUT = "12345678-5";
    private static final String PERMISO = "GESTIONAR_PRODUCTOS";
    private static final String CUERPO = "{\"modelo\":\"Stratocaster\",\"marca\":\"Fender\",\"precio\":750000,"
            + "\"categoria\":\"GUITARRA\",\"imagenUrl\":\"https://img/s.png\",\"stockDisponible\":10}";

    @MockitoBean
    private ProductoService productoService;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @Autowired
    private MockMvc mvc;

    private ProductoRespuestaDTO respuesta(String sku) {
        ProductoRespuestaDTO r = new ProductoRespuestaDTO();
        r.setSku(sku);
        r.setModelo("Stratocaster");
        r.setEstado(EstadoProducto.ACTIVO);
        r.setCategoria(Categoria.GUITARRA);
        r.setEspecificaciones(new ArrayList<>());
        return r;
    }

    @Test
    void publicCatalog() throws Exception {
        when(productoService.listarActivos()).thenReturn(List.of(respuesta("GTR-0001")));

        mvc.perform(get("/api/productos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.productos[0].sku").value("GTR-0001"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._embedded.productos[0]._links.stock.href").exists());
        verify(usuariosClient, never()).exigirPermiso(any(), any());
    }

    @Test
    void publicDetail() throws Exception {
        when(productoService.obtenerActivo("GTR-0001")).thenReturn(respuesta("GTR-0001"));

        mvc.perform(get("/api/productos/GTR-0001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.modelo").value("Stratocaster"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.resenas.href").exists());
    }

    @Test
    void publicDetail404() throws Exception {
        when(productoService.obtenerActivo("XXX-0000"))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe"));

        mvc.perform(get("/api/productos/XXX-0000")).andExpect(status().isNotFound());
    }

    @Test
    void categories() throws Exception {
        mvc.perform(get("/api/productos/categorias"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").value("GUITARRA"))
                .andExpect(jsonPath("$.length()").value(Categoria.values().length));
    }

    @Test
    void adminListFilters() throws Exception {
        when(productoService.listarProductos(EstadoProducto.INACTIVO, Categoria.BAJO, "fender"))
                .thenReturn(List.of(respuesta("BAJ-0001")));

        mvc.perform(get("/api/productos/admin").header("X-Rut-Usuario", RUT)
                        .param("estado", "INACTIVO").param("categoria", "BAJO").param("texto", "fender"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.productos[0].sku").value("BAJ-0001"));
        verify(usuariosClient).exigirPermiso(RUT, PERMISO);
    }

    @Test
    void adminListForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(RUT, PERMISO);

        mvc.perform(get("/api/productos/admin").header("X-Rut-Usuario", RUT)).andExpect(status().isForbidden());
    }

    @Test
    void adminDetail() throws Exception {
        Producto p = new Producto();
        p.setSku("GTR-0001");
        when(productoService.findBySku("GTR-0001")).thenReturn(p);
        when(productoService.aRespuesta(p)).thenReturn(respuesta("GTR-0001"));

        mvc.perform(get("/api/productos/admin/GTR-0001").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.sku").value("GTR-0001"));
    }

    @Test
    void create201() throws Exception {
        when(productoService.crearProducto(any(ProductoDTO.class), eq(RUT))).thenReturn(respuesta("GTR-0001"));

        mvc.perform(post("/api/productos").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.sku").value("GTR-0001"));
    }

    @Test
    void update() throws Exception {
        when(productoService.editarProducto(eq("GTR-0001"), any(ProductoDTO.class), eq(RUT)))
                .thenReturn(respuesta("GTR-0001"));

        mvc.perform(put("/api/productos/GTR-0001").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content(CUERPO))
                .andExpect(status().isOk());
    }

    @Test
    void deactivateReactivate() throws Exception {
        when(productoService.desactivarProducto("GTR-0001", RUT)).thenReturn(respuesta("GTR-0001"));
        when(productoService.reactivarProducto("GTR-0001", RUT)).thenReturn(respuesta("GTR-0001"));

        mvc.perform(patch("/api/productos/GTR-0001/desactivar").header("X-Rut-Usuario", RUT)).andExpect(status().isOk());
        mvc.perform(patch("/api/productos/GTR-0001/reactivar").header("X-Rut-Usuario", RUT)).andExpect(status().isOk());
    }

    @Test
    void delete204() throws Exception {
        mvc.perform(delete("/api/productos/GTR-0001").header("X-Rut-Usuario", RUT)).andExpect(status().isNoContent());

        verify(productoService).eliminarProducto("GTR-0001", RUT);
    }

    @Test
    void deleteConflict409() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.CONFLICT, "Tiene pedidos"))
                .when(productoService).eliminarProducto("GTR-0001", RUT);

        mvc.perform(delete("/api/productos/GTR-0001").header("X-Rut-Usuario", RUT)).andExpect(status().isConflict());
    }

    @Test
    void specSheet() throws Exception {
        when(productoService.agregarFichaTecnica("GTR-0001", "cuerdas:6", RUT)).thenReturn(respuesta("GTR-0001"));
        when(productoService.editarFichaTecnica("GTR-0001", "cuerdas:7", RUT)).thenReturn(respuesta("GTR-0001"));

        mvc.perform(post("/api/productos/GTR-0001/ficha-tecnica").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"texto\":\"cuerdas:6\"}"))
                .andExpect(status().isOk());
        mvc.perform(put("/api/productos/GTR-0001/ficha-tecnica").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"texto\":\"cuerdas:7\"}"))
                .andExpect(status().isOk());
    }
}
