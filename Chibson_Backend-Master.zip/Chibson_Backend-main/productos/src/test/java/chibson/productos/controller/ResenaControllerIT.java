package chibson.productos.controller;

import chibson.productos.LimpiezaBaseDatos;
import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.Producto;
import chibson.productos.repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ResenaControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String RUT = "12345678-5";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private ProductoRepository productoRepository;
    @MockitoBean
    private UsuariosClient usuariosClient;
    @MockitoBean
    private VentasClient ventasClient;

    private static final String CLIENTE = "11111111-1";
    private static final String BODY = "{\"sku\":\"GTR-0001\",\"calificacion\":5,\"titulo\":\"Excelente\",\"comentario\":\"Muy buena\"}";

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
        guardar("GTR-0001", "Stratocaster", EstadoProducto.ACTIVO, 10);
        when(usuariosClient.obtenerNombre(anyString())).thenReturn("Ana Pérez");
        when(ventasClient.clienteRecibioProducto(anyString(), anyString())).thenReturn(true);
    }

    private Long crearResena() throws Exception {
        String json = mockMvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(BODY))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return Long.valueOf(json.replaceAll(".*?\"idResena\":(\\d+).*", "$1"));
    }

    private Producto guardar(String sku, String modelo, EstadoProducto estado, int stock) {
        Producto p = new Producto();
        p.setSku(sku);
        p.setModelo(modelo);
        p.setMarca("Fender");
        p.setPrecio(750000);
        p.setCategoria(Categoria.GUITARRA);
        p.setEstado(estado);
        p.setImagenUrl("https://img/x.png");
        p.setStockDisponible(stock);
        p.setStockMinimo(5);
        return productoRepository.save(p);
    }

    @Test
    void createPending() throws Exception {
        mockMvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(BODY))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andExpect(jsonPath("$.nombreCliente").value("Ana Pérez"));
    }

    @Test
    void duplicateReview409() throws Exception {
        crearResena();

        mockMvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(BODY))
                .andExpect(status().isConflict());
    }

    @Test
    void notReceived403() throws Exception {
        when(ventasClient.clienteRecibioProducto(anyString(), anyString())).thenReturn(false);

        mockMvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(BODY))
                .andExpect(status().isForbidden());
    }

    @Test
    void invalidRating400() throws Exception {
        mockMvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(BODY.replace("\"calificacion\":5", "\"calificacion\":9")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void approveAndListPublic() throws Exception {
        Long id = crearResena();

        mockMvc.perform(get("/api/resenas/producto/GTR-0001"))
                .andExpect(jsonPath("$.total").value(0));
        mockMvc.perform(patch("/api/resenas/" + id + "/moderar").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"estado\":\"APROBADA\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("APROBADA"));
        mockMvc.perform(get("/api/resenas/producto/GTR-0001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.total").value(1))
                .andExpect(jsonPath("$.promedio").value(5.0));
    }

    @Test
    void moderateInvalidDecision400() throws Exception {
        Long id = crearResena();

        mockMvc.perform(patch("/api/resenas/" + id + "/moderar").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"estado\":\"OCULTA\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void hideApprovedOnly() throws Exception {
        Long id = crearResena();

        mockMvc.perform(patch("/api/resenas/" + id + "/ocultar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch("/api/resenas/" + id + "/moderar").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"estado\":\"APROBADA\"}"))
                .andExpect(status().isOk());
        mockMvc.perform(patch("/api/resenas/" + id + "/ocultar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("OCULTA"));
    }

    @Test
    void replyToReview() throws Exception {
        Long id = crearResena();

        mockMvc.perform(put("/api/resenas/" + id + "/respuesta").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"respuesta\":\"Gracias por tu compra\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.respuestaAdmin").value("Gracias por tu compra"));
        mockMvc.perform(put("/api/resenas/" + id + "/respuesta").header("X-Rut-Usuario", RUT).contentType(JSON)
                        .content("{\"respuesta\":\" \"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void adminListWithFilters() throws Exception {
        crearResena();

        mockMvc.perform(get("/api/resenas/admin").header("X-Rut-Usuario", RUT))
                .andExpect(jsonPath("$._embedded.resenas.length()").value(1));
        mockMvc.perform(get("/api/resenas/admin").header("X-Rut-Usuario", RUT).param("estado", "APROBADA"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/resenas/admin").header("X-Rut-Usuario", RUT).param("sku", "gtr-0001").param("calificacion", "5"))
                .andExpect(jsonPath("$._embedded.resenas.length()").value(1));
    }

    @Test
    void deleteReview() throws Exception {
        Long id = crearResena();

        mockMvc.perform(delete("/api/resenas/" + id).header("X-Rut-Usuario", RUT))
                .andExpect(status().isNoContent());
        mockMvc.perform(delete("/api/resenas/" + id).header("X-Rut-Usuario", RUT))
                .andExpect(status().isNotFound());
    }
}
