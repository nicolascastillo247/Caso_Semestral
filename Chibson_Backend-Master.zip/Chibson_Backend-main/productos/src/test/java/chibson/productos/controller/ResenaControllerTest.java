package chibson.productos.controller;

import chibson.productos.client.UsuariosClient;
import chibson.productos.dto.ResenaDTO;
import chibson.productos.dto.ResenasProductoDTO;
import chibson.productos.model.EstadoResena;
import chibson.productos.model.Producto;
import chibson.productos.model.Resena;
import chibson.productos.service.ResenaService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ResenaController.class)
@ActiveProfiles("test")
class ResenaControllerTest {
    private static final String RUT = "12345678-5";
    private static final String CLIENTE = "11111111-1";
    private static final String PERMISO = "GESTIONAR_RESENAS";

    @MockitoBean
    private ResenaService resenaService;
    @MockitoBean
    private UsuariosClient usuariosClient;

    @Autowired
    private MockMvc mvc;

    private Resena resena(Long id, EstadoResena estado) {
        Producto p = new Producto();
        p.setSku("GTR-0001");
        p.setModelo("Stratocaster");
        Resena r = new Resena();
        r.setIdResena(id);
        r.setTitulo("Excelente");
        r.setCalificacion(5);
        r.setEstado(estado);
        r.setProducto(p);
        return r;
    }

    @Test
    void create201() throws Exception {
        when(resenaService.crearResena(any(ResenaDTO.class), eq(CLIENTE))).thenReturn(resena(1L, EstadoResena.PENDIENTE));

        mvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"sku\":\"GTR-0001\",\"calificacion\":5,\"titulo\":\"Excelente\",\"comentario\":\"Muy buena\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.idResena").value(1));
    }

    @Test
    void createForbidden403() throws Exception {
        when(resenaService.crearResena(any(ResenaDTO.class), eq(CLIENTE)))
                .thenThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "No lo recibiste"));

        mvc.perform(post("/api/resenas").header("X-Rut-Usuario", CLIENTE)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"sku\":\"GTR-0001\"}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void listApproved() throws Exception {
        when(resenaService.listarAprobadas("GTR-0001"))
                .thenReturn(new ResenasProductoDTO("GTR-0001", 4.5, 1, List.of(resena(2L, EstadoResena.APROBADA))));

        mvc.perform(get("/api/resenas/producto/GTR-0001"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.promedio").value(4.5))
                .andExpect(jsonPath("$.total").value(1));
    }

    @Test
    void adminListFilters() throws Exception {
        when(resenaService.listarResenas(EstadoResena.PENDIENTE, "GTR-0001", 5))
                .thenReturn(List.of(resena(3L, EstadoResena.PENDIENTE)));

        mvc.perform(get("/api/resenas/admin").header("X-Rut-Usuario", RUT)
                        .param("estado", "PENDIENTE").param("sku", "GTR-0001").param("calificacion", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.resenas[0].idResena").value(3));
        verify(usuariosClient).exigirPermiso(RUT, PERMISO);
    }

    @Test
    void adminListForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(RUT, PERMISO);

        mvc.perform(get("/api/resenas/admin").header("X-Rut-Usuario", RUT)).andExpect(status().isForbidden());
    }

    @Test
    void moderate() throws Exception {
        when(resenaService.moderarResena(4L, EstadoResena.APROBADA, RUT)).thenReturn(resena(4L, EstadoResena.APROBADA));

        mvc.perform(patch("/api/resenas/4/moderar").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"estado\":\"APROBADA\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("APROBADA"));
    }

    @Test
    void hide() throws Exception {
        when(resenaService.ocultarResena(5L, RUT)).thenReturn(resena(5L, EstadoResena.OCULTA));

        mvc.perform(patch("/api/resenas/5/ocultar").header("X-Rut-Usuario", RUT))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("OCULTA"));
    }

    @Test
    void reply() throws Exception {
        when(resenaService.responderResena(6L, "Gracias", RUT)).thenReturn(resena(6L, EstadoResena.APROBADA));

        mvc.perform(put("/api/resenas/6/respuesta").header("X-Rut-Usuario", RUT)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"respuesta\":\"Gracias\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void delete204() throws Exception {
        mvc.perform(delete("/api/resenas/7").header("X-Rut-Usuario", RUT)).andExpect(status().isNoContent());

        verify(resenaService).eliminarResena(7L, RUT);
    }
}
