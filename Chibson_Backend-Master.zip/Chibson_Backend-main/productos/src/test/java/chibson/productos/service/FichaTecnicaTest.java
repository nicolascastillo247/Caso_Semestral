package chibson.productos.service;

import chibson.productos.dto.EspecificacionDTO;
import chibson.productos.service.FichaTecnica;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FichaTecnicaTest {
    @Test
    void validateTrimsSemicolon() {
        assertEquals("cuerdas:6;trastes:22", FichaTecnica.validar(" cuerdas:6;trastes:22; "));
    }

    @Test
    void emptyOrNull() {
        assertEquals(HttpStatus.BAD_REQUEST, assertThrows(ResponseStatusException.class,
                () -> FichaTecnica.validar(null)).getStatusCode());
        assertEquals(HttpStatus.BAD_REQUEST, assertThrows(ResponseStatusException.class,
                () -> FichaTecnica.validar("   ")).getStatusCode());
    }

    @Test
    void noColon() {
        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> FichaTecnica.validar("cuerdas:6;trastes"));
        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
        assertTrue(e.getReason().contains("2"));
    }

    @Test
    void badSegment() {
        assertThrows(ResponseStatusException.class, () -> FichaTecnica.validar("cuerdas:"));
        assertThrows(ResponseStatusException.class, () -> FichaTecnica.validar("a:b:c"));
        assertThrows(ResponseStatusException.class, () -> FichaTecnica.validar("a:1;;b:2"));
    }

    @Test
    void parseCapitalizes() {
        List<EspecificacionDTO> filas = FichaTecnica.interpretar("cuerdas:6;trastes: 22");

        assertEquals(2, filas.size());
        assertEquals("Cuerdas", filas.get(0).getClave());
        assertEquals("22", filas.get(1).getValor());
    }

    @Test
    void parseSkipsBad() {
        assertEquals(1, FichaTecnica.interpretar("cuerdas:6;malo;x:").size());
    }

    @Test
    void parseEmpty() {
        assertTrue(FichaTecnica.interpretar(null).isEmpty());
        assertTrue(FichaTecnica.interpretar(" ").isEmpty());
    }
}
