package chibson.productos.service;

import chibson.productos.client.UsuariosClient;
import chibson.productos.client.VentasClient;
import chibson.productos.dto.RegistroAccionDTO;
import chibson.productos.dto.ResenaDTO;
import chibson.productos.dto.ResenasProductoDTO;
import chibson.productos.model.EstadoProducto;
import chibson.productos.model.EstadoResena;
import chibson.productos.model.Producto;
import chibson.productos.model.Resena;
import chibson.productos.repository.ProductoRepository;
import chibson.productos.repository.ResenaRepository;
import chibson.productos.service.ResenaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ResenaServiceTest {
    private static final String RUT = "11111111-1";
    private static final String ADMIN = "12345678-5";

    @Mock
    private ResenaRepository resenaRepository;
    @Mock
    private ProductoRepository productoRepository;
    @Mock
    private UsuariosClient usuariosClient;
    @Mock
    private VentasClient ventasClient;

    private ResenaService service;
    private Producto producto;

    @BeforeEach
    void setUp() {
        service = new ResenaService(resenaRepository, productoRepository, usuariosClient, ventasClient);
        producto = new Producto();
        producto.setSku("GTR-0001");
        producto.setModelo("Stratocaster");
    }

    private ResenaDTO datos(Integer calificacion, String titulo, String comentario) {
        ResenaDTO d = new ResenaDTO();
        d.setSku("GTR-0001");
        d.setCalificacion(calificacion);
        d.setTitulo(titulo);
        d.setComentario(comentario);
        return d;
    }

    private Resena resena(Long id, EstadoResena estado, int calificacion) {
        Resena r = new Resena();
        r.setIdResena(id);
        r.setEstado(estado);
        r.setCalificacion(calificacion);
        r.setProducto(producto);
        return r;
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    private void productoActivo() {
        when(usuariosClient.obtenerNombre(RUT)).thenReturn("Ana Pérez");
        when(productoRepository.findBySkuAndEstado("GTR-0001", EstadoProducto.ACTIVO)).thenReturn(Optional.of(producto));
    }

    @Test
    void createPending() {
        productoActivo();
        when(resenaRepository.existsByRutClienteAndProductoSku(RUT, "GTR-0001")).thenReturn(false);
        when(ventasClient.clienteRecibioProducto(RUT, "GTR-0001")).thenReturn(true);
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArgument(0));

        Resena r = service.crearResena(datos(5, "  Excelente ", " Muy buena "), RUT);

        assertEquals(EstadoResena.PENDIENTE, r.getEstado());
        assertEquals("Excelente", r.getTitulo());
        assertEquals("Muy buena", r.getComentario());
        assertEquals("Ana Pérez", r.getNombreCliente());
        assertNotNull(r.getFecha());
    }

    @Test
    void blankComment() {
        productoActivo();
        when(resenaRepository.existsByRutClienteAndProductoSku(RUT, "GTR-0001")).thenReturn(false);
        when(ventasClient.clienteRecibioProducto(RUT, "GTR-0001")).thenReturn(true);
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(null, service.crearResena(datos(4, "Bien", "  "), RUT).getComentario());
    }

    @Test
    void productNotFound() {
        when(usuariosClient.obtenerNombre(RUT)).thenReturn("Ana Pérez");
        when(productoRepository.findBySkuAndEstado("GTR-0001", EstadoProducto.ACTIVO)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearResena(datos(5, "x", null), RUT))));
    }

    @Test
    void ratingOutOfRange() {
        productoActivo();
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearResena(datos(6, "x", null), RUT))));
    }

    @Test
    void ratingNull() {
        productoActivo();
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearResena(datos(null, "x", null), RUT))));
    }

    @Test
    void emptyTitle() {
        productoActivo();
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearResena(datos(3, " ", null), RUT))));
    }

    @Test
    void duplicate409() {
        productoActivo();
        when(resenaRepository.existsByRutClienteAndProductoSku(RUT, "GTR-0001")).thenReturn(true);

        assertEquals(HttpStatus.CONFLICT, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearResena(datos(3, "x", null), RUT))));
    }

    @Test
    void notReceived403() {
        productoActivo();
        when(resenaRepository.existsByRutClienteAndProductoSku(RUT, "GTR-0001")).thenReturn(false);
        when(ventasClient.clienteRecibioProducto(RUT, "GTR-0001")).thenReturn(false);

        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearResena(datos(3, "x", null), RUT))));
        verify(resenaRepository, never()).save(any());
    }

    @Test
    void averageRounded() {
        when(resenaRepository.findByProductoSkuAndEstadoOrderByFechaDesc("GTR-0001", EstadoResena.APROBADA))
                .thenReturn(List.of(resena(1L, EstadoResena.APROBADA, 5), resena(2L, EstadoResena.APROBADA, 4),
                        resena(3L, EstadoResena.APROBADA, 4)));

        ResenasProductoDTO r = service.listarAprobadas("GTR-0001");

        assertEquals(4.3, r.getPromedio());
        assertEquals(3, r.getTotal());
    }

    @Test
    void averageZero() {
        when(resenaRepository.findByProductoSkuAndEstadoOrderByFechaDesc("GTR-0001", EstadoResena.APROBADA))
                .thenReturn(List.of());

        ResenasProductoDTO r = service.listarAprobadas("GTR-0001");

        assertEquals(0.0, r.getPromedio());
        assertEquals(0, r.getTotal());
    }

    @Test
    void listFilters() {
        when(resenaRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(
                resena(1L, EstadoResena.PENDIENTE, 5),
                resena(2L, EstadoResena.APROBADA, 5),
                resena(3L, EstadoResena.PENDIENTE, 2)));

        assertEquals(3, service.listarResenas(null, null, null).size());
        assertEquals(3, service.listarResenas(null, " ", null).size());
        assertEquals(2, service.listarResenas(EstadoResena.PENDIENTE, null, null).size());
        assertEquals(1, service.listarResenas(EstadoResena.PENDIENTE, "gtr-0001", 5).size());
        assertEquals(0, service.listarResenas(null, "OTRO-0001", null).size());
    }

    @Test
    void findByIdNotFound() {
        when(resenaRepository.findById(9L)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> service.findById(9L))));
    }

    @Test
    void approve() {
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(resena(1L, EstadoResena.PENDIENTE, 5)));
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArgument(0));

        Resena r = service.moderarResena(1L, EstadoResena.APROBADA, ADMIN);

        assertEquals(EstadoResena.APROBADA, r.getEstado());
        verify(usuariosClient).registrarAccion(any(RegistroAccionDTO.class));
    }

    @Test
    void reject() {
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(resena(1L, EstadoResena.PENDIENTE, 1)));
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(EstadoResena.RECHAZADA, service.moderarResena(1L, EstadoResena.RECHAZADA, ADMIN).getEstado());
    }

    @Test
    void invalidDecision() {
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.moderarResena(1L, EstadoResena.OCULTA, ADMIN))));
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.moderarResena(1L, null, ADMIN))));
    }

    @Test
    void moderatePendingOnly() {
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(resena(1L, EstadoResena.APROBADA, 5)));

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.moderarResena(1L, EstadoResena.RECHAZADA, ADMIN))));
    }

    @Test
    void hide() {
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(resena(1L, EstadoResena.APROBADA, 5)));
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals(EstadoResena.OCULTA, service.ocultarResena(1L, ADMIN).getEstado());
    }

    @Test
    void hidePending() {
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(resena(1L, EstadoResena.PENDIENTE, 5)));

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.ocultarResena(1L, ADMIN))));
    }

    @Test
    void reply() {
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(resena(1L, EstadoResena.APROBADA, 5)));
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArgument(0));

        Resena r = service.responderResena(1L, "  Gracias ", ADMIN);

        assertEquals("Gracias", r.getRespuestaAdmin());
        assertNotNull(r.getFechaRespuesta());
    }

    @Test
    void emptyReply() {
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.responderResena(1L, " ", ADMIN))));
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.responderResena(1L, null, ADMIN))));
    }

    @Test
    void delete() {
        Resena r = resena(1L, EstadoResena.APROBADA, 5);
        when(resenaRepository.findById(1L)).thenReturn(Optional.of(r));

        service.eliminarResena(1L, ADMIN);

        verify(resenaRepository).delete(r);
        verify(usuariosClient).registrarAccion(any(RegistroAccionDTO.class));
    }
}
