package chibson.productos.dto;

import chibson.productos.model.Categoria;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductoDTO {
    private String modelo;
    private String marca;
    private String descripcion;
    private Integer precio;
    private Categoria categoria;
    private String imagenUrl;

    private Integer stockDisponible;

    private Integer stockMinimo;

    private Boolean activo;
}
