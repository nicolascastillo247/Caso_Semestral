package chibson.productos.model;

public enum Categoria {
    GUITARRA("GTR"),
    BAJO("BAJ"),
    PERCUSION("PER"),
    TECLAS("TEC"),
    VIENTO("VIE"),
    CUERDAS("CUE");

    private final String prefijo;

    Categoria(String prefijo) {
        this.prefijo = prefijo;
    }

    public String getPrefijo() {
        return prefijo;
    }
}
