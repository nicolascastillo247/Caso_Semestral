package chibson.productos.dto;

import chibson.productos.model.Resena;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResenasProductoDTO {
    private String sku;

    private double promedio;
    private int total;
    private List<Resena> resenas;
}
