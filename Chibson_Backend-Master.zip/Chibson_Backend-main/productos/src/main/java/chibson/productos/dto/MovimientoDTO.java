package chibson.productos.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MovimientoDTO {
    private Integer cantidad;
    private Long numeroPedido;

    private String tipo;

    private String rutResponsable;
}
