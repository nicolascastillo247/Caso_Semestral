package chibson.productos.model;

public enum EstadoProducto {
    ACTIVO,
    INACTIVO
}
