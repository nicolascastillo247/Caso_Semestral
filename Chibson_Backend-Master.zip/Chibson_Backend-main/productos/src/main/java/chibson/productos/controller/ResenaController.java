package chibson.productos.controller;

import chibson.productos.client.UsuariosClient;
import chibson.productos.dto.ModeracionDTO;
import chibson.productos.dto.ResenaDTO;
import chibson.productos.dto.ResenasProductoDTO;
import chibson.productos.dto.RespuestaResenaDTO;
import chibson.productos.model.EstadoResena;
import chibson.productos.model.Resena;
import chibson.productos.service.ResenaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/resenas")
@Tag(name = "Reseñas", description = "Reseñas de productos y su moderación")
public class ResenaController {
    private static final String RUT = "X-Rut-Usuario";
    private static final String PERMISO = "GESTIONAR_RESENAS";

    private final ResenaService resenaService;
    private final UsuariosClient usuariosClient;

    public ResenaController(ResenaService resenaService, UsuariosClient usuariosClient) {
        this.resenaService = resenaService;
        this.usuariosClient = usuariosClient;
    }

    @PostMapping
    @Operation(summary = "Crea una reseña de un producto comprado")
    public ResponseEntity<EntityModel<Resena>> crearResena(@RequestHeader(value = RUT, required = false) String rut,
                                                           @RequestBody ResenaDTO datos) {
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(resenaService.crearResena(datos, rut)));
    }

    @GetMapping("/producto/{sku}")
    @Operation(summary = "Reseñas aprobadas de un producto con su promedio")
    public EntityModel<ResenasProductoDTO> listarAprobadas(@PathVariable String sku) {
        return EntityModel.of(resenaService.listarAprobadas(sku),
                linkTo(ResenaController.class).slash("producto").slash(sku).withSelfRel(),
                linkTo(ProductoController.class).slash(sku).withRel("producto"));
    }

    @GetMapping("/admin")
    @Operation(summary = "Lista todas las reseñas con filtros (administración)")
    public CollectionModel<EntityModel<Resena>> listarResenas(@RequestHeader(value = RUT, required = false) String rut,
                                                              @RequestParam(required = false) EstadoResena estado,
                                                              @RequestParam(required = false) String sku,
                                                              @RequestParam(required = false) Integer calificacion) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return CollectionModel.of(resenaService.listarResenas(estado, sku, calificacion).stream()
                        .map(this::modelo).toList(),
                linkTo(ResenaController.class).slash("admin").withSelfRel());
    }

    @PatchMapping("/{id}/moderar")
    @Operation(summary = "Aprueba o rechaza una reseña")
    public EntityModel<Resena> moderarResena(@RequestHeader(value = RUT, required = false) String rut,
                                             @PathVariable Long id, @RequestBody ModeracionDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(resenaService.moderarResena(id, datos.getEstado(), rut));
    }

    @PatchMapping("/{id}/ocultar")
    @Operation(summary = "Oculta una reseña")
    public EntityModel<Resena> ocultarResena(@RequestHeader(value = RUT, required = false) String rut,
                                             @PathVariable Long id) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(resenaService.ocultarResena(id, rut));
    }

    @PutMapping("/{id}/respuesta")
    @Operation(summary = "Responde una reseña")
    public EntityModel<Resena> responderResena(@RequestHeader(value = RUT, required = false) String rut,
                                               @PathVariable Long id, @RequestBody RespuestaResenaDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(resenaService.responderResena(id, datos.getRespuesta(), rut));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Elimina una reseña")
    public ResponseEntity<Void> eliminarResena(@RequestHeader(value = RUT, required = false) String rut,
                                               @PathVariable Long id) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        resenaService.eliminarResena(id, rut);
        return ResponseEntity.noContent().build();
    }

    private EntityModel<Resena> modelo(Resena resena) {
        return EntityModel.of(resena,
                linkTo(ResenaController.class).slash("admin").withRel("resenas"));
    }
}
