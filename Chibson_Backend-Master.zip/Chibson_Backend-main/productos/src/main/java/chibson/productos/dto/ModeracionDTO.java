package chibson.productos.dto;

import chibson.productos.model.EstadoResena;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModeracionDTO {
    private EstadoResena estado;
}
