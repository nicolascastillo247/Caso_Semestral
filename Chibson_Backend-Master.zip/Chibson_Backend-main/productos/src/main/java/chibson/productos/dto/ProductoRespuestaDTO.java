package chibson.productos.dto;

import org.springframework.hateoas.server.core.Relation;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Relation(itemRelation = "producto", collectionRelation = "productos")
public class ProductoRespuestaDTO {
    private String sku;
    private String modelo;
    private String marca;
    private String descripcion;
    private Integer precio;
    private Categoria categoria;
    private EstadoProducto estado;
    private String imagenUrl;

    private String fichaTecnica;

    private List<EspecificacionDTO> especificaciones;
    private Integer stockDisponible;
    private Integer stockMinimo;
    private boolean bajoStock;
    private boolean agotado;
    private LocalDateTime fechaModificacion;
    private LocalDateTime fechaModificacionFicha;
}
