package chibson.productos.controller;

import chibson.productos.client.UsuariosClient;
import chibson.productos.dto.FichaTecnicaDTO;
import chibson.productos.dto.ProductoDTO;
import chibson.productos.dto.ProductoRespuestaDTO;
import chibson.productos.model.Categoria;
import chibson.productos.model.EstadoProducto;
import chibson.productos.service.ProductoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/productos")
@Tag(name = "Productos", description = "Catálogo público y administración de productos")
public class ProductoController {
    private static final String RUT = "X-Rut-Usuario";
    private static final String PERMISO = "GESTIONAR_PRODUCTOS";

    private final ProductoService productoService;
    private final UsuariosClient usuariosClient;

    public ProductoController(ProductoService productoService, UsuariosClient usuariosClient) {
        this.productoService = productoService;
        this.usuariosClient = usuariosClient;
    }

    @GetMapping
    @Operation(summary = "Catálogo: lista los productos activos")
    public CollectionModel<EntityModel<ProductoRespuestaDTO>> listarActivos() {
        return coleccion(productoService.listarActivos(), linkTo(ProductoController.class).withSelfRel());
    }

    @GetMapping("/{sku}")
    @Operation(summary = "Detalle de un producto activo")
    public EntityModel<ProductoRespuestaDTO> obtenerActivo(@PathVariable String sku) {
        return modelo(productoService.obtenerActivo(sku));
    }

    @GetMapping("/categorias")
    @Operation(summary = "Lista las categorías disponibles")
    public List<Categoria> listarCategorias() {
        return Arrays.asList(Categoria.values());
    }

    @GetMapping("/admin")
    @Operation(summary = "Lista todos los productos con filtros (administración)")
    public CollectionModel<EntityModel<ProductoRespuestaDTO>> listarProductos(
            @RequestHeader(value = RUT, required = false) String rut,
            @RequestParam(required = false) EstadoProducto estado,
            @RequestParam(required = false) Categoria categoria,
            @RequestParam(required = false) String texto) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return coleccion(productoService.listarProductos(estado, categoria, texto),
                linkTo(ProductoController.class).slash("admin").withSelfRel());
    }

    @GetMapping("/admin/{sku}")
    @Operation(summary = "Busca un producto por SKU, aunque esté desactivado (administración)")
    public EntityModel<ProductoRespuestaDTO> findBySku(@RequestHeader(value = RUT, required = false) String rut,
                                                       @PathVariable String sku) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(productoService.aRespuesta(productoService.findBySku(sku)));
    }

    @PostMapping
    @Operation(summary = "Crea un producto")
    public ResponseEntity<EntityModel<ProductoRespuestaDTO>> crearProducto(
            @RequestHeader(value = RUT, required = false) String rut, @RequestBody ProductoDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(productoService.crearProducto(datos, rut)));
    }

    @PutMapping("/{sku}")
    @Operation(summary = "Edita un producto")
    public EntityModel<ProductoRespuestaDTO> editarProducto(@RequestHeader(value = RUT, required = false) String rut,
                                                            @PathVariable String sku, @RequestBody ProductoDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(productoService.editarProducto(sku, datos, rut));
    }

    @PatchMapping("/{sku}/desactivar")
    @Operation(summary = "Desactiva un producto (deja de verse en el catálogo)")
    public EntityModel<ProductoRespuestaDTO> desactivarProducto(@RequestHeader(value = RUT, required = false) String rut,
                                                                @PathVariable String sku) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(productoService.desactivarProducto(sku, rut));
    }

    @PatchMapping("/{sku}/reactivar")
    @Operation(summary = "Reactiva un producto")
    public EntityModel<ProductoRespuestaDTO> reactivarProducto(@RequestHeader(value = RUT, required = false) String rut,
                                                               @PathVariable String sku) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(productoService.reactivarProducto(sku, rut));
    }

    @DeleteMapping("/{sku}")
    @Operation(summary = "Elimina un producto sin pedidos asociados")
    public ResponseEntity<Void> eliminarProducto(@RequestHeader(value = RUT, required = false) String rut,
                                                 @PathVariable String sku) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        productoService.eliminarProducto(sku, rut);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{sku}/ficha-tecnica")
    @Operation(summary = "Agrega la ficha técnica a un producto")
    public EntityModel<ProductoRespuestaDTO> agregarFichaTecnica(@RequestHeader(value = RUT, required = false) String rut,
                                                                 @PathVariable String sku,
                                                                 @RequestBody FichaTecnicaDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(productoService.agregarFichaTecnica(sku, datos.getTexto(), rut));
    }

    @PutMapping("/{sku}/ficha-tecnica")
    @Operation(summary = "Edita la ficha técnica de un producto")
    public EntityModel<ProductoRespuestaDTO> editarFichaTecnica(@RequestHeader(value = RUT, required = false) String rut,
                                                                @PathVariable String sku,
                                                                @RequestBody FichaTecnicaDTO datos) {
        usuariosClient.exigirPermiso(rut, PERMISO);
        return modelo(productoService.editarFichaTecnica(sku, datos.getTexto(), rut));
    }

    private EntityModel<ProductoRespuestaDTO> modelo(ProductoRespuestaDTO producto) {
        return EntityModel.of(producto,
                linkTo(ProductoController.class).slash(producto.getSku()).withSelfRel(),
                linkTo(ProductoController.class).slash(producto.getSku()).slash("stock").withRel("stock"),
                linkTo(ResenaController.class).slash("producto").slash(producto.getSku()).withRel("resenas"),
                linkTo(ProductoController.class).withRel("productos"));
    }

    private CollectionModel<EntityModel<ProductoRespuestaDTO>> coleccion(List<ProductoRespuestaDTO> productos,
                                                                         Link self) {
        return CollectionModel.of(productos.stream().map(this::modelo).toList(), self);
    }
}
