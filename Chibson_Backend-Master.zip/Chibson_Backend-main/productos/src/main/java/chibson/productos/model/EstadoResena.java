package chibson.productos.model;

public enum EstadoResena {
    PENDIENTE,
    APROBADA,
    RECHAZADA,
    OCULTA
}
