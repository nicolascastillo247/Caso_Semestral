package chibson.productos.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

@Component
public class VentasClient {
    private final RestTemplate restTemplate;
    private final String urlVentas;

    public VentasClient(RestTemplate restTemplate, @Value("${servicios.ventas.url}") String urlVentas) {
        this.restTemplate = restTemplate;
        this.urlVentas = urlVentas;
    }

    public boolean productoTienePedidos(String sku) {
        return consultar(urlVentas + "/api/pedidos/producto/{sku}/existe", sku);
    }

    public boolean clienteRecibioProducto(String rut, String sku) {
        return consultar(urlVentas + "/api/pedidos/cliente/{rut}/recibio/{sku}", rut, sku);
    }

    private boolean consultar(String url, Object... variables) {
        try {
            return Boolean.TRUE.equals(restTemplate.getForObject(url, Boolean.class, variables));
        } catch (RestClientException e) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "No se pudo consultar los pedidos en ms-ventas. Intente más tarde");
        }
    }
}
