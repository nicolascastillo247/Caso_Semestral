package chibson.productos.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import chibson.productos.dto.MovimientoDTO;
import chibson.productos.dto.ProductoRespuestaDTO;
import chibson.productos.dto.StockDTO;
import chibson.productos.service.ProductoService;
import chibson.productos.service.StockService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/productos")
@Tag(name = "Stock", description = "Stock de productos; lo usan ms-ventas y ms-informes")
public class StockController {
    private final StockService stockService;
    private final ProductoService productoService;

    public StockController(StockService stockService, ProductoService productoService) {
        this.stockService = stockService;
        this.productoService = productoService;
    }

    @GetMapping("/{sku}/stock")
    @Operation(summary = "Consulta el stock de un producto")
    public StockDTO consultar(@PathVariable String sku) {
        return stockService.consultar(sku);
    }

    @PostMapping("/{sku}/descontar")
    @Operation(summary = "Descuenta stock por una venta (uso interno de ms-ventas)")
    public StockDTO descontar(@PathVariable String sku, @RequestBody MovimientoDTO datos) {
        return stockService.descontar(sku, datos);
    }

    @PostMapping("/{sku}/reponer")
    @Operation(summary = "Repone stock por cancelación o devolución (uso interno de ms-ventas)")
    public StockDTO reponer(@PathVariable String sku, @RequestBody MovimientoDTO datos) {
        return stockService.reponer(sku, datos);
    }

    @GetMapping("/bajo-stock")
    @Operation(summary = "Productos activos con stock bajo (uso interno de ms-informes)")
    public List<ProductoRespuestaDTO> listarBajoStock() {
        return productoService.listarBajoStock();
    }
}
