package chibson.productos.model;

import org.springframework.hateoas.server.core.Relation;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "resena")
@Getter
@Setter
@NoArgsConstructor
@Relation(itemRelation = "resena", collectionRelation = "resenas")
public class Resena {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idResena;

    @Column(nullable = false, length = 12)
    private String rutCliente;

    @Column(nullable = false, length = 120)
    private String nombreCliente;

    @Column(nullable = false)
    private Integer calificacion;

    @Column(nullable = false, length = 100)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String comentario;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoResena estado;

    @Column(columnDefinition = "TEXT")
    private String respuestaAdmin;

    @Column(nullable = false)
    private LocalDateTime fecha;

    private LocalDateTime fechaRespuesta;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "sku", nullable = false)
    private Producto producto;

    public String getSku() {
        return producto == null ? null : producto.getSku();
    }

    public String getModeloProducto() {
        return producto == null ? null : producto.getModelo();
    }
}
