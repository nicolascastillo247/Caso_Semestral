package chibson.usuarios.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRespuestaDTO {
    private String rut;
    private String nombres;
    private String primerApellido;
    private String username;
    private String rol;
    private List<String> permisos;

    private String token;
}
