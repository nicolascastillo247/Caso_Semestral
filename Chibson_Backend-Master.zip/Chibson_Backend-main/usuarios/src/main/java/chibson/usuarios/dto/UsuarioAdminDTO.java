package chibson.usuarios.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioAdminDTO {
    private String rut;
    private String nombres;
    private String primerApellido;
    private String segundoApellido;
    private String username;
    private String correo;
    private String telefono;

    private String rol;

    private String password;
}
