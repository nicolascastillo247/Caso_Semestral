package chibson.usuarios.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;

@Service
public class TokenService {
    private final String secreto;
    private final long duracionSegundos;

    public TokenService(@Value("${seguridad.token.secreto}") String secreto,
                        @Value("${seguridad.token.duracion-segundos:28800}") long duracionSegundos) {
        this.secreto = secreto;
        this.duracionSegundos = duracionSegundos;
    }

    public String crear(String rut) {
        long expira = Instant.now().getEpochSecond() + duracionSegundos;
        String cuerpo = Base64.getUrlEncoder().withoutPadding().encodeToString(rut.getBytes(StandardCharsets.UTF_8))
                + "." + expira;
        return cuerpo + "." + firmar(cuerpo);
    }

    private String firmar(String cuerpo) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secreto.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(cuerpo.getBytes(StandardCharsets.UTF_8)));
        } catch (java.security.GeneralSecurityException e) {
            throw new IllegalStateException("No se pudo firmar el token", e);
        }
    }
}
