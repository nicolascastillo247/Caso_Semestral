package chibson.usuarios.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

@Component
public class VentasClient {
    private final RestTemplate restTemplate;
    private final String urlVentas;

    public VentasClient(RestTemplate restTemplate, @Value("${servicios.ventas.url}") String urlVentas) {
        this.restTemplate = restTemplate;
        this.urlVentas = urlVentas;
    }

    public boolean clienteTienePedidos(String rut) {
        try {
            Boolean respuesta = restTemplate.getForObject(
                    urlVentas + "/api/pedidos/cliente/" + rut + "/existe", Boolean.class);
            return Boolean.TRUE.equals(respuesta);
        } catch (RestClientException e) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "No se pudo verificar si el usuario tiene pedidos. Intente más tarde");
        }
    }
}
