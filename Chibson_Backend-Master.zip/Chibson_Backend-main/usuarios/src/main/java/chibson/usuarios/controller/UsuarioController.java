package chibson.usuarios.controller;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import chibson.usuarios.dto.PerfilDTO;
import chibson.usuarios.dto.RolDTO;
import chibson.usuarios.dto.UsuarioAdminDTO;
import chibson.usuarios.dto.UsuarioDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.Permisos;
import chibson.usuarios.service.RolService;
import chibson.usuarios.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/usuarios")
@Tag(name = "Usuarios", description = "Perfil propio y administración de usuarios")
public class UsuarioController {
    private static final String RUT = "X-Rut-Usuario";

    private final UsuarioService usuarioService;
    private final RolService rolService;

    public UsuarioController(UsuarioService usuarioService, RolService rolService) {
        this.usuarioService = usuarioService;
        this.rolService = rolService;
    }

    @GetMapping("/perfil")
    @Operation(summary = "Datos de Mi perfil")
    public EntityModel<UsuarioDTO> obtenerPerfil(@RequestHeader(value = RUT, required = false) String rut) {
        return perfil(UsuarioDTO.desde(rolService.exigirSesion(rut)));
    }

    @PutMapping("/perfil")
    @Operation(summary = "Actualiza los datos de Mi perfil")
    public EntityModel<UsuarioDTO> actualizarPerfil(@RequestHeader(value = RUT, required = false) String rut,
                                                    @RequestBody PerfilDTO datos) {
        Usuario usuario = rolService.exigirSesion(rut);
        return perfil(UsuarioDTO.desde(usuarioService.actualizarPerfil(usuario.getRut(), datos)));
    }

    @GetMapping("/{rut}/datos")
    @Operation(summary = "Datos públicos de un usuario (uso interno de ventas y soporte)")
    public UsuarioDTO obtenerDatos(@PathVariable String rut) {
        return UsuarioDTO.desde(usuarioService.findByRut(rut));
    }

    @GetMapping("/registrados/contar")
    @Operation(summary = "Cuenta los clientes registrados entre dos fechas (uso interno de ms-informes)")
    public long contarClientesRegistrados(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return usuarioService.contarClientesRegistrados(desde, hasta);
    }

    @GetMapping
    @Operation(summary = "Lista los usuarios con filtros por rol, estado y texto")
    public CollectionModel<EntityModel<UsuarioDTO>> listarUsuarios(
            @RequestHeader(value = RUT, required = false) String rutAdmin,
            @RequestParam(required = false) String rol,
            @RequestParam(required = false) EstadoUsuario estado,
            @RequestParam(required = false) String texto) {
        rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return CollectionModel.of(usuarioService.listarUsuarios(rol, estado, texto).stream()
                        .map(UsuarioDTO::desde).map(this::modelo).toList(),
                linkTo(UsuarioController.class).withSelfRel());
    }

    @GetMapping("/{rut}")
    @Operation(summary = "Busca un usuario por RUT")
    public EntityModel<UsuarioDTO> findByRut(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                             @PathVariable String rut) {
        rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return modelo(UsuarioDTO.desde(usuarioService.findByRut(rut)));
    }

    @PostMapping
    @Operation(summary = "Crea un usuario desde el panel")
    public ResponseEntity<EntityModel<UsuarioDTO>> crearUsuario(
            @RequestHeader(value = RUT, required = false) String rutAdmin, @RequestBody UsuarioAdminDTO datos) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(modelo(UsuarioDTO.desde(usuarioService.crearUsuario(datos, admin.getRut()))));
    }

    @PutMapping("/{rut}")
    @Operation(summary = "Edita un usuario")
    public EntityModel<UsuarioDTO> editarUsuario(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                    @PathVariable String rut, @RequestBody UsuarioAdminDTO datos) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return modelo(UsuarioDTO.desde(usuarioService.editarUsuario(rut, datos, admin.getRut())));
    }

    @PatchMapping("/{rut}/rol")
    @Operation(summary = "Asigna un rol a un usuario")
    public EntityModel<UsuarioDTO> asignarRol(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                 @PathVariable String rut, @RequestBody RolDTO datos) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return modelo(UsuarioDTO.desde(usuarioService.asignarRol(rut, datos.getRol(), admin.getRut())));
    }

    @PatchMapping("/{rut}/desactivar")
    @Operation(summary = "Desactiva un usuario")
    public EntityModel<UsuarioDTO> desactivarUsuario(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                        @PathVariable String rut) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return modelo(UsuarioDTO.desde(usuarioService.desactivarUsuario(rut, admin.getRut())));
    }

    @PatchMapping("/{rut}/reactivar")
    @Operation(summary = "Reactiva un usuario")
    public EntityModel<UsuarioDTO> reactivarUsuario(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                       @PathVariable String rut) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return modelo(UsuarioDTO.desde(usuarioService.reactivarUsuario(rut, admin.getRut())));
    }

    @DeleteMapping("/{rut}")
    @Operation(summary = "Elimina un usuario sin pedidos")
    public ResponseEntity<Void> eliminarUsuario(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                                @PathVariable String rut) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        usuarioService.eliminarUsuario(rut, admin.getRut());
        return ResponseEntity.noContent().build();
    }

    private EntityModel<UsuarioDTO> modelo(UsuarioDTO usuario) {
        return EntityModel.of(usuario,
                linkTo(UsuarioController.class).slash(usuario.getRut()).withSelfRel(),
                linkTo(RegistroAccionController.class).slash("administrador").slash(usuario.getRut())
                        .withRel("historial"),
                linkTo(UsuarioController.class).withRel("usuarios"));
    }

    private EntityModel<UsuarioDTO> perfil(UsuarioDTO usuario) {
        return EntityModel.of(usuario,
                linkTo(UsuarioController.class).slash("perfil").withSelfRel(),
                linkTo(NotificacionController.class).withRel("notificaciones"));
    }
}
