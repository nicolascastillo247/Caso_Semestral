package chibson.usuarios.model;

public enum TipoAccion {
    CREAR,
    MODIFICAR,
    ELIMINAR,
    ACTIVAR,
    DESACTIVAR
}
