package chibson.usuarios.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecuperarPasswordDTO {
    private String rut;
    private String correo;
    private String nuevaPassword;
    private String confirmarPassword;
}
