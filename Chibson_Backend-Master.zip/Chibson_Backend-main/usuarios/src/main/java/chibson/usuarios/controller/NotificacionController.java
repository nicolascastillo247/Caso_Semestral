package chibson.usuarios.controller;

import chibson.usuarios.dto.NotificacionDTO;
import chibson.usuarios.model.Notificacion;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.NotificacionService;
import chibson.usuarios.service.RolService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/notificaciones")
@Tag(name = "Notificaciones", description = "Avisos para los usuarios")
public class NotificacionController {
    private static final String RUT = "X-Rut-Usuario";

    private final NotificacionService notificacionService;
    private final RolService rolService;

    public NotificacionController(NotificacionService notificacionService, RolService rolService) {
        this.notificacionService = notificacionService;
        this.rolService = rolService;
    }

    @PostMapping
    @Operation(summary = "Crea un aviso para un usuario (uso interno de otros microservicios)")
    public ResponseEntity<EntityModel<Notificacion>> enviarNotificacion(@RequestBody NotificacionDTO datos) {
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(notificacionService.enviarNotificacion(datos)));
    }

    @GetMapping
    @Operation(summary = "Avisos del usuario con sesión, del más nuevo al más antiguo")
    public CollectionModel<EntityModel<Notificacion>> listarPorUsuario(
            @RequestHeader(value = RUT, required = false) String rut) {
        Usuario usuario = rolService.exigirSesion(rut);
        return CollectionModel.of(notificacionService.listarPorUsuario(usuario.getRut()).stream()
                        .map(this::modelo).toList(),
                linkTo(NotificacionController.class).withSelfRel());
    }

    @PatchMapping("/{id}/leida")
    @Operation(summary = "Marca un aviso como leído")
    public EntityModel<Notificacion> marcarLeida(@RequestHeader(value = RUT, required = false) String rut,
                                                 @PathVariable Long id) {
        Usuario usuario = rolService.exigirSesion(rut);
        return modelo(notificacionService.marcarLeida(id, usuario.getRut()));
    }

    private EntityModel<Notificacion> modelo(Notificacion notificacion) {
        return EntityModel.of(notificacion,
                linkTo(NotificacionController.class).slash(notificacion.getIdNotificacion()).slash("leida")
                        .withRel("marcarLeida"),
                linkTo(NotificacionController.class).withRel("notificaciones"));
    }
}
