package chibson.usuarios.model;

public enum EstadoUsuario {
    ACTIVO,
    DESACTIVADO
}
