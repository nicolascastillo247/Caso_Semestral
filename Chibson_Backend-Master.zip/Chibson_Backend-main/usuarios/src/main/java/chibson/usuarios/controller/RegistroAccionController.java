package chibson.usuarios.controller;

import chibson.usuarios.dto.RegistroAccionDTO;
import chibson.usuarios.model.RegistroAccion;
import chibson.usuarios.model.TipoAccion;
import chibson.usuarios.service.Permisos;
import chibson.usuarios.service.RegistroAccionService;
import chibson.usuarios.service.RolService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/acciones")
@Tag(name = "Historial de acciones", description = "Registro de lo que hacen los administradores")
public class RegistroAccionController {
    private static final String RUT = "X-Rut-Usuario";

    private final RegistroAccionService registroAccionService;
    private final RolService rolService;

    public RegistroAccionController(RegistroAccionService registroAccionService, RolService rolService) {
        this.registroAccionService = registroAccionService;
        this.rolService = rolService;
    }

    @PostMapping
    @Operation(summary = "Registra una acción (uso interno de otros microservicios)")
    public ResponseEntity<EntityModel<RegistroAccion>> registrarAccion(@RequestBody RegistroAccionDTO datos) {
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(registroAccionService.registrarAccion(datos)));
    }

    @GetMapping
    @Operation(summary = "Lista el historial con filtros por texto, tipo, administrador y fechas")
    public CollectionModel<EntityModel<RegistroAccion>> listarAcciones(
            @RequestHeader(value = RUT, required = false) String rutAdmin,
            @RequestParam(required = false) String texto,
            @RequestParam(required = false) TipoAccion tipo,
            @RequestParam(required = false) String administrador,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        rolService.exigirPermiso(rutAdmin, Permisos.VER_HISTORIAL);
        return coleccion(registroAccionService.listarAcciones(texto, tipo, administrador, desde, hasta),
                linkTo(RegistroAccionController.class).withSelfRel());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Detalle de una acción con sus cambios")
    public EntityModel<RegistroAccion> obtenerDetalle(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                                      @PathVariable Long id) {
        rolService.exigirPermiso(rutAdmin, Permisos.VER_HISTORIAL);
        return modelo(registroAccionService.obtenerDetalle(id));
    }

    @GetMapping("/administrador/{rut}")
    @Operation(summary = "Acciones de un administrador")
    public CollectionModel<EntityModel<RegistroAccion>> listarPorAdministrador(
            @RequestHeader(value = RUT, required = false) String rutAdmin, @PathVariable String rut) {
        rolService.exigirPermiso(rutAdmin, Permisos.VER_HISTORIAL);
        return coleccion(registroAccionService.listarPorAdministrador(rut),
                linkTo(RegistroAccionController.class).slash("administrador").slash(rut).withSelfRel());
    }

    private EntityModel<RegistroAccion> modelo(RegistroAccion accion) {
        return EntityModel.of(accion,
                linkTo(RegistroAccionController.class).slash(accion.getIdRegistro()).withSelfRel(),
                linkTo(RegistroAccionController.class).withRel("acciones"));
    }

    private CollectionModel<EntityModel<RegistroAccion>> coleccion(List<RegistroAccion> acciones, Link self) {
        return CollectionModel.of(acciones.stream().map(this::modelo).toList(), self);
    }
}
