package chibson.usuarios.controller;

import chibson.usuarios.dto.CambioPasswordDTO;
import chibson.usuarios.dto.LoginDTO;
import chibson.usuarios.dto.LoginRespuestaDTO;
import chibson.usuarios.dto.RegistroUsuarioDTO;
import chibson.usuarios.dto.RecuperarPasswordDTO;
import chibson.usuarios.dto.UsuarioDTO;
import chibson.usuarios.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Autenticación", description = "Registro, inicio de sesión y contraseñas")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/registro")
    @Operation(summary = "Registra un cliente nuevo")
    public ResponseEntity<EntityModel<UsuarioDTO>> registrar(@RequestBody RegistroUsuarioDTO datos) {
        UsuarioDTO usuario = UsuarioDTO.desde(authService.registrar(datos));
        return ResponseEntity.status(HttpStatus.CREATED).body(EntityModel.of(usuario,
                linkTo(UsuarioController.class).slash("perfil").withRel("perfil"),
                linkTo(AuthController.class).slash("login").withRel("login")));
    }

    @PostMapping("/login")
    @Operation(summary = "Inicia sesión con correo y contraseña; entrega el token")
    public EntityModel<LoginRespuestaDTO> login(@RequestBody LoginDTO datos) {
        return EntityModel.of(authService.login(datos),
                linkTo(UsuarioController.class).slash("perfil").withRel("perfil"),
                linkTo(NotificacionController.class).withRel("notificaciones"));
    }

    @PostMapping("/recuperar")
    @Operation(summary = "Recupera la contraseña con el RUT y el correo")
    public Map<String, String> recuperarPassword(@RequestBody RecuperarPasswordDTO datos) {
        authService.recuperarPassword(datos);
        return Map.of("mensaje", "La contraseña se actualizó correctamente");
    }

    @PutMapping("/password")
    @Operation(summary = "Cambia la contraseña del usuario con sesión")
    public Map<String, String> cambiarPassword(@RequestHeader(value = "X-Rut-Usuario", required = false) String rut,
                                               @RequestBody CambioPasswordDTO datos) {
        authService.cambiarPassword(rut, datos);
        return Map.of("mensaje", "La contraseña se actualizó correctamente");
    }
}
