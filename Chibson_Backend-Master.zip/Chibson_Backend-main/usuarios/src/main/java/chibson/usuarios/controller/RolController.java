package chibson.usuarios.controller;

import chibson.usuarios.model.Permiso;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.Permisos;
import chibson.usuarios.service.RolService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

@RestController
@RequestMapping("/api/roles")
@Tag(name = "Roles y permisos", description = "Roles, permisos y verificación de acceso")
public class RolController {
    private static final String RUT = "X-Rut-Usuario";

    private final RolService rolService;

    public RolController(RolService rolService) {
        this.rolService = rolService;
    }

    @GetMapping
    @Operation(summary = "Lista los roles con sus permisos")
    public CollectionModel<EntityModel<Rol>> listarRoles(@RequestHeader(value = RUT, required = false) String rutAdmin) {
        rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return CollectionModel.of(rolService.listarRoles().stream().map(this::modelo).toList(),
                linkTo(RolController.class).withSelfRel());
    }

    @GetMapping("/permisos")
    @Operation(summary = "Lista todos los permisos disponibles")
    public List<Permiso> listarPermisos(@RequestHeader(value = RUT, required = false) String rutAdmin) {
        rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return rolService.listarPermisos();
    }

    @PutMapping("/{idRol}/permisos")
    @Operation(summary = "Reemplaza los permisos de un rol")
    public EntityModel<Rol> modificarPermisos(@RequestHeader(value = RUT, required = false) String rutAdmin,
                                              @PathVariable Long idRol, @RequestBody List<Long> idsPermisos) {
        Usuario admin = rolService.exigirPermiso(rutAdmin, Permisos.GESTIONAR_USUARIOS);
        return modelo(rolService.modificarPermisos(idRol, idsPermisos, admin.getRut()));
    }

    @GetMapping("/verificar")
    @Operation(summary = "Indica si un usuario tiene un permiso (uso interno de otros microservicios)")
    public boolean tienePermiso(@RequestParam String rut, @RequestParam String permiso) {
        return rolService.tienePermiso(rut, permiso);
    }

    private EntityModel<Rol> modelo(Rol rol) {
        return EntityModel.of(rol,
                linkTo(RolController.class).slash(rol.getIdRol()).slash("permisos").withRel("modificarPermisos"),
                linkTo(RolController.class).withRel("roles"));
    }
}
