package chibson.usuarios.controller;

import chibson.usuarios.dto.RegistroAccionDTO;
import chibson.usuarios.model.RegistroAccion;
import chibson.usuarios.model.TipoAccion;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.RegistroAccionService;
import chibson.usuarios.service.RolService;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RegistroAccionController.class)
@ActiveProfiles("test")
class RegistroAccionControllerTest {
    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private RegistroAccionService registroAccionService;
    @MockitoBean
    private RolService rolService;

    @Autowired
    private MockMvc mvc;

    private RegistroAccion accion(Long id) {
        RegistroAccion r = new RegistroAccion();
        r.setIdRegistro(id);
        r.setRutAdministrador(ADMIN);
        r.setTipo(TipoAccion.CREAR);
        r.setModulo("Usuarios");
        r.setDescripcion("Creó un usuario");
        return r;
    }

    @Test
    void logAction201() throws Exception {
        when(registroAccionService.registrarAccion(any(RegistroAccionDTO.class))).thenReturn(accion(1L));

        mvc.perform(post("/api/acciones").contentType(JSON).content("{\"rutAdministrador\":\"12345678-5\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.modulo").value("Usuarios"));
    }

    @Test
    void listActions() throws Exception {
        when(registroAccionService.listarAcciones("crear", TipoAccion.CREAR, ADMIN,
                LocalDate.of(2026, 1, 1), LocalDate.of(2026, 12, 31))).thenReturn(List.of(accion(1L)));

        mvc.perform(get("/api/acciones").header("X-Rut-Usuario", ADMIN)
                        .param("texto", "crear").param("tipo", "CREAR").param("administrador", ADMIN)
                        .param("desde", "2026-01-01").param("hasta", "2026-12-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.acciones[0].idRegistro").value(1));
        verify(rolService).exigirPermiso(ADMIN, "VER_HISTORIAL");
    }

    @Test
    void detailAndByAdmin() throws Exception {
        when(registroAccionService.obtenerDetalle(3L)).thenReturn(accion(3L));
        when(registroAccionService.listarPorAdministrador(ADMIN)).thenReturn(List.of(accion(4L)));

        mvc.perform(get("/api/acciones/3").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idRegistro").value(3));
        mvc.perform(get("/api/acciones/administrador/12345678-5").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.acciones[0].idRegistro").value(4));
    }

    @Test
    void historyForbidden() throws Exception {
        when(rolService.exigirPermiso(CLIENTE, "VER_HISTORIAL"))
                .thenThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"));

        mvc.perform(get("/api/acciones/3").header("X-Rut-Usuario", CLIENTE)).andExpect(status().isForbidden());
    }
}
