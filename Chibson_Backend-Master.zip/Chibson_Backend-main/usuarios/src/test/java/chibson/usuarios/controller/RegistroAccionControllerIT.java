package chibson.usuarios.controller;

import chibson.usuarios.LimpiezaBaseDatos;
import chibson.usuarios.client.VentasClient;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.RolRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.PasswordHasher;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class RegistroAccionControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Usuario guardarCliente(String rut, String correo) {
        Rol rol = rolRepository.findByNombreIgnoreCase(Rol.CLIENTE).orElseThrow();
        return usuarioRepository.save(new Usuario(rut, "Ana", "Pérez", "Soto", "ana" + rut.charAt(0), correo, "+56911111111",
                PasswordHasher.hashear("Clave1234"), null, null, null, null, EstadoUsuario.ACTIVO, LocalDate.now(), rol));
    }

    private static final String ACCION = "{\"rutAdministrador\":\"12345678-5\",\"tipo\":\"CREAR\",\"modulo\":\"Productos\","
            + "\"descripcion\":\"Creó el producto Stratocaster\",\"cambios\":[{\"campo\":\"precio\",\"valorAnterior\":\"1\",\"valorNuevo\":\"2\"}]}";

    private Long registrar() throws Exception {
        String json = mockMvc.perform(post("/api/acciones").contentType(JSON).content(ACCION))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return Long.valueOf(json.replaceAll(".*?\"idRegistro\":(\\d+).*", "$1"));
    }

    @Test
    void logAction() throws Exception {
        mockMvc.perform(post("/api/acciones").contentType(JSON).content(ACCION))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.tipo").value("CREAR"))
                .andExpect(jsonPath("$.cambios.length()").value(1));
    }

    @Test
    void logActionInvalid400() throws Exception {
        mockMvc.perform(post("/api/acciones").contentType(JSON).content(ACCION.replace("CREAR", "BORRAR_TODO")))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/acciones").contentType(JSON).content(ACCION.replace("Productos", " ")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void listWithFilters() throws Exception {
        registrar();
        mockMvc.perform(post("/api/acciones").contentType(JSON)
                .content(ACCION.replace("CREAR", "ELIMINAR").replace("Creó el producto Stratocaster", "Eliminó una noticia")));

        mockMvc.perform(get("/api/acciones").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.acciones.length()").value(2));
        mockMvc.perform(get("/api/acciones").header("X-Rut-Usuario", ADMIN).param("tipo", "ELIMINAR"))
                .andExpect(jsonPath("$._embedded.acciones.length()").value(1));
        mockMvc.perform(get("/api/acciones").header("X-Rut-Usuario", ADMIN).param("texto", "stratocaster"))
                .andExpect(jsonPath("$._embedded.acciones.length()").value(1));
        mockMvc.perform(get("/api/acciones").header("X-Rut-Usuario", ADMIN).param("administrador", "12345678-5"))
                .andExpect(jsonPath("$._embedded.acciones.length()").value(2));
        mockMvc.perform(get("/api/acciones").header("X-Rut-Usuario", ADMIN).param("desde", "2000-01-01").param("hasta", "2999-01-01"))
                .andExpect(jsonPath("$._embedded.acciones.length()").value(2));
    }

    @Test
    void detailAndNotFound() throws Exception {
        Long id = registrar();

        mockMvc.perform(get("/api/acciones/" + id).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.cambios[0].campo").value("precio"));
        mockMvc.perform(get("/api/acciones/999999").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void listByAdministrator() throws Exception {
        registrar();

        mockMvc.perform(get("/api/acciones/administrador/" + ADMIN).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.acciones.length()").value(1));
    }

    @Test
    void historyRequiresPermission() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/acciones").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isForbidden());
        mockMvc.perform(get("/api/acciones"))
                .andExpect(status().isUnauthorized());
    }
}
