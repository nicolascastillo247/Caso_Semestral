package chibson.usuarios.controller;

import chibson.usuarios.dto.NotificacionDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Notificacion;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.NotificacionService;
import chibson.usuarios.service.RolService;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(NotificacionController.class)
@ActiveProfiles("test")
class NotificacionControllerTest {
    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private NotificacionService notificacionService;
    @MockitoBean
    private RolService rolService;

    @Autowired
    private MockMvc mvc;

    private Usuario usuario(String rut, String rolNombre) {
        Usuario u = new Usuario();
        u.setRut(rut);
        u.setNombres("Ana");
        u.setPrimerApellido("Pérez");
        u.setSegundoApellido("Soto");
        u.setUsername("ana");
        u.setCorreo("ana@correo.cl");
        u.setEstado(EstadoUsuario.ACTIVO);
        u.setFechaRegistro(LocalDate.of(2026, 1, 1));
        u.setRol(new Rol(1L, rolNombre, new HashSet<>()));
        return u;
    }

    @Test
    void sendNotification201() throws Exception {
        Notificacion n = new Notificacion();
        n.setIdNotificacion(1L);
        n.setMensaje("Hola");
        when(notificacionService.enviarNotificacion(any(NotificacionDTO.class))).thenReturn(n);

        mvc.perform(post("/api/notificaciones").contentType(JSON)
                        .content("{\"rutUsuario\":\"11111111-1\",\"mensaje\":\"Hola\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.mensaje").value("Hola"));
    }

    @Test
    void listAndMarkRead() throws Exception {
        Notificacion n = new Notificacion();
        n.setIdNotificacion(1L);
        n.setLeida(true);
        when(rolService.exigirSesion(CLIENTE)).thenReturn(usuario(CLIENTE, Rol.CLIENTE));
        when(notificacionService.listarPorUsuario(CLIENTE)).thenReturn(List.of(n));
        when(notificacionService.marcarLeida(1L, CLIENTE)).thenReturn(n);

        mvc.perform(get("/api/notificaciones").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.notificaciones[0].idNotificacion").value(1));
        mvc.perform(patch("/api/notificaciones/1/leida").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.leida").value(true));
    }
}
