package chibson.usuarios.controller;

import chibson.usuarios.dto.CambioPasswordDTO;
import chibson.usuarios.dto.LoginDTO;
import chibson.usuarios.dto.LoginRespuestaDTO;
import chibson.usuarios.dto.RecuperarPasswordDTO;
import chibson.usuarios.dto.RegistroUsuarioDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.AuthService;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuthController.class)
@ActiveProfiles("test")
class AuthControllerTest {
    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private AuthService authService;

    @Autowired
    private MockMvc mvc;

    private Usuario usuario(String rut, String rolNombre) {
        Usuario u = new Usuario();
        u.setRut(rut);
        u.setNombres("Ana");
        u.setPrimerApellido("Pérez");
        u.setSegundoApellido("Soto");
        u.setUsername("ana");
        u.setCorreo("ana@correo.cl");
        u.setEstado(EstadoUsuario.ACTIVO);
        u.setFechaRegistro(LocalDate.of(2026, 1, 1));
        u.setRol(new Rol(1L, rolNombre, new HashSet<>()));
        return u;
    }

    @Test
    void register201() throws Exception {
        when(authService.registrar(any(RegistroUsuarioDTO.class))).thenReturn(usuario(CLIENTE, Rol.CLIENTE));

        mvc.perform(post("/api/auth/registro").contentType(JSON).content("{\"rut\":\"11111111-1\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.rut").value(CLIENTE))
                .andExpect(jsonPath("$.rol").value("CLIENTE"));
    }

    @Test
    void loginToken() throws Exception {
        when(authService.login(any(LoginDTO.class))).thenReturn(
                new LoginRespuestaDTO(CLIENTE, "Ana", "Pérez", "ana", "CLIENTE", List.of("VER_PERFIL"), "tok"));

        mvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"a@b.cl\",\"password\":\"x\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("tok"))
                .andExpect(jsonPath("$.permisos[0]").value("VER_PERFIL"));
    }

    @Test
    void loginInvalid401() throws Exception {
        when(authService.login(any(LoginDTO.class)))
                .thenThrow(new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales inválidas"));

        mvc.perform(post("/api/auth/login").contentType(JSON).content("{}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void recoverPassword() throws Exception {
        mvc.perform(post("/api/auth/recuperar").contentType(JSON).content("{\"rut\":\"11111111-1\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mensaje").exists());

        verify(authService).recuperarPassword(any(RecuperarPasswordDTO.class));
    }

    @Test
    void changePassword() throws Exception {
        mvc.perform(put("/api/auth/password").header("X-Rut-Usuario", CLIENTE)
                        .contentType(JSON).content("{\"passwordActual\":\"a\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mensaje").exists());

        verify(authService).cambiarPassword(eq(CLIENTE), any(CambioPasswordDTO.class));
    }
}
