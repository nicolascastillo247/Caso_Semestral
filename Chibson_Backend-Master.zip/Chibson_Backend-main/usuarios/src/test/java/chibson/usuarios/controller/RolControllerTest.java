package chibson.usuarios.controller;

import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Permiso;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.RolService;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(RolController.class)
@ActiveProfiles("test")
class RolControllerTest {
    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private RolService rolService;

    @Autowired
    private MockMvc mvc;

    private Usuario usuario(String rut, String rolNombre) {
        Usuario u = new Usuario();
        u.setRut(rut);
        u.setNombres("Ana");
        u.setPrimerApellido("Pérez");
        u.setSegundoApellido("Soto");
        u.setUsername("ana");
        u.setCorreo("ana@correo.cl");
        u.setEstado(EstadoUsuario.ACTIVO);
        u.setFechaRegistro(LocalDate.of(2026, 1, 1));
        u.setRol(new Rol(1L, rolNombre, new HashSet<>()));
        return u;
    }

    @Test
    void listRolesPermissions() throws Exception {
        when(rolService.listarRoles()).thenReturn(List.of(new Rol(1L, "CLIENTE", new HashSet<>())));
        when(rolService.listarPermisos()).thenReturn(List.of(new Permiso(1L, "VER_PERFIL", "Ver perfil")));

        mvc.perform(get("/api/roles").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.roles[0].nombre").value("CLIENTE"));
        mvc.perform(get("/api/roles/permisos").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].codigo").value("VER_PERFIL"));
    }

    @Test
    void updatePermissions() throws Exception {
        when(rolService.exigirPermiso(ADMIN, "GESTIONAR_USUARIOS")).thenReturn(usuario(ADMIN, Rol.ADMINISTRADOR));
        when(rolService.modificarPermisos(2L, List.of(1L, 2L), ADMIN)).thenReturn(new Rol(2L, "CLIENTE", Set.of()));

        mvc.perform(put("/api/roles/2/permisos").header("X-Rut-Usuario", ADMIN).contentType(JSON).content("[1,2]"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idRol").value(2));
    }

    @Test
    void verifyPermission() throws Exception {
        when(rolService.tienePermiso(ADMIN, "VER_HISTORIAL")).thenReturn(true);

        mvc.perform(get("/api/roles/verificar").param("rut", ADMIN).param("permiso", "VER_HISTORIAL"))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }
}
