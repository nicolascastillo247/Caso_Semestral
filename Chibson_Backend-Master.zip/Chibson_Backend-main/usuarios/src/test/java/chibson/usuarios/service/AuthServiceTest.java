package chibson.usuarios.service;

import chibson.usuarios.dto.CambioPasswordDTO;
import chibson.usuarios.dto.LoginDTO;
import chibson.usuarios.dto.LoginRespuestaDTO;
import chibson.usuarios.dto.RecuperarPasswordDTO;
import chibson.usuarios.dto.RegistroUsuarioDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Permiso;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.AuthService;
import chibson.usuarios.service.PasswordHasher;
import chibson.usuarios.service.RolService;
import chibson.usuarios.service.TokenService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {
    @Mock
    private UsuarioRepository usuarioRepository;
    @Mock
    private RolService rolService;
    @Mock
    private TokenService tokenService;
    @InjectMocks
    private AuthService authService;

    private Rol cliente;

    @BeforeEach
    void setUp() {
        cliente = new Rol(2L, Rol.CLIENTE, new HashSet<>(Set.of(new Permiso(1L, "VER_PERFIL", "Ver perfil"))));
    }

    private Usuario usuario(String password, EstadoUsuario estado) {
        Usuario u = new Usuario();
        u.setRut("12345678-5");
        u.setNombres("Ana");
        u.setPrimerApellido("Pérez");
        u.setUsername("ana");
        u.setCorreo("ana@correo.cl");
        u.setPassword(PasswordHasher.hashear(password));
        u.setEstado(estado);
        u.setRol(cliente);
        return u;
    }

    private RegistroUsuarioDTO registro() {
        return new RegistroUsuarioDTO("12.345.678-5", "Ana", "Pérez", "Soto", "ana", "Ana@Correo.cl",
                "Clave1234", "Clave1234");
    }

    @Test
    void registerCreatesClient() {
        when(usuarioRepository.existsById("12345678-5")).thenReturn(false);
        when(usuarioRepository.existsByCorreoIgnoreCase("ana@correo.cl")).thenReturn(false);
        when(rolService.buscarRol(Rol.CLIENTE)).thenReturn(cliente);
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(i -> i.getArgument(0));

        Usuario creado = authService.registrar(registro());

        assertEquals("12345678-5", creado.getRut());
        assertEquals("ana@correo.cl", creado.getCorreo());
        assertEquals(EstadoUsuario.ACTIVO, creado.getEstado());
        assertEquals(cliente, creado.getRol());
        assertNotEquals("Clave1234", creado.getPassword());
        assertTrue(PasswordHasher.coincide("Clave1234", creado.getPassword()));
    }

    @Test
    void registerDuplicateRut() {
        when(usuarioRepository.existsById("12345678-5")).thenReturn(true);

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> authService.registrar(registro()));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void registerDuplicateEmail() {
        when(usuarioRepository.existsById("12345678-5")).thenReturn(false);
        when(usuarioRepository.existsByCorreoIgnoreCase("ana@correo.cl")).thenReturn(true);

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> authService.registrar(registro()));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
    }

    @Test
    void registerPasswordMismatch() {
        when(usuarioRepository.existsById("12345678-5")).thenReturn(false);
        when(usuarioRepository.existsByCorreoIgnoreCase("ana@correo.cl")).thenReturn(false);
        RegistroUsuarioDTO datos = registro();
        datos.setConfirmarPassword("Otra12345");

        assertThrows(ResponseStatusException.class, () -> authService.registrar(datos));
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void loginOk() {
        when(usuarioRepository.findByCorreoIgnoreCase("ana@correo.cl"))
                .thenReturn(Optional.of(usuario("Clave1234", EstadoUsuario.ACTIVO)));
        when(tokenService.crear("12345678-5")).thenReturn("token-firmado");

        LoginRespuestaDTO respuesta = authService.login(new LoginDTO(" ana@correo.cl ", "Clave1234"));

        assertEquals("12345678-5", respuesta.getRut());
        assertEquals(Rol.CLIENTE, respuesta.getRol());
        assertEquals("token-firmado", respuesta.getToken());
        assertTrue(respuesta.getPermisos().contains("VER_PERFIL"));
    }

    @Test
    void loginWrongPassword() {
        when(usuarioRepository.findByCorreoIgnoreCase("ana@correo.cl"))
                .thenReturn(Optional.of(usuario("Clave1234", EstadoUsuario.ACTIVO)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginDTO("ana@correo.cl", "Incorrecta1")));

        assertEquals(HttpStatus.UNAUTHORIZED, e.getStatusCode());
        verify(tokenService, never()).crear(any());
    }

    @Test
    void loginUnknownEmail() {
        when(usuarioRepository.findByCorreoIgnoreCase("nadie@correo.cl")).thenReturn(Optional.empty());

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginDTO("nadie@correo.cl", "Clave1234")));

        assertEquals(HttpStatus.UNAUTHORIZED, e.getStatusCode());
        assertEquals("Correo o contraseña incorrectos", e.getReason());
    }

    @Test
    void loginEmpty() {
        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginDTO(null, null)));

        assertEquals(HttpStatus.UNAUTHORIZED, e.getStatusCode());
    }

    @Test
    void loginInactive() {
        when(usuarioRepository.findByCorreoIgnoreCase("ana@correo.cl"))
                .thenReturn(Optional.of(usuario("Clave1234", EstadoUsuario.DESACTIVADO)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> authService.login(new LoginDTO("ana@correo.cl", "Clave1234")));

        assertEquals(HttpStatus.FORBIDDEN, e.getStatusCode());
    }

    @Test
    void recoverOk() {
        Usuario u = usuario("Vieja1234", EstadoUsuario.ACTIVO);
        when(usuarioRepository.findById("12345678-5")).thenReturn(Optional.of(u));

        authService.recuperarPassword(new RecuperarPasswordDTO("12345678-5", "ana@correo.cl", "Nueva1234", "Nueva1234"));

        assertTrue(PasswordHasher.coincide("Nueva1234", u.getPassword()));
        assertFalse(PasswordHasher.coincide("Vieja1234", u.getPassword()));
        verify(usuarioRepository).save(u);
    }

    @Test
    void recoverWrongEmail() {
        Usuario u = usuario("Vieja1234", EstadoUsuario.ACTIVO);
        String hashOriginal = u.getPassword();
        when(usuarioRepository.findById("12345678-5")).thenReturn(Optional.of(u));

        assertThrows(ResponseStatusException.class, () -> authService.recuperarPassword(
                new RecuperarPasswordDTO("12345678-5", "otro@correo.cl", "Nueva1234", "Nueva1234")));

        assertEquals(hashOriginal, u.getPassword());
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void changePassword() {
        Usuario u = usuario("Vieja1234", EstadoUsuario.ACTIVO);
        when(rolService.exigirSesion("12345678-5")).thenReturn(u);

        authService.cambiarPassword("12345678-5", new CambioPasswordDTO("Nueva1234", "Nueva1234"));

        assertTrue(PasswordHasher.coincide("Nueva1234", u.getPassword()));
        verify(usuarioRepository).save(u);
    }

    @Test
    void changePasswordMismatch() {
        when(rolService.exigirSesion("12345678-5")).thenReturn(usuario("Vieja1234", EstadoUsuario.ACTIVO));

        assertThrows(ResponseStatusException.class,
                () -> authService.cambiarPassword("12345678-5", new CambioPasswordDTO("Nueva1234", null)));
    }
}
