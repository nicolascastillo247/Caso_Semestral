package chibson.usuarios.controller;

import chibson.usuarios.LimpiezaBaseDatos;
import chibson.usuarios.client.VentasClient;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Permiso;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.PermisoRepository;
import chibson.usuarios.repository.RolRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.PasswordHasher;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class RolControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Usuario guardarCliente(String rut, String correo) {
        Rol rol = rolRepository.findByNombreIgnoreCase(Rol.CLIENTE).orElseThrow();
        return usuarioRepository.save(new Usuario(rut, "Ana", "Pérez", "Soto", "ana" + rut.charAt(0), correo, "+56911111111",
                PasswordHasher.hashear("Clave1234"), null, null, null, null, EstadoUsuario.ACTIVO, LocalDate.now(), rol));
    }
    @Autowired
    private PermisoRepository permisoRepository;

    private Long idRolCliente() {
        return rolRepository.findByNombreIgnoreCase(Rol.CLIENTE).orElseThrow().getIdRol();
    }

    @Test
    void listRoles() throws Exception {
        mockMvc.perform(get("/api/roles").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.roles.length()").value(2));
    }

    @Test
    void listPermissions() throws Exception {
        mockMvc.perform(get("/api/roles/permisos").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(9));
    }

    @Test
    void rolesRequireAdmin() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/roles").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isForbidden());
        mockMvc.perform(get("/api/roles/permisos"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void verifyPermission() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/roles/verificar").param("rut", ADMIN).param("permiso", "GESTIONAR_PRODUCTOS"))
                .andExpect(content().string("true"));
        mockMvc.perform(get("/api/roles/verificar").param("rut", CLIENTE).param("permiso", "GESTIONAR_PRODUCTOS"))
                .andExpect(content().string("false"));
        mockMvc.perform(get("/api/roles/verificar").param("rut", "99999999-9").param("permiso", "GESTIONAR_PRODUCTOS"))
                .andExpect(content().string("false"));
    }

    @Test
    void updateRolePermissions() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        Permiso permiso = permisoRepository.findByCodigo("VER_VENTAS").orElseThrow();
        String url = "/api/roles/" + idRolCliente() + "/permisos";
        try {
            mockMvc.perform(put(url).header("X-Rut-Usuario", ADMIN).contentType(JSON)
                            .content("[" + permiso.getIdPermiso() + "]"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.permisos.length()").value(1));
            mockMvc.perform(get("/api/roles/verificar").param("rut", CLIENTE).param("permiso", "VER_VENTAS"))
                    .andExpect(content().string("true"));
        } finally {
            mockMvc.perform(put(url).header("X-Rut-Usuario", ADMIN).contentType(JSON).content("[]"))
                    .andExpect(status().isOk());
        }
        mockMvc.perform(get("/api/roles/verificar").param("rut", CLIENTE).param("permiso", "VER_VENTAS"))
                .andExpect(content().string("false"));
    }

    @Test
    void updateUnknownPermission400() throws Exception {
        mockMvc.perform(put("/api/roles/" + idRolCliente() + "/permisos").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("[999999]"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateUnknownRole404() throws Exception {
        mockMvc.perform(put("/api/roles/999999/permisos").header("X-Rut-Usuario", ADMIN).contentType(JSON).content("[]"))
                .andExpect(status().isNotFound());
    }
}
