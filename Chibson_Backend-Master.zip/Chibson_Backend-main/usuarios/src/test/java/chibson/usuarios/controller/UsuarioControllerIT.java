package chibson.usuarios.controller;

import chibson.usuarios.LimpiezaBaseDatos;
import chibson.usuarios.client.VentasClient;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.RolRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.PasswordHasher;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class UsuarioControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Usuario guardarCliente(String rut, String correo) {
        Rol rol = rolRepository.findByNombreIgnoreCase(Rol.CLIENTE).orElseThrow();
        return usuarioRepository.save(new Usuario(rut, "Ana", "Pérez", "Soto", "ana" + rut.charAt(0), correo, "+56911111111",
                PasswordHasher.hashear("Clave1234"), null, null, null, null, EstadoUsuario.ACTIVO, LocalDate.now(), rol));
    }

    private static final String NUEVO = "{\"rut\":\"22222222-2\",\"nombres\":\"Luis\",\"primerApellido\":\"Rojas\",\"segundoApellido\":\"Mena\",\"username\":\"luis\",\"correo\":\"luis@correo.cl\",\"telefono\":\"+56922222222\",\"rol\":\"CLIENTE\",\"password\":\"Clave1234\"}";

    @Test
    void profileGetAndUpdate() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/usuarios/perfil").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.correo").value("ana@correo.cl"));
        mockMvc.perform(put("/api/usuarios/perfil").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"nombres\":\"Ana María\",\"primerApellido\":\"Pérez\",\"segundoApellido\":\"Soto\",\"username\":\"anita\","
                                + "\"telefono\":\"+56933333333\",\"region\":\"Metropolitana\",\"ciudadComuna\":\"Santiago\",\"numero\":\"10\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombres").value("Ana María"))
                .andExpect(jsonPath("$.region").value("Metropolitana"));
    }

    @Test
    void profileWithoutSession401() throws Exception {
        mockMvc.perform(get("/api/usuarios/perfil"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void profileUpdateMissingRegion400() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(put("/api/usuarios/perfil").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"nombres\":\"Ana\",\"primerApellido\":\"Pérez\",\"segundoApellido\":\"Soto\",\"username\":\"ana\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void publicDataAndNotFound() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/usuarios/" + CLIENTE + "/datos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value(CLIENTE));
        mockMvc.perform(get("/api/usuarios/33333333-3/datos"))
                .andExpect(status().isNotFound());
    }

    @Test
    void countRegisteredClients() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/usuarios/registrados/contar"))
                .andExpect(content().string("1"));
        mockMvc.perform(get("/api/usuarios/registrados/contar").param("desde", "2000-01-01").param("hasta", "2999-01-01"))
                .andExpect(content().string("1"));
        mockMvc.perform(get("/api/usuarios/registrados/contar").param("desde", "2026-12-01").param("hasta", "2026-01-01"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void adminListWithFilters() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/usuarios").header("X-Rut-Usuario", ADMIN))
                .andExpect(jsonPath("$._embedded.usuarios.length()").value(2));
        mockMvc.perform(get("/api/usuarios").header("X-Rut-Usuario", ADMIN).param("rol", "CLIENTE"))
                .andExpect(jsonPath("$._embedded.usuarios.length()").value(1));
        mockMvc.perform(get("/api/usuarios").header("X-Rut-Usuario", ADMIN).param("estado", "DESACTIVADO"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/usuarios").header("X-Rut-Usuario", ADMIN).param("texto", "ANA@"))
                .andExpect(jsonPath("$._embedded.usuarios.length()").value(1));
    }

    @Test
    void clientCannotListUsers403() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/usuarios").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isForbidden());
        mockMvc.perform(get("/api/usuarios"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void adminFindByRut() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(get("/api/usuarios/" + CLIENTE).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("ana1"));
        mockMvc.perform(get("/api/usuarios/33333333-3").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void adminCreatesUser() throws Exception {
        mockMvc.perform(post("/api/usuarios").header("X-Rut-Usuario", ADMIN).contentType(JSON).content(NUEVO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.rut").value("22222222-2"))
                .andExpect(jsonPath("$.rol").value("CLIENTE"));
        mockMvc.perform(post("/api/usuarios").header("X-Rut-Usuario", ADMIN).contentType(JSON).content(NUEVO))
                .andExpect(status().isConflict());
    }

    @Test
    void adminCreateInvalid400() throws Exception {
        mockMvc.perform(post("/api/usuarios").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content(NUEVO.replace("+56922222222", " ")))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/usuarios").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content(NUEVO.replace("Clave1234", "corta")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void adminEditsUser() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(put("/api/usuarios/" + CLIENTE).header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content(NUEVO.replace("22222222-2", CLIENTE).replace("luis@correo.cl", "nuevo@correo.cl")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombres").value("Luis"))
                .andExpect(jsonPath("$.correo").value("nuevo@correo.cl"));
    }

    @Test
    void adminEditDuplicateEmail409() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        guardarCliente("22222222-2", "luis@correo.cl");

        mockMvc.perform(put("/api/usuarios/" + CLIENTE).header("X-Rut-Usuario", ADMIN).contentType(JSON).content(NUEVO))
                .andExpect(status().isConflict());
    }

    @Test
    void assignRole() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(patch("/api/usuarios/" + CLIENTE + "/rol").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"rol\":\"ADMINISTRADOR\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rol").value("ADMINISTRADOR"));
        mockMvc.perform(patch("/api/usuarios/" + CLIENTE + "/rol").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"rol\":\"NO_EXISTE\"}"))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void deactivateAndReactivate() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        String base = "/api/usuarios/" + CLIENTE;

        mockMvc.perform(patch(base + "/desactivar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("DESACTIVADO"));
        mockMvc.perform(patch(base + "/desactivar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch(base + "/reactivar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("ACTIVO"));
        mockMvc.perform(patch(base + "/reactivar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deleteWithoutOrders() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        when(ventasClient.clienteTienePedidos(CLIENTE)).thenReturn(false);

        mockMvc.perform(delete("/api/usuarios/" + CLIENTE).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNoContent());
        mockMvc.perform(get("/api/usuarios/" + CLIENTE).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void deleteWithOrders409() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        when(ventasClient.clienteTienePedidos(CLIENTE)).thenReturn(true);

        mockMvc.perform(delete("/api/usuarios/" + CLIENTE).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isConflict());
    }
}
