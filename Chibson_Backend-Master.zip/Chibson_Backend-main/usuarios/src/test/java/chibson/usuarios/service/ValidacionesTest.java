package chibson.usuarios.service;

import chibson.usuarios.service.Validaciones;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class ValidacionesTest {
    @Test
    void normalizeRut() {
        assertEquals("12345678-5", Validaciones.normalizarRut("12.345.678-5"));
        assertEquals("12345678-5", Validaciones.normalizarRut("123456785"));
    }

    @Test
    void badCheckDigit() {
        assertThrows(ResponseStatusException.class, () -> Validaciones.normalizarRut("12345678-9"));
    }

    @Test
    void invalidRut() {
        assertThrows(ResponseStatusException.class, () -> Validaciones.normalizarRut(null));
        assertThrows(ResponseStatusException.class, () -> Validaciones.normalizarRut("  "));
        assertThrows(ResponseStatusException.class, () -> Validaciones.normalizarRut("12ab5678-5"));
        assertThrows(ResponseStatusException.class, () -> Validaciones.normalizarRut("1-9"));
    }

    @Test
    void emailLowercase() {
        assertEquals("ana@correo.cl", Validaciones.validarCorreo("  Ana@Correo.cl "));
    }

    @Test
    void invalidEmail() {
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarCorreo("ana@correo"));
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarCorreo("sin-arroba.cl"));
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarCorreo(null));
    }

    @Test
    void validPassword() {
        assertDoesNotThrow(() -> Validaciones.validarPassword("Clave1234", "Clave1234"));
        assertDoesNotThrow(() -> Validaciones.validarPassword("Clave1234", null));
    }

    @Test
    void weakPassword() {
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarPassword("corta1", null));
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarPassword("sololetras", null));
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarPassword("12345678", null));
        assertThrows(ResponseStatusException.class, () -> Validaciones.validarPassword("Clave1234", "Clave9999"));
    }

    @Test
    void requiredOptional() {
        assertEquals("Ana", Validaciones.obligatorio("  Ana ", "nombres"));
        assertThrows(ResponseStatusException.class, () -> Validaciones.obligatorio(" ", "nombres"));
        assertNull(Validaciones.opcional("  "));
        assertEquals("x", Validaciones.opcional(" x "));
    }
}
