package chibson.usuarios.controller;

import chibson.usuarios.dto.PerfilDTO;
import chibson.usuarios.dto.UsuarioAdminDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.service.RolService;
import chibson.usuarios.service.UsuarioService;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UsuarioController.class)
@ActiveProfiles("test")
class UsuarioControllerTest {
    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private UsuarioService usuarioService;
    @MockitoBean
    private RolService rolService;

    @Autowired
    private MockMvc mvc;

    private Usuario usuario(String rut, String rolNombre) {
        Usuario u = new Usuario();
        u.setRut(rut);
        u.setNombres("Ana");
        u.setPrimerApellido("Pérez");
        u.setSegundoApellido("Soto");
        u.setUsername("ana");
        u.setCorreo("ana@correo.cl");
        u.setEstado(EstadoUsuario.ACTIVO);
        u.setFechaRegistro(LocalDate.of(2026, 1, 1));
        u.setRol(new Rol(1L, rolNombre, new HashSet<>()));
        return u;
    }

    @Test
    void profile() throws Exception {
        when(rolService.exigirSesion(CLIENTE)).thenReturn(usuario(CLIENTE, Rol.CLIENTE));

        mvc.perform(get("/api/usuarios/perfil").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("ana"))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.notificaciones.href").exists());
    }

    @Test
    void profileUnauthorized() throws Exception {
        when(rolService.exigirSesion(null)).thenThrow(new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Debe iniciar sesión"));

        mvc.perform(get("/api/usuarios/perfil")).andExpect(status().isUnauthorized());
    }

    @Test
    void updateProfile() throws Exception {
        Usuario u = usuario(CLIENTE, Rol.CLIENTE);
        when(rolService.exigirSesion(CLIENTE)).thenReturn(u);
        when(usuarioService.actualizarPerfil(eq(CLIENTE), any(PerfilDTO.class))).thenReturn(u);

        mvc.perform(put("/api/usuarios/perfil").header("X-Rut-Usuario", CLIENTE)
                        .contentType(JSON).content("{\"nombres\":\"Ana\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombres").value("Ana"));
    }

    @Test
    void publicData() throws Exception {
        when(usuarioService.findByRut(CLIENTE)).thenReturn(usuario(CLIENTE, Rol.CLIENTE));

        mvc.perform(get("/api/usuarios/11111111-1/datos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.primerApellido").value("Pérez"));
    }

    @Test
    void countClients() throws Exception {
        when(usuarioService.contarClientesRegistrados(LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31))).thenReturn(7L);

        mvc.perform(get("/api/usuarios/registrados/contar").param("desde", "2026-01-01").param("hasta", "2026-01-31"))
                .andExpect(status().isOk())
                .andExpect(content().string("7"));
    }

    @Test
    void listUsers() throws Exception {
        when(usuarioService.listarUsuarios("CLIENTE", EstadoUsuario.ACTIVO, "ana"))
                .thenReturn(List.of(usuario(CLIENTE, Rol.CLIENTE)));

        mvc.perform(get("/api/usuarios").header("X-Rut-Usuario", ADMIN)
                        .param("rol", "CLIENTE").param("estado", "ACTIVO").param("texto", "ana"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.usuarios[0].rut").value(CLIENTE))
                .andExpect(jsonPath("$._embedded.usuarios[0]._links.historial.href").exists());
    }

    @Test
    void listUsersForbidden() throws Exception {
        when(rolService.exigirPermiso(CLIENTE, "GESTIONAR_USUARIOS"))
                .thenThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"));

        mvc.perform(get("/api/usuarios").header("X-Rut-Usuario", CLIENTE)).andExpect(status().isForbidden());
    }

    @Test
    void findUserAdmin() throws Exception {
        when(rolService.exigirPermiso(ADMIN, "GESTIONAR_USUARIOS")).thenReturn(usuario(ADMIN, Rol.ADMINISTRADOR));
        when(usuarioService.findByRut(CLIENTE)).thenReturn(usuario(CLIENTE, Rol.CLIENTE));

        mvc.perform(get("/api/usuarios/11111111-1").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value(CLIENTE));
    }

    @Test
    void createUpdateAssignRole() throws Exception {
        when(rolService.exigirPermiso(ADMIN, "GESTIONAR_USUARIOS")).thenReturn(usuario(ADMIN, Rol.ADMINISTRADOR));
        Usuario u = usuario(CLIENTE, Rol.CLIENTE);
        when(usuarioService.crearUsuario(any(UsuarioAdminDTO.class), eq(ADMIN))).thenReturn(u);
        when(usuarioService.editarUsuario(eq(CLIENTE), any(UsuarioAdminDTO.class), eq(ADMIN))).thenReturn(u);
        when(usuarioService.asignarRol(CLIENTE, "ADMINISTRADOR", ADMIN)).thenReturn(u);

        mvc.perform(post("/api/usuarios").header("X-Rut-Usuario", ADMIN).contentType(JSON).content("{}"))
                .andExpect(status().isCreated());
        mvc.perform(put("/api/usuarios/11111111-1").header("X-Rut-Usuario", ADMIN).contentType(JSON).content("{}"))
                .andExpect(status().isOk());
        mvc.perform(patch("/api/usuarios/11111111-1/rol").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"rol\":\"ADMINISTRADOR\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void deactivateReactivateDelete() throws Exception {
        when(rolService.exigirPermiso(ADMIN, "GESTIONAR_USUARIOS")).thenReturn(usuario(ADMIN, Rol.ADMINISTRADOR));
        Usuario u = usuario(CLIENTE, Rol.CLIENTE);
        when(usuarioService.desactivarUsuario(CLIENTE, ADMIN)).thenReturn(u);
        when(usuarioService.reactivarUsuario(CLIENTE, ADMIN)).thenReturn(u);

        mvc.perform(patch("/api/usuarios/11111111-1/desactivar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk());
        mvc.perform(patch("/api/usuarios/11111111-1/reactivar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk());
        mvc.perform(delete("/api/usuarios/11111111-1").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNoContent());

        verify(usuarioService).eliminarUsuario(CLIENTE, ADMIN);
    }
}
