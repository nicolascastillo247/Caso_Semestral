package chibson.usuarios.service;

import chibson.usuarios.service.TokenService;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class TokenServiceTest {
    @Test
    void tokenParts() {
        TokenService servicio = new TokenService("secreto-de-prueba", 3600);

        String[] partes = servicio.crear("12345678-5").split("\\.");

        assertEquals(3, partes.length);
        assertEquals("12345678-5", new String(Base64.getUrlDecoder().decode(partes[0]), StandardCharsets.UTF_8));
    }

    @Test
    void signatureDependsOnSecret() {
        String a = new TokenService("secreto-uno", 3600).crear("12345678-5");
        String b = new TokenService("secreto-dos", 3600).crear("12345678-5");

        assertNotEquals(a.split("\\.")[2], b.split("\\.")[2]);
    }

    @Test
    void differentRuts() {
        TokenService servicio = new TokenService("secreto-de-prueba", 3600);

        assertNotEquals(servicio.crear("12345678-5"), servicio.crear("11111111-1"));
    }
}
