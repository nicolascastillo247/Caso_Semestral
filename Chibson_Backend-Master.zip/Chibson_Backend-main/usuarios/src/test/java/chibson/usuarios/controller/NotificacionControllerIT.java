package chibson.usuarios.controller;

import chibson.usuarios.LimpiezaBaseDatos;
import chibson.usuarios.client.VentasClient;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.RolRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.PasswordHasher;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class NotificacionControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Usuario guardarCliente(String rut, String correo) {
        Rol rol = rolRepository.findByNombreIgnoreCase(Rol.CLIENTE).orElseThrow();
        return usuarioRepository.save(new Usuario(rut, "Ana", "Pérez", "Soto", "ana" + rut.charAt(0), correo, "+56911111111",
                PasswordHasher.hashear("Clave1234"), null, null, null, null, EstadoUsuario.ACTIVO, LocalDate.now(), rol));
    }

    @Test
    void sendNotification() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(post("/api/notificaciones").contentType(JSON)
                        .content("{\"rutUsuario\":\"11111111-1\",\"mensaje\":\"Su pedido fue enviado\",\"referencia\":\"pedido:1\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.mensaje").value("Su pedido fue enviado"))
                .andExpect(jsonPath("$.leida").value(false));
    }

    @Test
    void sendToUnknownUser404() throws Exception {
        mockMvc.perform(post("/api/notificaciones").contentType(JSON)
                        .content("{\"rutUsuario\":\"33333333-3\",\"mensaje\":\"Hola\"}"))
                .andExpect(status().isNotFound());
    }

    @Test
    void sendWithoutMessage400() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(post("/api/notificaciones").contentType(JSON)
                        .content("{\"rutUsuario\":\"11111111-1\",\"mensaje\":\" \"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void listOwnNotifications() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        mockMvc.perform(post("/api/notificaciones").contentType(JSON)
                .content("{\"rutUsuario\":\"11111111-1\",\"mensaje\":\"Uno\"}"));
        mockMvc.perform(post("/api/notificaciones").contentType(JSON)
                .content("{\"rutUsuario\":\"11111111-1\",\"mensaje\":\"Dos\"}"));

        mockMvc.perform(get("/api/notificaciones").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.notificaciones.length()").value(2));
        mockMvc.perform(get("/api/notificaciones").header("X-Rut-Usuario", ADMIN))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/notificaciones"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void markAsReadOnlyOwner() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");
        String json = mockMvc.perform(post("/api/notificaciones").contentType(JSON)
                        .content("{\"rutUsuario\":\"11111111-1\",\"mensaje\":\"Uno\"}"))
                .andReturn().getResponse().getContentAsString();
        String id = json.replaceAll(".*?\"idNotificacion\":(\\d+).*", "$1");

        mockMvc.perform(patch("/api/notificaciones/" + id + "/leida").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isForbidden());
        mockMvc.perform(patch("/api/notificaciones/" + id + "/leida").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.leida").value(true));
        mockMvc.perform(patch("/api/notificaciones/999999/leida").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isNotFound());
    }
}
