package chibson.usuarios.service;

import chibson.usuarios.service.PasswordHasher;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PasswordHasherTest {
    @Test
    void hashHidesPassword() {
        String hash = PasswordHasher.hashear("Admin1234");

        assertFalse(hash.contains("Admin1234"));
        assertTrue(hash.startsWith("pbkdf2$"));
    }

    @Test
    void saltedHashes() {
        assertNotEquals(PasswordHasher.hashear("Clave1234"), PasswordHasher.hashear("Clave1234"));
    }

    @Test
    void matches() {
        String hash = PasswordHasher.hashear("Clave1234");

        assertTrue(PasswordHasher.coincide("Clave1234", hash));
    }

    @Test
    void noMatch() {
        String hash = PasswordHasher.hashear("Clave1234");

        assertFalse(PasswordHasher.coincide("clave1234", hash));
        assertFalse(PasswordHasher.coincide("", hash));
    }

    @Test
    void legacyPlain() {
        assertTrue(PasswordHasher.coincide("Admin1234", "Admin1234"));
        assertFalse(PasswordHasher.coincide("Otra1234", "Admin1234"));
    }

    @Test
    void nullOrCorrupt() {
        assertFalse(PasswordHasher.coincide(null, "pbkdf2$1$a$b"));
        assertFalse(PasswordHasher.coincide("Clave1234", null));
        assertFalse(PasswordHasher.coincide("Clave1234", "pbkdf2$mal$formato"));
        assertFalse(PasswordHasher.coincide("Clave1234", "pbkdf2$abc$!!$!!"));
    }
}
