package chibson.usuarios.controller;

import chibson.usuarios.LimpiezaBaseDatos;
import chibson.usuarios.client.VentasClient;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.RolRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.PasswordHasher;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class AuthControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @MockitoBean
    private VentasClient ventasClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
    }

    private Usuario guardarCliente(String rut, String correo) {
        Rol rol = rolRepository.findByNombreIgnoreCase(Rol.CLIENTE).orElseThrow();
        return usuarioRepository.save(new Usuario(rut, "Ana", "Pérez", "Soto", "ana" + rut.charAt(0), correo, "+56911111111",
                PasswordHasher.hashear("Clave1234"), null, null, null, null, EstadoUsuario.ACTIVO, LocalDate.now(), rol));
    }

    private static final String REGISTRO = "{\"rut\":\"11111111-1\",\"nombres\":\"Ana\",\"primerApellido\":\"Pérez\",\"segundoApellido\":\"Soto\",\"username\":\"ana\",\"correo\":\"ana@correo.cl\",\"password\":\"Clave1234\",\"confirmarPassword\":\"Clave1234\"}";

    @Test
    void registerClient() throws Exception {
        mockMvc.perform(post("/api/auth/registro").contentType(JSON).content(REGISTRO))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.rut").value(CLIENTE))
                .andExpect(jsonPath("$.rol").value("CLIENTE"))
                .andExpect(jsonPath("$.password").doesNotExist());
    }

    @Test
    void registerDuplicates409() throws Exception {
        guardarCliente(CLIENTE, "otro@correo.cl");

        mockMvc.perform(post("/api/auth/registro").contentType(JSON).content(REGISTRO))
                .andExpect(status().isConflict());
        mockMvc.perform(post("/api/auth/registro").contentType(JSON)
                        .content(REGISTRO.replace("11111111-1", "22222222-2").replace("ana@correo.cl", "otro@correo.cl")))
                .andExpect(status().isConflict());
    }

    @Test
    void registerInvalidData400() throws Exception {
        mockMvc.perform(post("/api/auth/registro").contentType(JSON).content(REGISTRO.replace("11111111-1", "11111111-9")))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/auth/registro").contentType(JSON).content(REGISTRO.replace("ana@correo.cl", "no-es-correo")))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/auth/registro").contentType(JSON)
                        .content(REGISTRO.replace("\"confirmarPassword\":\"Clave1234\"", "\"confirmarPassword\":\"Otra1234\"")))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/auth/registro").contentType(JSON)
                        .content(REGISTRO.replace("\"password\":\"Clave1234\"", "\"password\":\"corta\"")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void registerThenLogin() throws Exception {
        mockMvc.perform(post("/api/auth/registro").contentType(JSON).content(REGISTRO))
                .andExpect(status().isCreated());

        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"ANA@correo.cl\",\"password\":\"Clave1234\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andExpect(jsonPath("$.rol").value("CLIENTE"));
    }

    @Test
    void loginAdminHasPermissions() throws Exception {
        mockMvc.perform(post("/api/auth/login").contentType(JSON)
                        .content("{\"correo\":\"admin@chibson.cl\",\"password\":\"Admin1234\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rol").value("ADMINISTRADOR"))
                .andExpect(jsonPath("$.permisos.length()").value(9));
    }

    @Test
    void loginWrongCredentials401() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"ana@correo.cl\",\"password\":\"Mala1234\"}"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"nadie@correo.cl\",\"password\":\"Clave1234\"}"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void loginDeactivated403() throws Exception {
        Usuario u = guardarCliente(CLIENTE, "ana@correo.cl");
        u.setEstado(EstadoUsuario.DESACTIVADO);
        usuarioRepository.save(u);

        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"ana@correo.cl\",\"password\":\"Clave1234\"}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void recoverPassword() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(post("/api/auth/recuperar").contentType(JSON)
                        .content("{\"rut\":\"11111111-1\",\"correo\":\"ana@correo.cl\",\"nuevaPassword\":\"Nueva1234\",\"confirmarPassword\":\"Nueva1234\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.mensaje").exists());
        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"ana@correo.cl\",\"password\":\"Nueva1234\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void recoverPasswordMismatch400() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(post("/api/auth/recuperar").contentType(JSON)
                        .content("{\"rut\":\"11111111-1\",\"correo\":\"otra@correo.cl\",\"nuevaPassword\":\"Nueva1234\",\"confirmarPassword\":\"Nueva1234\"}"))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/auth/recuperar").contentType(JSON)
                        .content("{\"rut\":\"11111111-1\",\"correo\":\"ana@correo.cl\",\"nuevaPassword\":\"Nueva1234\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void changePassword() throws Exception {
        guardarCliente(CLIENTE, "ana@correo.cl");

        mockMvc.perform(put("/api/auth/password").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"nuevaPassword\":\"Cambio1234\",\"confirmarPassword\":\"Cambio1234\"}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/auth/login").contentType(JSON).content("{\"correo\":\"ana@correo.cl\",\"password\":\"Cambio1234\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void changePasswordRequiresSession() throws Exception {
        mockMvc.perform(put("/api/auth/password").contentType(JSON)
                        .content("{\"nuevaPassword\":\"Cambio1234\",\"confirmarPassword\":\"Cambio1234\"}"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(put("/api/auth/password").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"nuevaPassword\":\"Cambio1234\"}"))
                .andExpect(status().isBadRequest());
    }
}
