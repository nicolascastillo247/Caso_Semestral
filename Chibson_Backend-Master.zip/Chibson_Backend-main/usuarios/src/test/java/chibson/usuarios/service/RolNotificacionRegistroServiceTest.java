package chibson.usuarios.service;

import chibson.usuarios.dto.DetalleCambioDTO;
import chibson.usuarios.dto.NotificacionDTO;
import chibson.usuarios.dto.RegistroAccionDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Notificacion;
import chibson.usuarios.model.Permiso;
import chibson.usuarios.model.RegistroAccion;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.TipoAccion;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.NotificacionRepository;
import chibson.usuarios.repository.PermisoRepository;
import chibson.usuarios.repository.RegistroAccionRepository;
import chibson.usuarios.repository.RolRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.NotificacionService;
import chibson.usuarios.service.RegistroAccionService;
import chibson.usuarios.service.RolService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RolNotificacionRegistroServiceTest {
    private static final String ADMIN = "12345678-5";

    @Mock
    private RolRepository rolRepository;
    @Mock
    private PermisoRepository permisoRepository;
    @Mock
    private UsuarioRepository usuarioRepository;
    @Mock
    private RegistroAccionService registroAccionService;
    @Mock
    private NotificacionRepository notificacionRepository;
    @Mock
    private RegistroAccionRepository registroAccionRepository;

    private RolService rolService;
    private NotificacionService notificacionService;
    private RegistroAccionService registros;

    @BeforeEach
    void setUp() {
        rolService = new RolService(rolRepository, permisoRepository, usuarioRepository, registroAccionService);
        notificacionService = new NotificacionService(notificacionRepository, usuarioRepository);
        registros = new RegistroAccionService(registroAccionRepository);
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    private Usuario usuario(EstadoUsuario estado, String... permisos) {
        Set<Permiso> set = new HashSet<>();
        long id = 1;
        for (String p : permisos) {
            set.add(new Permiso(id++, p, p));
        }
        Usuario u = new Usuario();
        u.setRut(ADMIN);
        u.setEstado(estado);
        u.setRol(new Rol(1L, "ADMINISTRADOR", set));
        return u;
    }

    @Test
    void listRolesPermissions() {
        when(rolRepository.findAll()).thenReturn(List.of(new Rol()));
        when(permisoRepository.findAll()).thenReturn(List.of(new Permiso()));

        assertEquals(1, rolService.listarRoles().size());
        assertEquals(1, rolService.listarPermisos().size());
    }

    @Test
    void findRole() {
        Rol rol = new Rol(2L, "CLIENTE", new HashSet<>());
        when(rolRepository.findByNombreIgnoreCase("cliente")).thenReturn(Optional.of(rol));

        assertSame(rol, rolService.buscarRol(" cliente "));
    }

    @Test
    void findRoleNotFound() {
        when(rolRepository.findByNombreIgnoreCase("X")).thenReturn(Optional.empty());

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.buscarRol("X"))));
        assertThrows(ResponseStatusException.class, () -> rolService.buscarRol(" "));
    }

    @Test
    void updatePermissions() {
        Rol rol = new Rol(2L, "CLIENTE", new HashSet<>(Set.of(new Permiso(1L, "A", "a"))));
        Permiso b = new Permiso(2L, "B", "b");
        when(rolRepository.findById(2L)).thenReturn(Optional.of(rol));
        when(permisoRepository.findAllById(List.of(2L))).thenReturn(List.of(b));
        when(rolRepository.save(rol)).thenReturn(rol);

        Rol guardado = rolService.modificarPermisos(2L, List.of(2L), ADMIN);

        assertEquals(Set.of(b), guardado.getPermisos());
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.MODIFICAR), eq("Roles"), any(), anyList());
    }

    @Test
    void updatePermissionsNull() {
        Rol rol = new Rol(2L, "CLIENTE", new HashSet<>(Set.of(new Permiso(1L, "A", "a"))));
        when(rolRepository.findById(2L)).thenReturn(Optional.of(rol));
        when(permisoRepository.findAllById(List.of())).thenReturn(List.of());
        when(rolRepository.save(rol)).thenReturn(rol);

        assertTrue(rolService.modificarPermisos(2L, null, ADMIN).getPermisos().isEmpty());
    }

    @Test
    void updateRoleNotFound() {
        when(rolRepository.findById(9L)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.modificarPermisos(9L, List.of(1L), ADMIN))));
    }

    @Test
    void updateUnknownPermissions() {
        Rol rol = new Rol(2L, "CLIENTE", new HashSet<>());
        when(rolRepository.findById(2L)).thenReturn(Optional.of(rol));
        when(permisoRepository.findAllById(List.of(1L, 99L))).thenReturn(List.of(new Permiso(1L, "A", "a")));

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.modificarPermisos(2L, List.of(1L, 99L), ADMIN))));
    }

    @Test
    void hasPermission() {
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(usuario(EstadoUsuario.ACTIVO, "VER_HISTORIAL")));

        assertTrue(rolService.tienePermiso(" " + ADMIN + " ", "VER_HISTORIAL"));
        assertFalse(rolService.tienePermiso(ADMIN, "OTRO"));
    }

    @Test
    void hasPermissionFalse() {
        assertFalse(rolService.tienePermiso(null, "X"));
        assertFalse(rolService.tienePermiso(" ", "X"));
        when(usuarioRepository.findById("1-9")).thenReturn(Optional.empty());
        assertFalse(rolService.tienePermiso("1-9", "X"));
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(usuario(EstadoUsuario.DESACTIVADO, "X")));
        assertFalse(rolService.tienePermiso(ADMIN, "X"));
    }

    @Test
    void requirePermission() {
        Usuario u = usuario(EstadoUsuario.ACTIVO, "VER_HISTORIAL");
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(u));

        assertSame(u, rolService.exigirPermiso(ADMIN, "VER_HISTORIAL"));
    }

    @Test
    void requirePermissionDenied() {
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(usuario(EstadoUsuario.ACTIVO, "A")));

        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.exigirPermiso(ADMIN, "B"))));
    }

    @Test
    void requirePermissionNoSession() {
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.exigirPermiso(null, "B"))));
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(usuario(EstadoUsuario.DESACTIVADO, "B")));
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.exigirPermiso(ADMIN, "B"))));
    }

    @Test
    void requireSession() {
        Usuario u = usuario(EstadoUsuario.ACTIVO);
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(u));

        assertSame(u, rolService.exigirSesion(ADMIN));
        assertThrows(ResponseStatusException.class, () -> rolService.exigirSesion(" "));
    }

    @Test
    void requireSessionInvalid() {
        when(usuarioRepository.findById("1-9")).thenReturn(Optional.empty());
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> rolService.exigirSesion("1-9"))));
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(usuario(EstadoUsuario.DESACTIVADO)));
        assertThrows(ResponseStatusException.class, () -> rolService.exigirSesion(ADMIN));
    }

    @Test
    void sendNotification() {
        Usuario u = usuario(EstadoUsuario.ACTIVO);
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(u));
        when(notificacionRepository.save(any(Notificacion.class))).thenAnswer(i -> i.getArgument(0));

        Notificacion n = notificacionService.enviarNotificacion(new NotificacionDTO(ADMIN, " Hola ", " ped-1 "));

        assertEquals("Hola", n.getMensaje());
        assertEquals("ped-1", n.getReferencia());
        assertFalse(n.isLeida());
        assertSame(u, n.getUsuario());
    }

    @Test
    void notificationUserNotFound() {
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> notificacionService.enviarNotificacion(new NotificacionDTO(ADMIN, "Hola", null)))));
    }

    @Test
    void notificationNoMessage() {
        when(usuarioRepository.findById(ADMIN)).thenReturn(Optional.of(usuario(EstadoUsuario.ACTIVO)));

        assertThrows(ResponseStatusException.class,
                () -> notificacionService.enviarNotificacion(new NotificacionDTO(ADMIN, " ", null)));
    }

    @Test
    void listNotifications() {
        when(notificacionRepository.findByUsuarioRutOrderByFechaDesc(ADMIN)).thenReturn(List.of(new Notificacion()));

        assertEquals(1, notificacionService.listarPorUsuario(ADMIN).size());
    }

    @Test
    void markRead() {
        Notificacion n = new Notificacion();
        n.setUsuario(usuario(EstadoUsuario.ACTIVO));
        when(notificacionRepository.findById(1L)).thenReturn(Optional.of(n));
        when(notificacionRepository.save(n)).thenReturn(n);

        assertTrue(notificacionService.marcarLeida(1L, ADMIN).isLeida());
    }

    @Test
    void markReadOtherUser() {
        Notificacion n = new Notificacion();
        n.setUsuario(usuario(EstadoUsuario.ACTIVO));
        when(notificacionRepository.findById(1L)).thenReturn(Optional.of(n));

        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> notificacionService.marcarLeida(1L, "11111111-1"))));
    }

    @Test
    void markReadNotFound() {
        when(notificacionRepository.findById(5L)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> notificacionService.marcarLeida(5L, ADMIN))));
    }

    private RegistroAccion registro(TipoAccion tipo, String rut, String descripcion, LocalDateTime fecha) {
        RegistroAccion r = new RegistroAccion();
        r.setTipo(tipo);
        r.setRutAdministrador(rut);
        r.setModulo("Usuarios");
        r.setDescripcion(descripcion);
        r.setFecha(fecha);
        return r;
    }

    @Test
    void logActionSaves() {
        when(registroAccionRepository.save(any(RegistroAccion.class))).thenAnswer(i -> i.getArgument(0));
        RegistroAccionDTO dto = new RegistroAccionDTO(ADMIN, "crear", "Productos", "Creó algo",
                List.of(new DetalleCambioDTO("precio", "1", "2")));

        RegistroAccion r = registros.registrarAccion(dto);

        assertEquals(TipoAccion.CREAR, r.getTipo());
        assertEquals(1, r.getCambios().size());
        assertEquals("2", r.getCambios().get(0).getValorNuevo());
        assertTrue(r.getFecha() != null);
    }

    @Test
    void logActionNoChanges() {
        when(registroAccionRepository.save(any(RegistroAccion.class))).thenAnswer(i -> i.getArgument(0));

        RegistroAccion r = registros.registrar(ADMIN, TipoAccion.ELIMINAR, "X", "Y", null);

        assertTrue(r.getCambios().isEmpty());
    }

    @Test
    void logActionInvalidType() {
        RegistroAccionDTO dto = new RegistroAccionDTO(ADMIN, "VOLAR", "Productos", "algo", new ArrayList<>());

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> registros.registrarAccion(dto))));
    }

    @Test
    void logActionMissingFields() {
        assertThrows(ResponseStatusException.class,
                () -> registros.registrarAccion(new RegistroAccionDTO(null, "CREAR", "M", "D", null)));
        assertThrows(ResponseStatusException.class,
                () -> registros.registrarAccion(new RegistroAccionDTO(ADMIN, "CREAR", " ", "D", null)));
        assertThrows(ResponseStatusException.class,
                () -> registros.registrarAccion(new RegistroAccionDTO(ADMIN, "CREAR", "M", null, null)));
        assertThrows(ResponseStatusException.class,
                () -> registros.registrarAccion(new RegistroAccionDTO(ADMIN, null, "M", "D", null)));
    }

    @Test
    void listActionsFilters() {
        LocalDateTime enero = LocalDateTime.of(2026, 1, 15, 10, 0);
        LocalDateTime marzo = LocalDateTime.of(2026, 3, 15, 10, 0);
        when(registroAccionRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(
                registro(TipoAccion.CREAR, ADMIN, "Creó el usuario ana", marzo),
                registro(TipoAccion.ELIMINAR, "11111111-1", "Eliminó un producto", enero)));

        assertEquals(2, registros.listarAcciones(null, null, null, null, null).size());
        assertEquals(2, registros.listarAcciones(" ", null, " ", null, null).size());
        assertEquals(1, registros.listarAcciones(null, TipoAccion.CREAR, null, null, null).size());
        assertEquals(1, registros.listarAcciones(null, null, ADMIN.toLowerCase(), null, null).size());
        assertEquals(1, registros.listarAcciones(null, null, null, LocalDate.of(2026, 2, 1), null).size());
        assertEquals(1, registros.listarAcciones(null, null, null, null, LocalDate.of(2026, 2, 1)).size());
        assertEquals(1, registros.listarAcciones("ANA", null, null, null, null).size());
        assertEquals(1, registros.listarAcciones("11111111", null, null, null, null).size());
        assertEquals(0, registros.listarAcciones("zzz", null, null, null, null).size());
    }

    @Test
    void listByAdmin() {
        when(registroAccionRepository.findByRutAdministradorOrderByFechaDesc(ADMIN))
                .thenReturn(List.of(new RegistroAccion()));

        assertEquals(1, registros.listarPorAdministrador(ADMIN).size());
    }

    @Test
    void getDetail() {
        RegistroAccion r = new RegistroAccion();
        when(registroAccionRepository.findById(1L)).thenReturn(Optional.of(r));
        when(registroAccionRepository.findById(2L)).thenReturn(Optional.empty());

        assertSame(r, registros.obtenerDetalle(1L));
        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> registros.obtenerDetalle(2L))));
    }

    @Test
    void noteOnlyRealChanges() {
        List<DetalleCambioDTO> cambios = RegistroAccionService.sinCambios();

        RegistroAccionService.anotar(cambios, "a", "x", "x");
        RegistroAccionService.anotar(cambios, "b", null, "nuevo");
        RegistroAccionService.anotar(cambios, "c", 1, null);

        assertEquals(2, cambios.size());
        assertNull(cambios.get(0).getValorAnterior());
        assertEquals("1", cambios.get(1).getValorAnterior());
        assertNull(cambios.get(1).getValorNuevo());
    }
}
