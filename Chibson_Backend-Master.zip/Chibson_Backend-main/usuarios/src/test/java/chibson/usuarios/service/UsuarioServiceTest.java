package chibson.usuarios.service;

import chibson.usuarios.client.VentasClient;
import chibson.usuarios.dto.PerfilDTO;
import chibson.usuarios.dto.UsuarioAdminDTO;
import chibson.usuarios.model.EstadoUsuario;
import chibson.usuarios.model.Rol;
import chibson.usuarios.model.TipoAccion;
import chibson.usuarios.model.Usuario;
import chibson.usuarios.repository.NotificacionRepository;
import chibson.usuarios.repository.UsuarioRepository;
import chibson.usuarios.service.PasswordHasher;
import chibson.usuarios.service.RegistroAccionService;
import chibson.usuarios.service.RolService;
import chibson.usuarios.service.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {
    private static final String ADMIN = "12345678-5";
    private static final String CLIENTE = "11111111-1";

    @Mock
    private UsuarioRepository usuarioRepository;
    @Mock
    private NotificacionRepository notificacionRepository;
    @Mock
    private RolService rolService;
    @Mock
    private RegistroAccionService registroAccionService;
    @Mock
    private VentasClient ventasClient;
    @Mock
    private RestTemplate restTemplate;

    private UsuarioService service;
    private Rol rolCliente;
    private Rol rolAdmin;

    @BeforeEach
    void setUp() {
        service = new UsuarioService(usuarioRepository, notificacionRepository, rolService, registroAccionService, ventasClient);
        rolCliente = new Rol(2L, Rol.CLIENTE, new HashSet<>());
        rolAdmin = new Rol(1L, Rol.ADMINISTRADOR, new HashSet<>());
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    private Usuario usuario(String rut, Rol rol, EstadoUsuario estado) {
        Usuario u = new Usuario();
        u.setRut(rut);
        u.setNombres("Ana");
        u.setPrimerApellido("Pérez");
        u.setSegundoApellido("Soto");
        u.setUsername("ana");
        u.setCorreo("ana@correo.cl");
        u.setTelefono("12345678");
        u.setPassword("hash");
        u.setEstado(estado);
        u.setRol(rol);
        u.setFechaRegistro(LocalDate.of(2026, 1, 1));
        return u;
    }

    private UsuarioAdminDTO datosAdmin() {
        UsuarioAdminDTO d = new UsuarioAdminDTO();
        d.setRut("11.111.111-1");
        d.setNombres("Luis");
        d.setPrimerApellido("Rojas");
        d.setSegundoApellido("Mena");
        d.setUsername("luis");
        d.setCorreo(" Luis@Correo.cl ");
        d.setTelefono("99999999");
        d.setRol("CLIENTE");
        d.setPassword("Clave1234");
        return d;
    }

    private void existe(String rut, Usuario u) {
        when(usuarioRepository.findById(rut)).thenReturn(Optional.of(u));
    }

    @Test
    void listFilters() {
        Usuario a = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        Usuario b = usuario(ADMIN, rolAdmin, EstadoUsuario.DESACTIVADO);
        b.setNombres("Pedro");
        b.setUsername("pedro");
        b.setCorreo("pedro@correo.cl");
        when(usuarioRepository.findAllByOrderByFechaRegistroDesc()).thenReturn(List.of(a, b));

        assertEquals(2, service.listarUsuarios(null, null, null).size());
        assertEquals(2, service.listarUsuarios(" ", null, " ").size());
        assertEquals(1, service.listarUsuarios("cliente", null, null).size());
        assertEquals(1, service.listarUsuarios(null, EstadoUsuario.DESACTIVADO, null).size());
        assertEquals(1, service.listarUsuarios(null, null, "PEDRO").size());
        assertEquals(1, service.listarUsuarios(null, null, "pedro@correo").size());
        assertEquals(1, service.listarUsuarios(null, null, "11111111").size());
        assertEquals(2, service.listarUsuarios(null, null, "pérez soto").size());
        assertEquals(1, service.listarUsuarios(null, null, "ana").size());
        assertEquals(0, service.listarUsuarios(null, null, "zzz").size());
    }

    @Test
    void findByRut() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        existe(CLIENTE, u);

        assertEquals(u, service.findByRut("11.111.111-1"));
    }

    @Test
    void findByRutNotFound() {
        when(usuarioRepository.findById(CLIENTE)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> service.findByRut(CLIENTE))));
    }

    @Test
    void createHashesPassword() {
        when(usuarioRepository.existsById(CLIENTE)).thenReturn(false);
        when(usuarioRepository.existsByCorreoIgnoreCase("luis@correo.cl")).thenReturn(false);
        when(rolService.buscarRol("CLIENTE")).thenReturn(rolCliente);
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(i -> i.getArgument(0));

        Usuario u = service.crearUsuario(datosAdmin(), ADMIN);

        assertEquals(CLIENTE, u.getRut());
        assertEquals("luis@correo.cl", u.getCorreo());
        assertEquals(EstadoUsuario.ACTIVO, u.getEstado());
        assertNotEquals("Clave1234", u.getPassword());
        assertTrue(PasswordHasher.coincide("Clave1234", u.getPassword()));
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.CREAR), anyString(), anyString(), anyList());
    }

    @Test
    void createDuplicateRut() {
        when(usuarioRepository.existsById(CLIENTE)).thenReturn(true);

        assertEquals(HttpStatus.CONFLICT, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearUsuario(datosAdmin(), ADMIN))));
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void createDuplicateEmail() {
        when(usuarioRepository.existsById(CLIENTE)).thenReturn(false);
        when(usuarioRepository.existsByCorreoIgnoreCase("luis@correo.cl")).thenReturn(true);

        assertEquals(HttpStatus.CONFLICT, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearUsuario(datosAdmin(), ADMIN))));
    }

    @Test
    void createWeakPassword() {
        when(usuarioRepository.existsById(CLIENTE)).thenReturn(false);
        when(usuarioRepository.existsByCorreoIgnoreCase("luis@correo.cl")).thenReturn(false);
        UsuarioAdminDTO d = datosAdmin();
        d.setPassword("abc");

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.crearUsuario(d, ADMIN))));
    }

    @Test
    void update() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        existe(CLIENTE, u);
        when(usuarioRepository.existsByCorreoIgnoreCase("luis@correo.cl")).thenReturn(false);
        when(rolService.buscarRol("CLIENTE")).thenReturn(rolCliente);
        when(usuarioRepository.save(u)).thenReturn(u);

        Usuario editado = service.editarUsuario(CLIENTE, datosAdmin(), ADMIN);

        assertEquals("Luis", editado.getNombres());
        assertEquals("luis@correo.cl", editado.getCorreo());
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.MODIFICAR), anyString(), anyString(), anyList());
    }

    @Test
    void updateSameEmail() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        u.setCorreo("luis@correo.cl");
        existe(CLIENTE, u);
        when(rolService.buscarRol("CLIENTE")).thenReturn(rolCliente);
        when(usuarioRepository.save(u)).thenReturn(u);

        service.editarUsuario(CLIENTE, datosAdmin(), ADMIN);

        verify(usuarioRepository, never()).existsByCorreoIgnoreCase(anyString());
    }

    @Test
    void updateDuplicateEmail() {
        existe(CLIENTE, usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO));
        when(usuarioRepository.existsByCorreoIgnoreCase("luis@correo.cl")).thenReturn(true);

        assertEquals(HttpStatus.CONFLICT, estado(assertThrows(ResponseStatusException.class,
                () -> service.editarUsuario(CLIENTE, datosAdmin(), ADMIN))));
    }

    @Test
    void assignRole() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        existe(CLIENTE, u);
        when(rolService.buscarRol("ADMINISTRADOR")).thenReturn(rolAdmin);
        when(usuarioRepository.save(u)).thenReturn(u);

        assertEquals(Rol.ADMINISTRADOR, service.asignarRol(CLIENTE, "ADMINISTRADOR", ADMIN).getRol().getNombre());
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.MODIFICAR), eq("Roles"), anyString(), anyList());
    }

    @Test
    void deactivate() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        existe(CLIENTE, u);
        when(usuarioRepository.save(u)).thenReturn(u);

        assertEquals(EstadoUsuario.DESACTIVADO, service.desactivarUsuario(CLIENTE, ADMIN).getEstado());
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.DESACTIVAR), anyString(), anyString(), anyList());
    }

    @Test
    void deactivateTwice() {
        existe(CLIENTE, usuario(CLIENTE, rolCliente, EstadoUsuario.DESACTIVADO));

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.desactivarUsuario(CLIENTE, ADMIN))));
    }

    @Test
    void reactivate() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.DESACTIVADO);
        existe(CLIENTE, u);
        when(usuarioRepository.save(u)).thenReturn(u);

        assertEquals(EstadoUsuario.ACTIVO, service.reactivarUsuario(CLIENTE, ADMIN).getEstado());
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.ACTIVAR), anyString(), anyString(), anyList());
    }

    @Test
    void reactivateActive() {
        existe(CLIENTE, usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO));

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.reactivarUsuario(CLIENTE, ADMIN))));
    }

    @Test
    void deleteNoOrders() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        existe(CLIENTE, u);
        when(ventasClient.clienteTienePedidos(CLIENTE)).thenReturn(false);

        service.eliminarUsuario(CLIENTE, ADMIN);

        verify(notificacionRepository).deleteByUsuarioRut(CLIENTE);
        verify(usuarioRepository).delete(u);
        verify(registroAccionService).registrar(eq(ADMIN), eq(TipoAccion.ELIMINAR), anyString(), anyString(), anyList());
    }

    @Test
    void deleteWithOrders() {
        existe(CLIENTE, usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO));
        when(ventasClient.clienteTienePedidos(CLIENTE)).thenReturn(true);

        assertEquals(HttpStatus.CONFLICT, estado(assertThrows(ResponseStatusException.class,
                () -> service.eliminarUsuario(CLIENTE, ADMIN))));
        verify(usuarioRepository, never()).delete(any());
    }

    private PerfilDTO perfil() {
        PerfilDTO p = new PerfilDTO();
        p.setNombres("Ana María");
        p.setPrimerApellido("Pérez");
        p.setSegundoApellido("Soto");
        p.setUsername("anita");
        p.setTelefono(" ");
        p.setRegion("Valparaíso");
        p.setCiudadComuna("Viña del Mar");
        p.setCondominio(null);
        p.setNumero("123");
        return p;
    }

    @Test
    void updateProfile() {
        Usuario u = usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO);
        existe(CLIENTE, u);
        when(usuarioRepository.save(u)).thenReturn(u);

        Usuario r = service.actualizarPerfil(CLIENTE, perfil());

        assertEquals("anita", r.getUsername());
        assertEquals("Viña del Mar", r.getCiudadComuna());
        assertNull(r.getTelefono());
        assertNull(r.getCondominio());
    }

    @Test
    void profileNoRegion() {
        existe(CLIENTE, usuario(CLIENTE, rolCliente, EstadoUsuario.ACTIVO));
        PerfilDTO p = perfil();
        p.setRegion(" ");

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.actualizarPerfil(CLIENTE, p))));
    }

    @Test
    void countClients() {
        when(usuarioRepository.countByFechaRegistroBetweenAndRolNombre(LocalDate.of(2026, 1, 1),
                LocalDate.of(2026, 1, 31), Rol.CLIENTE)).thenReturn(5L);

        assertEquals(5L, service.contarClientesRegistrados(LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31)));
    }

    @Test
    void countToday() {
        LocalDate hoy = LocalDate.now();
        when(usuarioRepository.countByFechaRegistroBetweenAndRolNombre(hoy, hoy, Rol.CLIENTE)).thenReturn(2L);

        assertEquals(2L, service.contarClientesRegistrados(null, null));
    }

    @Test
    void countInvalidRange() {
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.contarClientesRegistrados(LocalDate.of(2026, 2, 1), LocalDate.of(2026, 1, 1)))));
    }

    @Test
    void salesClientHasOrders() {
        VentasClient cliente = new VentasClient(restTemplate, "http://localhost:8083");
        when(restTemplate.getForObject("http://localhost:8083/api/pedidos/cliente/" + CLIENTE + "/existe", Boolean.class))
                .thenReturn(true);

        assertTrue(cliente.clienteTienePedidos(CLIENTE));
    }

    @Test
    void salesClientNull() {
        VentasClient cliente = new VentasClient(restTemplate, "http://localhost:8083");
        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenReturn(null);

        assertFalse(cliente.clienteTienePedidos(CLIENTE));
    }

    @Test
    void salesClientDown503() {
        VentasClient cliente = new VentasClient(restTemplate, "http://localhost:8083");
        when(restTemplate.getForObject(anyString(), eq(Boolean.class))).thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> cliente.clienteTienePedidos(CLIENTE))));
    }
}
