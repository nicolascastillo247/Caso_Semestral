package chibson.usuarios;

import chibson.usuarios.config.DatosIniciales;
import chibson.usuarios.repository.NotificacionRepository;
import chibson.usuarios.repository.RegistroAccionRepository;
import chibson.usuarios.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LimpiezaBaseDatos {
    @Autowired
    private NotificacionRepository notificacionRepository;

    @Autowired
    private RegistroAccionRepository registroAccionRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public void limpiar() {
        notificacionRepository.deleteAll();
        registroAccionRepository.deleteAll();
        usuarioRepository.findAll().stream()
                .filter(u -> !DatosIniciales.RUT_ADMIN.equals(u.getRut()))
                .forEach(usuarioRepository::delete);
    }
}
