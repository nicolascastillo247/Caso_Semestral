# ms-usuarios

Registro, inicio de sesión, perfil, administración de usuarios, roles y permisos, notificaciones e historial de acciones de los administradores.

- **Puerto:** 8081
- **Base de datos:** `chibson_usuarios` en MySQL (se crea sola al arrancar)
- **Swagger:** http://localhost:8081/swagger-ui.html
- **Llama a:** ms-ventas (saber si un cliente tiene pedidos antes de eliminarlo).
- **Lo usan:** Todos los demás servicios: verifican permisos (`/api/roles/verificar`), piden datos de usuarios (`/api/usuarios/{rut}/datos`), registran acciones (`/api/acciones`) y envían notificaciones (`/api/notificaciones`). ms-informes cuenta los clientes registrados.

## Ejecutar

```
.\mvnw spring-boot:run
```

O todo el backend junto con `iniciar-todo.ps1` desde la carpeta raíz.

## Pruebas

```
.\mvnw clean test
```

El informe de cobertura queda en `target/site/jacoco/index.html`.

Las pruebas no usan MySQL: los `*ControllerIT` levantan la aplicación completa con H2 en memoria (perfil `test`) y limpian las tablas antes de cada prueba con `LimpiezaBaseDatos`. Los servicios externos se reemplazan con `@MockitoBean`.

| Tipo | Clases | Qué prueba |
|---|---|---|
| Servicio | `service/*Test` | Reglas de negocio con Mockito, sin Spring. |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest`: rutas, códigos HTTP, JSON y enlaces HATEOAS con el servicio simulado. |
| Integración | `controller/*ControllerIT` | `@SpringBootTest` + MockMvc + H2: flujo completo hasta la base de datos. |

## Endpoints

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/auth/registro` | Registra un cliente nuevo | No |
| POST | `/api/auth/login` | Inicia sesión con correo y contraseña; entrega el token | No |
| POST | `/api/auth/recuperar` | Recupera la contraseña con el RUT y el correo | No |
| PUT | `/api/auth/password` | Cambia la contraseña del usuario con sesión | Sí |
| POST | `/api/notificaciones` | Crea un aviso para un usuario (uso interno de otros microservicios) | No |
| GET | `/api/notificaciones` | Avisos del usuario con sesión, del más nuevo al más antiguo | Sí |
| PATCH | `/api/notificaciones/{id}/leida` | Marca un aviso como leído | Sí |
| POST | `/api/acciones` | Registra una acción (uso interno de otros microservicios) | No |
| GET | `/api/acciones` | Lista el historial con filtros por texto, tipo, administrador y fechas | Sí |
| GET | `/api/acciones/{id}` | Detalle de una acción con sus cambios | Sí |
| GET | `/api/acciones/administrador/{rut}` | Acciones de un administrador | Sí |
| GET | `/api/roles` | Lista los roles con sus permisos | Sí |
| GET | `/api/roles/permisos` | Lista todos los permisos disponibles | Sí |
| PUT | `/api/roles/{idRol}/permisos` | Reemplaza los permisos de un rol | Sí |
| GET | `/api/roles/verificar` | Indica si un usuario tiene un permiso (uso interno de otros microservicios) | No |
| GET | `/api/usuarios/perfil` | Datos de Mi perfil | Sí |
| PUT | `/api/usuarios/perfil` | Actualiza los datos de Mi perfil | Sí |
| GET | `/api/usuarios/{rut}/datos` | Datos públicos de un usuario (uso interno de ventas y soporte) | No |
| GET | `/api/usuarios/registrados/contar` | Cuenta los clientes registrados entre dos fechas (uso interno de ms-informes) | No |
| GET | `/api/usuarios` | Lista los usuarios con filtros por rol, estado y texto | Sí |
| GET | `/api/usuarios/{rut}` | Busca un usuario por RUT | Sí |
| POST | `/api/usuarios` | Crea un usuario desde el panel | Sí |
| PUT | `/api/usuarios/{rut}` | Edita un usuario | Sí |
| PATCH | `/api/usuarios/{rut}/rol` | Asigna un rol a un usuario | Sí |
| PATCH | `/api/usuarios/{rut}/desactivar` | Desactiva un usuario | Sí |
| PATCH | `/api/usuarios/{rut}/reactivar` | Reactiva un usuario | Sí |
| DELETE | `/api/usuarios/{rut}` | Elimina un usuario sin pedidos | Sí |

Las respuestas de un recurso traen `_links` (HATEOAS). Las listas vienen dentro de `_embedded`. Los endpoints de uso interno (contar, existe, verificar, datos, stock, resumen) responden JSON simple porque los consumen otros microservicios.

Colección de Postman: `chibson-usuarios.postman_collection.json` (en esta carpeta).
