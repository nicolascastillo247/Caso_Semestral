param(
    [int]$SegundosEspera = 180
)

$raiz = $PSScriptRoot

function Test-Puerto([int]$puerto) {
    [bool](Get-NetTCPConnection -LocalPort $puerto -State Listen -ErrorAction SilentlyContinue)
}

if (-not $env:JAVA_HOME -and -not (Get-Command java -ErrorAction SilentlyContinue)) {
    Write-Host 'No se encontro Java. Instala el JDK 25 y define JAVA_HOME.' -ForegroundColor Red
    exit 1
}

if (-not (Test-Puerto 3306)) {
    Write-Host 'MySQL no esta encendido en el puerto 3306. Inicialo desde el panel de XAMPP.' -ForegroundColor Red
    exit 1
}

$servicios = @(
    @{ Nombre = 'usuarios';  Puerto = 8081 },
    @{ Nombre = 'productos'; Puerto = 8082 },
    @{ Nombre = 'ventas';    Puerto = 8083 },
    @{ Nombre = 'soporte';   Puerto = 8084 },
    @{ Nombre = 'contenido'; Puerto = 8085 },
    @{ Nombre = 'informes';  Puerto = 8086 },
    @{ Nombre = 'gateway';   Puerto = 8080 }
)

$yaCorriendo = 0
foreach ($s in $servicios) {
    if (Test-Puerto $s.Puerto) {
        Write-Host ("{0,-10} ya esta corriendo en el puerto {1}" -f $s.Nombre, $s.Puerto) -ForegroundColor DarkGray
        $yaCorriendo++
        continue
    }

    $comando = "`$Host.UI.RawUI.WindowTitle = 'ms-$($s.Nombre) :$($s.Puerto)'; .\mvnw.cmd spring-boot:run"

    Write-Host ("{0,-10} iniciando en el puerto {1}..." -f $s.Nombre, $s.Puerto) -NoNewline
    Start-Process powershell -WorkingDirectory (Join-Path $raiz $s.Nombre) `
        -ArgumentList '-NoExit', '-ExecutionPolicy', 'Bypass', '-Command', $comando

    $limite = (Get-Date).AddSeconds($SegundosEspera)
    while (-not (Test-Puerto $s.Puerto) -and (Get-Date) -lt $limite) {
        Start-Sleep -Seconds 2
    }

    if (Test-Puerto $s.Puerto) {
        Write-Host ' listo' -ForegroundColor Green
    } else {
        Write-Host " no respondio en $SegundosEspera s. Revisa su ventana." -ForegroundColor Red
    }
}

if ($yaCorriendo -eq $servicios.Count) {
    Write-Host ''
    Write-Host 'Los servicios ya estaban encendidos. Para reiniciarlos, ejecuta primero detener-todo.' -ForegroundColor Yellow
}

Write-Host ''
Write-Host 'Gateway:  http://localhost:8080' -ForegroundColor Cyan
Write-Host 'Swagger:  http://localhost:8081/swagger-ui.html (8081 a 8086, uno por microservicio)' -ForegroundColor Cyan
