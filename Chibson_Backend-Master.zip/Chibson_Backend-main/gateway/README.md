# gateway

Punto de entrada único del backend (Spring Cloud Gateway, WebFlux).

- **Puerto:** 8080
- **Rutas:** `/api/auth`, `/api/usuarios`, `/api/roles`, `/api/notificaciones`, `/api/acciones` → 8081 · `/api/productos`, `/api/resenas` → 8082 · `/api/pedidos`, `/api/devoluciones`, `/api/ventas` → 8083 · `/api/tickets` → 8084 · `/api/noticias`, `/api/institucional` → 8085 · `/api/reportes` → 8086
- **CORS:** permite el frontend abierto con Live Server (`http://localhost:5500` y `http://127.0.0.1:5500`).

## Seguridad

`AutenticacionFilter` convierte el token de sesión en el encabezado `X-Rut-Usuario` que esperan los microservicios:

- Borra cualquier `X-Rut-Usuario` que mande el cliente, para que no se pueda falsificar.
- Si viene `Authorization: Bearer <token>` válido, agrega el RUT del token.
- Si el token es inválido o expiró, responde 401.
- Sin token la petición sigue sin RUT: las rutas públicas funcionan y las privadas las rechaza el microservicio.

El token lo entrega `POST /api/auth/login` y `TokenValidador` lo comprueba con el mismo secreto que ms-usuarios (`seguridad.token.secreto`).

## Ejecutar y probar

```
.\mvnw spring-boot:run
.\mvnw clean test
```

Se levanta al final, después de los microservicios. Colección de Postman: `chibson-gateway.postman_collection.json`.
