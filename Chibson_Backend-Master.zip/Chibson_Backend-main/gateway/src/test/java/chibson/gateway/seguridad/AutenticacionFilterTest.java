package chibson.gateway.seguridad;

import chibson.gateway.seguridad.AutenticacionFilter;
import chibson.gateway.seguridad.TokenValidador;
import org.junit.jupiter.api.Test;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class AutenticacionFilterTest {
    private static final String SECRETO = "secreto-de-prueba";

    private final AutenticacionFilter filtro = new AutenticacionFilter(new TokenValidador(SECRETO));
    private final AtomicReference<ServerWebExchange> recibido = new AtomicReference<>();
    private final GatewayFilterChain cadena = exchange -> {
        recibido.set(exchange);
        return Mono.empty();
    };

    private MockServerWebExchange peticion(String authorization, String rutFalsificado) {
        MockServerHttpRequest.BaseBuilder<?> req = MockServerHttpRequest.get("/api/tickets/mis-tickets");
        if (authorization != null) {
            req.header("Authorization", authorization);
        }
        if (rutFalsificado != null) {
            req.header("X-Rut-Usuario", rutFalsificado);
        }
        return MockServerWebExchange.from(req);
    }

    @Test
    void validToken() throws Exception {
        String token = TokenValidadorTest.token("12345678-5", Instant.now().getEpochSecond() + 600, SECRETO);

        filtro.filter(peticion("Bearer " + token, null), cadena).block();

        assertNotNull(recibido.get());
        assertEquals("12345678-5", recibido.get().getRequest().getHeaders().getFirst("X-Rut-Usuario"));
    }

    @Test
    void replacesForgedRut() throws Exception {
        String token = TokenValidadorTest.token("11111111-1", Instant.now().getEpochSecond() + 600, SECRETO);

        filtro.filter(peticion("Bearer " + token, "12345678-5"), cadena).block();

        assertEquals("11111111-1", recibido.get().getRequest().getHeaders().getFirst("X-Rut-Usuario"));
    }

    @Test
    void noTokenRemovesRut() {
        filtro.filter(peticion(null, "12345678-5"), cadena).block();

        assertNotNull(recibido.get());
        assertNull(recibido.get().getRequest().getHeaders().getFirst("X-Rut-Usuario"));
    }

    @Test
    void invalidToken401() {
        MockServerWebExchange exchange = peticion("Bearer token.invalido.firma", "12345678-5");

        filtro.filter(exchange, cadena).block();

        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
        assertNull(recibido.get());
    }

    @Test
    void expiredToken401() throws Exception {
        String token = TokenValidadorTest.token("12345678-5", Instant.now().getEpochSecond() - 5, SECRETO);
        MockServerWebExchange exchange = peticion("Bearer " + token, null);

        filtro.filter(exchange, cadena).block();

        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
        assertNull(recibido.get());
    }
}
