package chibson.gateway.seguridad;

import chibson.gateway.seguridad.TokenValidador;
import org.junit.jupiter.api.Test;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TokenValidadorTest {
    private static final String SECRETO = "secreto-de-prueba";

    static String token(String rut, long expira, String secreto) throws Exception {
        String cuerpo = Base64.getUrlEncoder().withoutPadding().encodeToString(rut.getBytes(StandardCharsets.UTF_8))
                + "." + expira;
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secreto.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        String firma = Base64.getUrlEncoder().withoutPadding()
                .encodeToString(mac.doFinal(cuerpo.getBytes(StandardCharsets.UTF_8)));
        return cuerpo + "." + firma;
    }

    private final TokenValidador validador = new TokenValidador(SECRETO);

    @Test
    void validToken() throws Exception {
        String token = token("12345678-5", Instant.now().getEpochSecond() + 600, SECRETO);

        assertEquals("12345678-5", validador.rutDe(token).orElseThrow());
    }

    @Test
    void expiredToken() throws Exception {
        String token = token("12345678-5", Instant.now().getEpochSecond() - 10, SECRETO);

        assertTrue(validador.rutDe(token).isEmpty());
    }

    @Test
    void wrongSecret() throws Exception {
        String token = token("12345678-5", Instant.now().getEpochSecond() + 600, "otro-secreto");

        assertTrue(validador.rutDe(token).isEmpty());
    }

    @Test
    void tamperedRut() throws Exception {
        String original = token("11111111-1", Instant.now().getEpochSecond() + 600, SECRETO);
        String[] partes = original.split("\\.");
        String rutFalso = Base64.getUrlEncoder().withoutPadding()
                .encodeToString("12345678-5".getBytes(StandardCharsets.UTF_8));

        assertTrue(validador.rutDe(rutFalso + "." + partes[1] + "." + partes[2]).isEmpty());
    }

    @Test
    void malformedTokens() {
        assertTrue(validador.rutDe(null).isEmpty());
        assertTrue(validador.rutDe("").isEmpty());
        assertTrue(validador.rutDe("abc").isEmpty());
        assertTrue(validador.rutDe("a.b.c").isEmpty());
        assertTrue(validador.rutDe("a.b.c.d").isEmpty());
    }
}
