package chibson.gateway.seguridad;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Component
public class AutenticacionFilter implements GlobalFilter, Ordered {
    public static final String HEADER_RUT = "X-Rut-Usuario";
    private static final String PREFIJO = "Bearer ";

    private final TokenValidador tokenValidador;

    public AutenticacionFilter(TokenValidador tokenValidador) {
        this.tokenValidador = tokenValidador;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String autorizacion = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (autorizacion == null || !autorizacion.startsWith(PREFIJO)) {
            ServerHttpRequest sinRut = exchange.getRequest().mutate().headers(h -> h.remove(HEADER_RUT)).build();
            return chain.filter(exchange.mutate().request(sinRut).build());
        }

        Optional<String> rut = tokenValidador.rutDe(autorizacion.substring(PREFIJO.length()).trim());
        if (rut.isEmpty()) {
            return rechazar(exchange);
        }
        ServerHttpRequest conRut = exchange.getRequest().mutate()
                .headers(h -> h.set(HEADER_RUT, rut.get())).build();
        return chain.filter(exchange.mutate().request(conRut).build());
    }

    private Mono<Void> rechazar(ServerWebExchange exchange) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);
        byte[] cuerpo = "{\"mensaje\":\"Sesión inválida o expirada, vuelva a iniciar sesión\"}"
                .getBytes(StandardCharsets.UTF_8);
        DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(cuerpo);
        return exchange.getResponse().writeWith(Mono.just(buffer));
    }

    @Override
    public int getOrder() {
        return -1;
    }
}
