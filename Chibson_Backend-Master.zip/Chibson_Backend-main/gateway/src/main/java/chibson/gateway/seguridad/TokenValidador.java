package chibson.gateway.seguridad;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;
import java.util.Optional;

@Component
public class TokenValidador {
    private final String secreto;

    public TokenValidador(@Value("${seguridad.token.secreto}") String secreto) {
        this.secreto = secreto;
    }

    public Optional<String> rutDe(String token) {
        if (token == null) {
            return Optional.empty();
        }
        String[] partes = token.split("\\.");
        if (partes.length != 3) {
            return Optional.empty();
        }
        try {
            String cuerpo = partes[0] + "." + partes[1];
            if (!MessageDigest.isEqual(firmar(cuerpo).getBytes(StandardCharsets.UTF_8),
                    partes[2].getBytes(StandardCharsets.UTF_8))) {
                return Optional.empty();
            }
            if (Long.parseLong(partes[1]) < Instant.now().getEpochSecond()) {
                return Optional.empty();
            }
            return Optional.of(new String(Base64.getUrlDecoder().decode(partes[0]), StandardCharsets.UTF_8));
        } catch (IllegalArgumentException | GeneralSecurityException e) {
            return Optional.empty();
        }
    }

    private String firmar(String cuerpo) throws GeneralSecurityException {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secreto.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(cuerpo.getBytes(StandardCharsets.UTF_8)));
    }
}
