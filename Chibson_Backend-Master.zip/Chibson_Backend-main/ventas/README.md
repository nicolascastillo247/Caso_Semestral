# ms-ventas

Compra (checkout) con pago simulado, pedidos y sus estados, devoluciones con reembolso y listado de ventas.

- **Puerto:** 8083
- **Base de datos:** `chibson_ventas` en MySQL (se crea sola al arrancar)
- **Swagger:** http://localhost:8083/swagger-ui.html
- **Llama a:** ms-productos (precio, descontar y reponer stock) y ms-usuarios (permisos, datos del cliente, notificaciones e historial).
- **Lo usan:** ms-usuarios y ms-productos (consultas de pedidos) y ms-informes (resumen de pedidos y devoluciones pendientes).

## Ejecutar

```
.\mvnw spring-boot:run
```

O todo el backend junto con `iniciar-todo.ps1` desde la carpeta raíz.

## Pruebas

```
.\mvnw clean test
```

El informe de cobertura queda en `target/site/jacoco/index.html`.

Las pruebas no usan MySQL: los `*ControllerIT` levantan la aplicación completa con H2 en memoria (perfil `test`) y limpian las tablas antes de cada prueba con `LimpiezaBaseDatos`. Los servicios externos se reemplazan con `@MockitoBean`.

| Tipo | Clases | Qué prueba |
|---|---|---|
| Servicio | `service/*Test` | Reglas de negocio con Mockito, sin Spring. |
| Controlador | `controller/*ControllerTest` | `@WebMvcTest`: rutas, códigos HTTP, JSON y enlaces HATEOAS con el servicio simulado. |
| Integración | `controller/*ControllerIT` | `@SpringBootTest` + MockMvc + H2: flujo completo hasta la base de datos. |

## Endpoints

| Método | Ruta | Qué hace | Sesión |
|---|---|---|---|
| POST | `/api/devoluciones` | El cliente solicita una devolución | Sí |
| GET | `/api/devoluciones/mis-devoluciones` | Devoluciones del cliente que hace la petición | Sí |
| GET | `/api/devoluciones` | Lista las devoluciones, opcionalmente por estado (administración) | Sí |
| GET | `/api/devoluciones/pendientes/contar` | Cuenta las devoluciones pendientes (uso interno de ms-informes) | No |
| GET | `/api/devoluciones/{numero}` | Detalle de una devolución | Sí |
| PATCH | `/api/devoluciones/{numero}/aprobar` | Aprueba una devolución y repone el stock | Sí |
| PATCH | `/api/devoluciones/{numero}/rechazar` | Rechaza una devolución con un motivo | Sí |
| PATCH | `/api/devoluciones/{numero}/reembolsar` | Marca como reembolsada una devolución aprobada | Sí |
| POST | `/api/pedidos/checkout` | Compra el carrito: 201 si el pago se aprueba, 402 si se rechaza | Sí |
| POST | `/api/pedidos/{numero}/pagar` | Reintenta el pago de un pedido pendiente | Sí |
| GET | `/api/pedidos/mis-pedidos` | Pedidos del cliente que hace la petición | Sí |
| GET | `/api/pedidos/mis-pedidos/{numero}` | Detalle de un pedido del cliente | Sí |
| GET | `/api/pedidos` | Lista los pedidos, opcionalmente por estado (administración) | Sí |
| GET | `/api/pedidos/{numero}` | Detalle de un pedido (administración) | Sí |
| PATCH | `/api/pedidos/{numero}/estado` | Cambia el estado de un pedido | Sí |
| PATCH | `/api/pedidos/{numero}/cancelar` | Cancela un pedido con un motivo y repone el stock | Sí |
| DELETE | `/api/pedidos/{numero}` | Elimina un pedido | Sí |
| GET | `/api/pedidos/cliente/{rut}/existe` | Indica si un cliente tiene pedidos (uso interno de ms-usuarios) | No |
| GET | `/api/pedidos/producto/{sku}/existe` | Indica si un producto tiene pedidos (uso interno de ms-productos) | No |
| GET | `/api/pedidos/cliente/{rut}/recibio/{sku}` | Indica si un cliente recibió un producto (uso interno de ms-productos) | No |
| GET | `/api/pedidos/resumen` | Resumen de pedidos entre fechas (uso interno de ms-informes) | No |
| GET | `/api/ventas` | Lista las ventas con filtros por texto, método de pago y fechas | Sí |
| GET | `/api/ventas/{numero}` | Detalle de una venta | Sí |

Las respuestas de un recurso traen `_links` (HATEOAS). Las listas vienen dentro de `_embedded`. Los endpoints de uso interno (contar, existe, verificar, datos, stock, resumen) responden JSON simple porque los consumen otros microservicios.

Colección de Postman: `chibson-ventas.postman_collection.json` (en esta carpeta).
