package chibson.ventas.model;

import org.springframework.hateoas.server.core.Relation;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "solicitud_devolucion")
@Getter
@Setter
@NoArgsConstructor
@Relation(itemRelation = "devolucion", collectionRelation = "devoluciones")
public class SolicitudDevolucion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long numeroSeguimiento;

    @Column(nullable = false, length = 12)
    private String rutCliente;

    @OneToMany(mappedBy = "solicitud", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemDevolucion> items = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private MotivoDevolucion motivo;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    private String evidenciaUrl;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoDevolucion estado;

    private String motivoRechazo;

    @Column(length = 12)
    private String rutAdministrador;

    @Column(nullable = false)
    private LocalDateTime fechaSolicitud;

    private LocalDateTime fechaResolucion;

    private Integer montoReembolsado;

    private LocalDateTime fechaReembolso;

    @Column(length = 12)
    private String rutAdministradorReembolso;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "numero_pedido", nullable = false)
    private Pedido pedido;

    public Long getNumeroPedido() {
        return pedido == null ? null : pedido.getNumeroPedido();
    }

    public int calcularMontoReembolso() {
        return items.stream().mapToInt(ItemDevolucion::subtotal).sum();
    }

    public void reembolsar(String rutAdmin) {
        this.montoReembolsado = calcularMontoReembolso();
        this.fechaReembolso = LocalDateTime.now();
        this.rutAdministradorReembolso = rutAdmin;
        this.estado = EstadoDevolucion.REEMBOLSADA;
    }
}
