package chibson.ventas.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI apiInfo() {
        return new OpenAPI().info(new Info()
                .title("Chibson Instruments - ms-ventas")
                .description("Pedidos, pagos, devoluciones y ventas. Los endpoints protegidos piden el encabezado X-Rut-Usuario.")
                .version("1.0"));
    }
}
