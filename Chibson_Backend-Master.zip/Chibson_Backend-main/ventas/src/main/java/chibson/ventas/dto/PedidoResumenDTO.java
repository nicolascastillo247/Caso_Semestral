package chibson.ventas.dto;

import java.time.LocalDateTime;
import java.util.List;

import chibson.ventas.model.ItemPedido;
import chibson.ventas.model.EstadoPedido;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PedidoResumenDTO {
    private Long numeroPedido;
    private LocalDateTime fecha;
    private EstadoPedido estado;
    private Integer total;

    private String region;

    private boolean pagado;
    private List<ItemPedido> items;
    private List<ReembolsoDTO> reembolsos;
}
