package chibson.ventas.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import chibson.ventas.dto.VentaDTO;
import chibson.ventas.model.MetodoPago;
import chibson.ventas.service.VentaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/ventas")
@Tag(name = "Ventas", description = "Listado y detalle de ventas")
public class VentaController {
    private static final String RUT = "X-Rut-Usuario";

    private final VentaService ventaService;

    public VentaController(VentaService ventaService) {
        this.ventaService = ventaService;
    }

    @GetMapping
    @Operation(summary = "Lista las ventas con filtros por texto, método de pago y fechas")
    public CollectionModel<EntityModel<VentaDTO>> listar(
            @RequestHeader(value = RUT, required = false) String rut,
            @RequestParam(required = false) String texto,
            @RequestParam(required = false) MetodoPago metodo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return CollectionModel.of(ventaService.listar(rut, texto, metodo, desde, hasta).stream()
                        .map(this::modelo).toList(),
                linkTo(VentaController.class).withSelfRel());
    }

    @GetMapping("/{numero}")
    @Operation(summary = "Detalle de una venta")
    public EntityModel<VentaDTO> detalle(@RequestHeader(value = RUT, required = false) String rut,
                                         @PathVariable Long numero) {
        return modelo(ventaService.detalle(numero, rut));
    }

    private EntityModel<VentaDTO> modelo(VentaDTO venta) {
        return EntityModel.of(venta,
                linkTo(VentaController.class).slash(venta.getNumeroVenta()).withSelfRel(),
                linkTo(VentaController.class).withRel("ventas"));
    }
}
