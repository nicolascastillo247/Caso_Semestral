package chibson.ventas.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pedido")
@Getter
@Setter
@NoArgsConstructor
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long numeroPedido;

    @Column(nullable = false, length = 12)
    private String rutCliente;

    @Column(nullable = false)
    private LocalDateTime fecha;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoPedido estado;

    @Column(nullable = false)
    private Integer subtotal;

    @Column(nullable = false)
    private Integer costoEnvio;

    @Column(nullable = false)
    private Integer iva;

    @Column(nullable = false)
    private Integer total;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MetodoPago metodoPago;

    private String motivoCancelacion;

    private String regionEnvio;
    private String ciudadComunaEnvio;
    private String condominioEnvio;
    private String numeroEnvio;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<ItemPedido> items = new ArrayList<>();

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("fecha ASC")
    private List<HistorialEstadoPedido> historial = new ArrayList<>();

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("fecha ASC")
    private List<Pago> pagos = new ArrayList<>();

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SolicitudDevolucion> devoluciones = new ArrayList<>();

    public boolean usaDireccionAlternativa() {
        return regionEnvio != null;
    }

    public boolean puedeCambiarA(EstadoPedido nuevo) {
        return (estado == EstadoPedido.PAGADO && nuevo == EstadoPedido.EN_PROCESO)
                || (estado == EstadoPedido.EN_PROCESO && nuevo == EstadoPedido.ENVIADO)
                || (estado == EstadoPedido.ENVIADO && nuevo == EstadoPedido.ENTREGADO);
    }

    public boolean tienePagoAprobado() {
        return pagos.stream().anyMatch(p -> p.getEstado() == EstadoPago.APROBADO);
    }

    public int montoReembolsado() {
        return devoluciones.stream()
                .filter(d -> d.getEstado() == EstadoDevolucion.REEMBOLSADA)
                .mapToInt(SolicitudDevolucion::getMontoReembolsado)
                .sum();
    }

    public int totalNeto() {
        return total - montoReembolsado();
    }
}
