package chibson.ventas.dto;

import chibson.ventas.model.MetodoPago;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PagoDTO {
    private MetodoPago metodoPago;

    private Boolean simularRechazo;
}
