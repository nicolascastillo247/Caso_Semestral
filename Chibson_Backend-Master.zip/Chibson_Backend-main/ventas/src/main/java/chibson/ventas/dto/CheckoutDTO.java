package chibson.ventas.dto;

import java.util.List;

import chibson.ventas.model.MetodoPago;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckoutDTO {
    private List<ItemDTO> items;
    private MetodoPago metodoPago;

    private Boolean usarDireccionDistinta;
    private String region;
    private String ciudadComuna;

    private String condominio;
    private String numero;

    private Boolean simularRechazo;
}
