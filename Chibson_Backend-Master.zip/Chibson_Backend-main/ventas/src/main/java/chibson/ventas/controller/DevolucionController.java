package chibson.ventas.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import java.util.List;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import chibson.ventas.dto.DevolucionDTO;
import chibson.ventas.dto.MotivoDTO;
import chibson.ventas.model.EstadoDevolucion;
import chibson.ventas.model.SolicitudDevolucion;
import chibson.ventas.service.DevolucionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/devoluciones")
@Tag(name = "Devoluciones", description = "Solicitudes de devolución y reembolsos")
public class DevolucionController {
    private static final String RUT = "X-Rut-Usuario";

    private final DevolucionService devolucionService;

    public DevolucionController(DevolucionService devolucionService) {
        this.devolucionService = devolucionService;
    }

    @PostMapping
    @Operation(summary = "El cliente solicita una devolución")
    public ResponseEntity<EntityModel<SolicitudDevolucion>> solicitar(
            @RequestHeader(value = RUT, required = false) String rut, @RequestBody DevolucionDTO datos) {
        return ResponseEntity.status(HttpStatus.CREATED).body(modelo(devolucionService.solicitar(rut, datos)));
    }

    @GetMapping("/mis-devoluciones")
    @Operation(summary = "Devoluciones del cliente que hace la petición")
    public CollectionModel<EntityModel<SolicitudDevolucion>> misDevoluciones(
            @RequestHeader(value = RUT, required = false) String rut) {
        return coleccion(devolucionService.listarPorCliente(rut),
                linkTo(DevolucionController.class).slash("mis-devoluciones").withSelfRel());
    }

    @GetMapping
    @Operation(summary = "Lista las devoluciones, opcionalmente por estado (administración)")
    public CollectionModel<EntityModel<SolicitudDevolucion>> listar(
            @RequestHeader(value = RUT, required = false) String rut,
            @RequestParam(required = false) EstadoDevolucion estado) {
        return coleccion(devolucionService.listar(rut, estado), linkTo(DevolucionController.class).withSelfRel());
    }

    @GetMapping("/pendientes/contar")
    @Operation(summary = "Cuenta las devoluciones pendientes (uso interno de ms-informes)")
    public long contarPendientes() {
        return devolucionService.contarPendientes();
    }

    @GetMapping("/{numero}")
    @Operation(summary = "Detalle de una devolución")
    public EntityModel<SolicitudDevolucion> detalle(@RequestHeader(value = RUT, required = false) String rut,
                                       @PathVariable Long numero) {
        return modelo(devolucionService.detalle(numero, rut));
    }

    @PatchMapping("/{numero}/aprobar")
    @Operation(summary = "Aprueba una devolución y repone el stock")
    public EntityModel<SolicitudDevolucion> aprobar(@RequestHeader(value = RUT, required = false) String rut,
                                       @PathVariable Long numero) {
        return modelo(devolucionService.aprobar(numero, rut));
    }

    @PatchMapping("/{numero}/rechazar")
    @Operation(summary = "Rechaza una devolución con un motivo")
    public EntityModel<SolicitudDevolucion> rechazar(@RequestHeader(value = RUT, required = false) String rut,
                                        @PathVariable Long numero, @RequestBody MotivoDTO datos) {
        return modelo(devolucionService.rechazar(numero, datos.getMotivo(), rut));
    }

    @PatchMapping("/{numero}/reembolsar")
    @Operation(summary = "Marca como reembolsada una devolución aprobada")
    public EntityModel<SolicitudDevolucion> reembolsar(@RequestHeader(value = RUT, required = false) String rut,
                                          @PathVariable Long numero) {
        return modelo(devolucionService.reembolsar(numero, rut));
    }

    private EntityModel<SolicitudDevolucion> modelo(SolicitudDevolucion devolucion) {
        return EntityModel.of(devolucion,
                linkTo(DevolucionController.class).slash(devolucion.getNumeroSeguimiento()).withSelfRel(),
                linkTo(DevolucionController.class).withRel("devoluciones"));
    }

    private CollectionModel<EntityModel<SolicitudDevolucion>> coleccion(List<SolicitudDevolucion> lista, Link self) {
        return CollectionModel.of(lista.stream().map(this::modelo).toList(), self);
    }
}
