package chibson.ventas.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DireccionDTO {
    private String region;
    private String ciudadComuna;
    private String condominio;
    private String numero;

    private boolean alternativa;
}
