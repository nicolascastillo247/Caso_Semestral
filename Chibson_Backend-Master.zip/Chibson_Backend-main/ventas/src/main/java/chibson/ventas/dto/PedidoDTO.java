package chibson.ventas.dto;

import org.springframework.hateoas.server.core.Relation;
import chibson.ventas.model.ItemPedido;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.model.HistorialEstadoPedido;
import chibson.ventas.model.MetodoPago;
import chibson.ventas.model.Pago;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Relation(itemRelation = "pedido", collectionRelation = "pedidos")
public class PedidoDTO {
    private Long numeroPedido;
    private String rutCliente;
    private String nombreCliente;
    private LocalDateTime fecha;
    private EstadoPedido estado;
    private Integer subtotal;
    private Integer costoEnvio;
    private Integer iva;
    private Integer total;
    private MetodoPago metodoPago;
    private DireccionDTO direccion;
    private String motivoCancelacion;
    private List<ItemPedido> items;
    private List<HistorialEstadoPedido> historial;
    private List<Pago> pagos;
}
