package chibson.ventas.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import chibson.ventas.dto.CheckoutDTO;
import chibson.ventas.dto.CompraRespuestaDTO;
import chibson.ventas.dto.EstadoDTO;
import chibson.ventas.dto.MotivoDTO;
import chibson.ventas.dto.PagoDTO;
import chibson.ventas.dto.PedidoDTO;
import chibson.ventas.dto.PedidoResumenDTO;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/pedidos")
@Tag(name = "Pedidos", description = "Compra, pago y gestión de pedidos")
public class PedidoController {
    private static final String RUT = "X-Rut-Usuario";

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @PostMapping("/checkout")
    @Operation(summary = "Compra el carrito: 201 si el pago se aprueba, 402 si se rechaza")
    public ResponseEntity<EntityModel<CompraRespuestaDTO>> comprar(
            @RequestHeader(value = RUT, required = false) String rut, @RequestBody CheckoutDTO datos) {
        return responder(pedidoService.comprar(rut, datos));
    }

    @PostMapping("/{numero}/pagar")
    @Operation(summary = "Reintenta el pago de un pedido pendiente")
    public ResponseEntity<EntityModel<CompraRespuestaDTO>> reintentarPago(
            @RequestHeader(value = RUT, required = false) String rut,
            @PathVariable Long numero, @RequestBody PagoDTO datos) {
        return responder(pedidoService.reintentarPago(numero, rut, datos.getMetodoPago(),
                Boolean.TRUE.equals(datos.getSimularRechazo())));
    }

    @GetMapping("/mis-pedidos")
    @Operation(summary = "Pedidos del cliente que hace la petición")
    public CollectionModel<EntityModel<PedidoDTO>> misPedidos(@RequestHeader(value = RUT, required = false) String rut) {
        return CollectionModel.of(pedidoService.listarPorCliente(rut).stream().map(this::modeloCliente).toList(),
                linkTo(PedidoController.class).slash("mis-pedidos").withSelfRel());
    }

    @GetMapping("/mis-pedidos/{numero}")
    @Operation(summary = "Detalle de un pedido del cliente")
    public EntityModel<PedidoDTO> miPedido(@RequestHeader(value = RUT, required = false) String rut,
                                           @PathVariable Long numero) {
        return modeloCliente(pedidoService.detalleCliente(numero, rut));
    }

    @GetMapping
    @Operation(summary = "Lista los pedidos, opcionalmente por estado (administración)")
    public CollectionModel<EntityModel<PedidoDTO>> listar(@RequestHeader(value = RUT, required = false) String rut,
                                                          @RequestParam(required = false) EstadoPedido estado) {
        return CollectionModel.of(pedidoService.listar(rut, estado).stream().map(this::modeloAdmin).toList(),
                linkTo(PedidoController.class).withSelfRel());
    }

    @GetMapping("/{numero}")
    @Operation(summary = "Detalle de un pedido (administración)")
    public EntityModel<PedidoDTO> detalle(@RequestHeader(value = RUT, required = false) String rut,
                                          @PathVariable Long numero) {
        return modeloAdmin(pedidoService.detalleAdmin(numero, rut));
    }

    @PatchMapping("/{numero}/estado")
    @Operation(summary = "Cambia el estado de un pedido")
    public EntityModel<PedidoDTO> actualizarEstado(@RequestHeader(value = RUT, required = false) String rut,
                                                   @PathVariable Long numero, @RequestBody EstadoDTO datos) {
        return modeloAdmin(pedidoService.actualizarEstado(numero, datos.getEstado(), rut));
    }

    @PatchMapping("/{numero}/cancelar")
    @Operation(summary = "Cancela un pedido con un motivo y repone el stock")
    public EntityModel<PedidoDTO> cancelar(@RequestHeader(value = RUT, required = false) String rut,
                                           @PathVariable Long numero, @RequestBody MotivoDTO datos) {
        return modeloAdmin(pedidoService.cancelar(numero, datos.getMotivo(), rut));
    }

    @DeleteMapping("/{numero}")
    @Operation(summary = "Elimina un pedido")
    public ResponseEntity<Void> eliminar(@RequestHeader(value = RUT, required = false) String rut,
                                         @PathVariable Long numero) {
        pedidoService.eliminar(numero, rut);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/cliente/{rut}/existe")
    @Operation(summary = "Indica si un cliente tiene pedidos (uso interno de ms-usuarios)")
    public boolean clienteTienePedidos(@PathVariable String rut) {
        return pedidoService.clienteTienePedidos(rut);
    }

    @GetMapping("/producto/{sku}/existe")
    @Operation(summary = "Indica si un producto tiene pedidos (uso interno de ms-productos)")
    public boolean productoTienePedidos(@PathVariable String sku) {
        return pedidoService.productoTienePedidos(sku);
    }

    @GetMapping("/cliente/{rut}/recibio/{sku}")
    @Operation(summary = "Indica si un cliente recibió un producto (uso interno de ms-productos)")
    public boolean clienteRecibioProducto(@PathVariable String rut, @PathVariable String sku) {
        return pedidoService.clienteRecibioProducto(rut, sku);
    }

    @GetMapping("/resumen")
    @Operation(summary = "Resumen de pedidos entre fechas (uso interno de ms-informes)")
    public List<PedidoResumenDTO> resumen(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        return pedidoService.resumen(desde, hasta);
    }

    private ResponseEntity<EntityModel<CompraRespuestaDTO>> responder(CompraRespuestaDTO respuesta) {
        HttpStatus estado = respuesta.isAprobado() ? HttpStatus.CREATED : HttpStatus.PAYMENT_REQUIRED;
        Long numero = respuesta.getPedido() == null ? null : respuesta.getPedido().getNumeroPedido();
        EntityModel<CompraRespuestaDTO> modelo = EntityModel.of(respuesta,
                linkTo(PedidoController.class).slash("mis-pedidos").slash(numero).withRel("pedido"),
                linkTo(PedidoController.class).slash(numero).slash("pagar").withRel("pagar"));
        return ResponseEntity.status(estado).body(modelo);
    }

    private EntityModel<PedidoDTO> modeloCliente(PedidoDTO pedido) {
        return EntityModel.of(pedido,
                linkTo(PedidoController.class).slash("mis-pedidos").slash(pedido.getNumeroPedido()).withSelfRel(),
                linkTo(PedidoController.class).slash("mis-pedidos").withRel("misPedidos"));
    }

    private EntityModel<PedidoDTO> modeloAdmin(PedidoDTO pedido) {
        return EntityModel.of(pedido,
                linkTo(PedidoController.class).slash(pedido.getNumeroPedido()).withSelfRel(),
                linkTo(PedidoController.class).withRel("pedidos"));
    }
}
