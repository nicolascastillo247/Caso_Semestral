package chibson.ventas.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockDTO {
    private String sku;
    private Integer stockDisponible;
    private Integer stockMinimo;
    private Boolean bajoStock;
}
