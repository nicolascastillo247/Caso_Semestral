package chibson.ventas.service;

public final class Permisos {
    public static final String GESTIONAR_PEDIDOS = "GESTIONAR_PEDIDOS";
    public static final String VER_VENTAS = "VER_VENTAS";

    private Permisos() {
    }
}
