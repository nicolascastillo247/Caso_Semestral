package chibson.ventas.client;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import chibson.ventas.dto.StockDTO;
import chibson.ventas.dto.MovimientoDTO;
import chibson.ventas.dto.ProductoDTO;

@Component
public class ProductosClient {
    private static final Pattern MENSAJE = Pattern.compile("\"message\"\\s*:\\s*\"([^\"]*)\"");

    private final RestTemplate restTemplate;
    private final String urlProductos;

    public ProductosClient(RestTemplate restTemplate, @Value("${servicios.productos.url}") String urlProductos) {
        this.restTemplate = restTemplate;
        this.urlProductos = urlProductos;
    }

    public ProductoDTO obtenerProducto(String sku) {
        try {
            return restTemplate.getForObject(urlProductos + "/api/productos/{sku}", ProductoDTO.class, sku);
        } catch (HttpClientErrorException.NotFound e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "El producto " + sku + " no está disponible");
        } catch (RestClientException e) {
            throw noDisponible();
        }
    }

    public StockDTO descontarStock(String sku, int cantidad, Long numeroPedido, String rutResponsable) {
        MovimientoDTO movimiento = new MovimientoDTO(cantidad, numeroPedido, null, rutResponsable);
        return enviarMovimiento(urlProductos + "/api/productos/{sku}/descontar", movimiento, sku);
    }

    public StockDTO reponerStock(String sku, int cantidad, Long numeroPedido, String tipo, String rutResponsable) {
        MovimientoDTO movimiento = new MovimientoDTO(cantidad, numeroPedido, tipo, rutResponsable);
        return enviarMovimiento(urlProductos + "/api/productos/{sku}/reponer", movimiento, sku);
    }

    private StockDTO enviarMovimiento(String url, MovimientoDTO movimiento, String sku) {
        try {
            return restTemplate.postForObject(url, movimiento, StockDTO.class, sku);
        } catch (HttpClientErrorException e) {
            throw new ResponseStatusException(e.getStatusCode(), extraerMensaje(e));
        } catch (RestClientException e) {
            throw noDisponible();
        }
    }

    private String extraerMensaje(HttpClientErrorException e) {
        Matcher m = MENSAJE.matcher(e.getResponseBodyAsString());
        return m.find() ? m.group(1) : "ms-productos rechazó la operación";
    }

    private ResponseStatusException noDisponible() {
        return new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                "No se pudo consultar los productos. Intente más tarde");
    }
}
