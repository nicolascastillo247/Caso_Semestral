package chibson.ventas.dto;

import java.util.List;

import chibson.ventas.model.MotivoDevolucion;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DevolucionDTO {
    private Long numeroPedido;

    private List<ItemDTO> items;
    private MotivoDevolucion motivo;
    private String descripcion;

    private String evidenciaUrl;
}
