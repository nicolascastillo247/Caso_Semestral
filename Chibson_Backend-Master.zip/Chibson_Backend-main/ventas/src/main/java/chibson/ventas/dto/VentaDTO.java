package chibson.ventas.dto;

import org.springframework.hateoas.server.core.Relation;
import chibson.ventas.model.ItemPedido;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.model.MetodoPago;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Relation(itemRelation = "venta", collectionRelation = "ventas")
public class VentaDTO {
    private Long numeroVenta;
    private String rutCliente;
    private String nombreCliente;
    private LocalDateTime fecha;
    private Integer total;

    private Integer montoReembolsado;

    private Integer totalNeto;
    private MetodoPago metodoPago;
    private EstadoPedido estadoPedido;
    private List<ItemPedido> items;

    private List<ReembolsoDTO> reembolsos;
}
