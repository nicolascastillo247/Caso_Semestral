package chibson.ventas.model;

public enum MotivoDevolucion {
    PRODUCTO_DANADO,
    PRODUCTO_DEFECTUOSO,
    PRODUCTO_INCORRECTO,
    OTRO
}
