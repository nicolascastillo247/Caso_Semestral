package chibson.ventas.model;

public enum MetodoPago {
    DEBITO,
    CREDITO,
    TRANSFERENCIA
}
