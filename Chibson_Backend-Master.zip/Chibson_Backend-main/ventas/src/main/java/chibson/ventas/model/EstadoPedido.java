package chibson.ventas.model;

public enum EstadoPedido {
    PENDIENTE,
    PAGADO,
    EN_PROCESO,
    ENVIADO,
    ENTREGADO,
    CANCELADO
}
