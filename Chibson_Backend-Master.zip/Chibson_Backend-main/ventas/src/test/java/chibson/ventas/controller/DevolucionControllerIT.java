package chibson.ventas.controller;

import chibson.ventas.LimpiezaBaseDatos;
import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.ProductoDTO;
import chibson.ventas.dto.UsuarioDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class DevolucionControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final String COMPRA = "{\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":2}],\"metodoPago\":\"DEBITO\"}";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @MockitoBean
    private UsuariosClient usuariosClient;
    @MockitoBean
    private ProductosClient productosClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
        UsuarioDTO ana = new UsuarioDTO(CLIENTE, "Ana", "Pérez", "Metropolitana", "Santiago", "Condominio Sur", "10", "ACTIVO");
        when(usuariosClient.obtenerCliente(CLIENTE)).thenReturn(ana);
        when(usuariosClient.buscarUsuario(any())).thenReturn(ana);
        when(productosClient.obtenerProducto("GTR-0001"))
                .thenReturn(new ProductoDTO("GTR-0001", "Stratocaster", 10000, "GUITARRA", 50));
    }

    private Long comprar() throws Exception {
        String json = mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(COMPRA))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return Long.valueOf(json.replaceAll(".*?\"numeroPedido\":(\\d+).*", "$1"));
    }

    private void cambiarEstado(Long numero, String estado) throws Exception {
        mockMvc.perform(patch("/api/pedidos/" + numero + "/estado").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"estado\":\"" + estado + "\"}"))
                .andExpect(status().isOk());
    }

    private Long entregar() throws Exception {
        Long numero = comprar();
        cambiarEstado(numero, "EN_PROCESO");
        cambiarEstado(numero, "ENVIADO");
        cambiarEstado(numero, "ENTREGADO");
        return numero;
    }

    private static final String DEVOLUCION = "{\"numeroPedido\":%d,\"motivo\":\"PRODUCTO_DANADO\",\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":%d}]}";

    private Long solicitar(Long pedido, int cantidad) throws Exception {
        String json = mockMvc.perform(post("/api/devoluciones").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(String.format(DEVOLUCION, pedido, cantidad)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return Long.valueOf(json.replaceAll(".*?\"numeroSeguimiento\":(\\d+).*", "$1"));
    }

    @Test
    void requestReturn() throws Exception {
        Long pedido = entregar();

        mockMvc.perform(post("/api/devoluciones").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(String.format(DEVOLUCION, pedido, 1)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.estado").value("PENDIENTE"))
                .andExpect(jsonPath("$.items.length()").value(1));
    }

    @Test
    void requestNotDelivered400() throws Exception {
        Long pedido = comprar();

        mockMvc.perform(post("/api/devoluciones").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(String.format(DEVOLUCION, pedido, 1)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void requestMoreThanBought400() throws Exception {
        Long pedido = entregar();

        mockMvc.perform(post("/api/devoluciones").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(String.format(DEVOLUCION, pedido, 3)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void requestWithoutReason400() throws Exception {
        Long pedido = entregar();

        mockMvc.perform(post("/api/devoluciones").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"numeroPedido\":" + pedido + ",\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":1}]}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void myReturnsAndAdminList() throws Exception {
        Long pedido = entregar();
        solicitar(pedido, 1);

        mockMvc.perform(get("/api/devoluciones/mis-devoluciones").header("X-Rut-Usuario", CLIENTE))
                .andExpect(jsonPath("$._embedded.devoluciones.length()").value(1));
        mockMvc.perform(get("/api/devoluciones").header("X-Rut-Usuario", ADMIN))
                .andExpect(jsonPath("$._embedded.devoluciones.length()").value(1));
        mockMvc.perform(get("/api/devoluciones").header("X-Rut-Usuario", ADMIN).param("estado", "APROBADA"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/devoluciones/pendientes/contar"))
                .andExpect(content().string("1"));
    }

    @Test
    void detailAndNotFound() throws Exception {
        Long seguimiento = solicitar(entregar(), 1);

        mockMvc.perform(get("/api/devoluciones/" + seguimiento).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.numeroSeguimiento").value(seguimiento));
        mockMvc.perform(get("/api/devoluciones/999999").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void approveAndRefund() throws Exception {
        Long seguimiento = solicitar(entregar(), 2);

        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/reembolsar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/aprobar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("APROBADA"));
        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/aprobar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/reembolsar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("REEMBOLSADA"))
                .andExpect(jsonPath("$.montoReembolsado").value(20000));
        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/reembolsar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isBadRequest());
    }

    @Test
    void rejectReturn() throws Exception {
        Long seguimiento = solicitar(entregar(), 1);

        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/rechazar").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"motivo\":\" \"}"))
                .andExpect(status().isBadRequest());
        mockMvc.perform(patch("/api/devoluciones/" + seguimiento + "/rechazar").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"motivo\":\"Fuera de garantía\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("RECHAZADA"))
                .andExpect(jsonPath("$.motivoRechazo").value("Fuera de garantía"));
    }

    @Test
    void adminForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("GESTIONAR_PEDIDOS"));

        mockMvc.perform(get("/api/devoluciones").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isForbidden());
    }
}
