package chibson.ventas.controller;

import chibson.ventas.dto.VentaDTO;
import chibson.ventas.model.MetodoPago;
import chibson.ventas.service.VentaService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(VentaController.class)
@ActiveProfiles("test")
class VentaControllerTest {
    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private VentaService ventaService;

    @Autowired
    private MockMvc mvc;

    @Test
    void listSales() throws Exception {
        VentaDTO v = new VentaDTO();
        v.setNumeroVenta(7L);
        v.setItems(new ArrayList<>());
        v.setReembolsos(new ArrayList<>());
        when(ventaService.listar(ADMIN, "ana", MetodoPago.DEBITO, LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31)))
                .thenReturn(List.of(v));

        mvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("texto", "ana")
                        .param("metodo", "DEBITO").param("desde", "2026-01-01").param("hasta", "2026-01-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.ventas[0].numeroVenta").value(7))
                .andExpect(jsonPath("$._links.self.href").exists());
    }

    @Test
    void saleDetail() throws Exception {
        VentaDTO v = new VentaDTO();
        v.setNumeroVenta(7L);
        v.setItems(new ArrayList<>());
        v.setReembolsos(new ArrayList<>());
        when(ventaService.detalle(7L, ADMIN)).thenReturn(v);

        mvc.perform(get("/api/ventas/7").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.numeroVenta").value(7))
                .andExpect(jsonPath("$._links.self.href").exists())
                .andExpect(jsonPath("$._links.ventas.href").exists());
    }

    @Test
    void salesForbidden() throws Exception {
        when(ventaService.listar(CLIENTE, null, null, null, null))
                .thenThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"));

        mvc.perform(get("/api/ventas").header("X-Rut-Usuario", CLIENTE)).andExpect(status().isForbidden());
    }
}
