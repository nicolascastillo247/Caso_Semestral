package chibson.ventas.service;

import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.CheckoutDTO;
import chibson.ventas.dto.CompraRespuestaDTO;
import chibson.ventas.dto.ItemDTO;
import chibson.ventas.dto.PedidoDTO;
import chibson.ventas.dto.ProductoDTO;
import chibson.ventas.dto.UsuarioDTO;
import chibson.ventas.model.EstadoPago;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.model.ItemPedido;
import chibson.ventas.model.MetodoPago;
import chibson.ventas.model.Pago;
import chibson.ventas.model.Pedido;
import chibson.ventas.repository.PedidoRepository;
import chibson.ventas.service.PedidoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PedidoServiceTest {
    private static final String RUT = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final int COSTO_ENVIO = 5000;

    @Mock
    private PedidoRepository pedidoRepository;
    @Mock
    private ProductosClient productosClient;
    @Mock
    private UsuariosClient usuariosClient;

    private PedidoService pedidoService;

    @BeforeEach
    void setUp() {
        pedidoService = new PedidoService(pedidoRepository, productosClient, usuariosClient, COSTO_ENVIO);
    }

    private UsuarioDTO clienteConDireccion() {
        return new UsuarioDTO(RUT, "Ana", "Pérez", "Metropolitana", "Santiago", null, "123", "ACTIVO");
    }

    private ProductoDTO producto(String sku, int precio, int stock) {
        return new ProductoDTO(sku, "Modelo " + sku, precio, "GUITARRA", stock);
    }

    private CheckoutDTO checkout(ItemDTO... items) {
        return new CheckoutDTO(List.of(items), MetodoPago.DEBITO, false, null, null, null, null, false);
    }

    private Pedido pedido(EstadoPedido estado, boolean pagado) {
        Pedido p = new Pedido();
        p.setNumeroPedido(50L);
        p.setRutCliente(RUT);
        p.setFecha(LocalDateTime.now());
        p.setEstado(estado);
        p.setTotal(105000);
        ItemPedido item = new ItemPedido();
        item.setSku("GTR-0001");
        item.setCantidad(2);
        item.setPrecioUnitario(50000);
        item.setPedido(p);
        p.getItems().add(item);
        if (pagado) {
            Pago pago = new Pago();
            pago.setEstado(EstadoPago.APROBADO);
            pago.setPedido(p);
            p.getPagos().add(pago);
        }
        return p;
    }

    @Test
    void purchaseApproved() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(productosClient.obtenerProducto("GTR-0001")).thenReturn(producto("GTR-0001", 100000, 5));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        CompraRespuestaDTO respuesta = pedidoService.comprar(RUT, checkout(new ItemDTO("GTR-0001", 2)));

        assertTrue(respuesta.isAprobado());
        PedidoDTO pedido = respuesta.getPedido();
        assertEquals(EstadoPedido.PAGADO, pedido.getEstado());
        assertEquals(200000, pedido.getSubtotal());
        assertEquals(31933, pedido.getIva());
        assertEquals(COSTO_ENVIO, pedido.getCostoEnvio());
        assertEquals(205000, pedido.getTotal());
        verify(productosClient).descontarStock(eq("GTR-0001"), eq(2), any(), eq(RUT));
        verify(usuariosClient).enviarNotificacion(eq(RUT), anyString(), anyString());
    }

    @Test
    void priceFromProducts() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(productosClient.obtenerProducto("GTR-0001")).thenReturn(producto("GTR-0001", 70000, 5));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        CompraRespuestaDTO respuesta = pedidoService.comprar(RUT, checkout(new ItemDTO("GTR-0001", 1)));

        assertEquals(70000, respuesta.getPedido().getSubtotal());
    }

    @Test
    void repeatedProductMerged() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(productosClient.obtenerProducto("GTR-0001")).thenReturn(producto("GTR-0001", 10000, 10));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        CompraRespuestaDTO respuesta = pedidoService.comprar(RUT,
                checkout(new ItemDTO("gtr-0001", 2), new ItemDTO("GTR-0001", 3)));

        assertEquals(1, respuesta.getPedido().getItems().size());
        assertEquals(5, respuesta.getPedido().getItems().get(0).getCantidad());
    }

    @Test
    void noPaymentMethod() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        CheckoutDTO datos = checkout(new ItemDTO("GTR-0001", 1));
        datos.setMetodoPago(null);

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> pedidoService.comprar(RUT, datos));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void noProducts() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        CheckoutDTO datos = new CheckoutDTO(List.of(), MetodoPago.DEBITO, false, null, null, null, null, false);

        assertThrows(ResponseStatusException.class, () -> pedidoService.comprar(RUT, datos));
        verify(pedidoRepository, never()).save(any());
    }

    @Test
    void invalidItem() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());

        assertThrows(ResponseStatusException.class,
                () -> pedidoService.comprar(RUT, checkout(new ItemDTO("GTR-0001", 0))));
        assertThrows(ResponseStatusException.class,
                () -> pedidoService.comprar(RUT, checkout(new ItemDTO(" ", 1))));
    }

    @Test
    void insufficientStock() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(productosClient.obtenerProducto("GTR-0001")).thenReturn(producto("GTR-0001", 100000, 1));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> pedidoService.comprar(RUT, checkout(new ItemDTO("GTR-0001", 2))));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
        verify(pedidoRepository, never()).save(any());
        verify(productosClient, never()).descontarStock(anyString(), anyInt(), any(), anyString());
    }

    @Test
    void noAddress() {
        UsuarioDTO sinDireccion = new UsuarioDTO(RUT, "Ana", "Pérez", null, null, null, null, "ACTIVO");
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(sinDireccion);

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> pedidoService.comprar(RUT, checkout(new ItemDTO("GTR-0001", 1))));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void paymentRejected() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(productosClient.obtenerProducto("GTR-0001")).thenReturn(producto("GTR-0001", 100000, 5));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));
        CheckoutDTO datos = checkout(new ItemDTO("GTR-0001", 1));
        datos.setSimularRechazo(true);

        CompraRespuestaDTO respuesta = pedidoService.comprar(RUT, datos);

        assertFalse(respuesta.isAprobado());
        assertEquals(EstadoPedido.PENDIENTE, respuesta.getPedido().getEstado());
        verify(productosClient, never()).descontarStock(anyString(), anyInt(), any(), anyString());
    }

    @Test
    void stockFailureRestocks() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(productosClient.obtenerProducto("GTR-0001")).thenReturn(producto("GTR-0001", 100000, 5));
        when(productosClient.obtenerProducto("BAJ-0001")).thenReturn(producto("BAJ-0001", 80000, 5));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));
        when(productosClient.descontarStock(eq("GTR-0001"), anyInt(), any(), anyString())).thenReturn(null);
        doThrow(new ResponseStatusException(HttpStatus.CONFLICT, "Stock insuficiente"))
                .when(productosClient).descontarStock(eq("BAJ-0001"), anyInt(), any(), anyString());

        assertThrows(ResponseStatusException.class, () -> pedidoService.comprar(RUT,
                checkout(new ItemDTO("GTR-0001", 1), new ItemDTO("BAJ-0001", 1))));

        verify(productosClient).reponerStock(eq("GTR-0001"), eq(1), any(), eq("CANCELACION"), eq(RUT));
    }

    @Test
    void retryPendingOnly() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(clienteConDireccion());
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(pedido(EstadoPedido.PAGADO, true)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> pedidoService.reintentarPago(50L, RUT, null, false));

        assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
    }

    @Test
    void retryOtherClient() {
        when(usuariosClient.obtenerCliente("22222222-2"))
                .thenReturn(new UsuarioDTO("22222222-2", "Luis", "Soto", "R", "C", null, "1", "ACTIVO"));
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(pedido(EstadoPedido.PENDIENTE, false)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> pedidoService.reintentarPago(50L, "22222222-2", null, false));

        assertEquals(HttpStatus.NOT_FOUND, e.getStatusCode());
    }

    @Test
    void statusFlow() {
        Pedido p = pedido(EstadoPedido.PAGADO, true);
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(p));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        PedidoDTO enProceso = pedidoService.actualizarEstado(50L, EstadoPedido.EN_PROCESO, ADMIN);
        assertEquals(EstadoPedido.EN_PROCESO, enProceso.getEstado());

        assertThrows(ResponseStatusException.class,
                () -> pedidoService.actualizarEstado(50L, EstadoPedido.ENTREGADO, ADMIN));
    }

    @Test
    void cancelViaStatusRejected() {
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(pedido(EstadoPedido.PAGADO, true)));

        assertThrows(ResponseStatusException.class,
                () -> pedidoService.actualizarEstado(50L, EstadoPedido.CANCELADO, ADMIN));
    }

    @Test
    void cancelPaidRestocks() {
        Pedido p = pedido(EstadoPedido.PAGADO, true);
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(p));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        PedidoDTO cancelado = pedidoService.cancelar(50L, " Cliente lo pidió ", ADMIN);

        assertEquals(EstadoPedido.CANCELADO, cancelado.getEstado());
        assertEquals("Cliente lo pidió", cancelado.getMotivoCancelacion());
        verify(productosClient).reponerStock("GTR-0001", 2, 50L, "CANCELACION", ADMIN);
    }

    @Test
    void cancelUnpaid() {
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(pedido(EstadoPedido.PENDIENTE, false)));
        when(pedidoRepository.save(any(Pedido.class))).thenAnswer(i -> i.getArgument(0));

        pedidoService.cancelar(50L, "Sin pago", ADMIN);

        verify(productosClient, never()).reponerStock(anyString(), anyInt(), anyLong(), anyString(), anyString());
    }

    @Test
    void cancelInvalid() {
        assertThrows(ResponseStatusException.class, () -> pedidoService.cancelar(50L, "  ", ADMIN));

        when(pedidoRepository.findById(51L)).thenReturn(Optional.of(pedido(EstadoPedido.ENTREGADO, true)));
        assertThrows(ResponseStatusException.class, () -> pedidoService.cancelar(51L, "Motivo", ADMIN));
    }

    @Test
    void deleteInvoiced() {
        Pedido p = pedido(EstadoPedido.PAGADO, true);
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(p));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> pedidoService.eliminar(50L, ADMIN));

        assertEquals(HttpStatus.CONFLICT, e.getStatusCode());
        verify(pedidoRepository, never()).delete(any());
    }

    @Test
    void deletePending() {
        Pedido p = pedido(EstadoPedido.PENDIENTE, false);
        when(pedidoRepository.findById(50L)).thenReturn(Optional.of(p));

        pedidoService.eliminar(50L, ADMIN);

        verify(pedidoRepository).delete(p);
    }
}
