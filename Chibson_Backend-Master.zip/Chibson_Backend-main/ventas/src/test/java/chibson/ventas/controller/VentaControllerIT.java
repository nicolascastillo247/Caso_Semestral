package chibson.ventas.controller;

import chibson.ventas.LimpiezaBaseDatos;
import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.ProductoDTO;
import chibson.ventas.dto.UsuarioDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class VentaControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final String COMPRA = "{\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":2}],\"metodoPago\":\"DEBITO\"}";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @MockitoBean
    private UsuariosClient usuariosClient;
    @MockitoBean
    private ProductosClient productosClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
        UsuarioDTO ana = new UsuarioDTO(CLIENTE, "Ana", "Pérez", "Metropolitana", "Santiago", "Condominio Sur", "10", "ACTIVO");
        when(usuariosClient.obtenerCliente(CLIENTE)).thenReturn(ana);
        when(usuariosClient.buscarUsuario(any())).thenReturn(ana);
        when(productosClient.obtenerProducto("GTR-0001"))
                .thenReturn(new ProductoDTO("GTR-0001", "Stratocaster", 10000, "GUITARRA", 50));
    }

    private Long comprar() throws Exception {
        String json = mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(COMPRA))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return Long.valueOf(json.replaceAll(".*?\"numeroPedido\":(\\d+).*", "$1"));
    }

    private void cambiarEstado(Long numero, String estado) throws Exception {
        mockMvc.perform(patch("/api/pedidos/" + numero + "/estado").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"estado\":\"" + estado + "\"}"))
                .andExpect(status().isOk());
    }

    private Long entregar() throws Exception {
        Long numero = comprar();
        cambiarEstado(numero, "EN_PROCESO");
        cambiarEstado(numero, "ENVIADO");
        cambiarEstado(numero, "ENTREGADO");
        return numero;
    }

    @Test
    void listOnlyPaidOrders() throws Exception {
        comprar();
        mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                .content(COMPRA.replace("}", ",\"simularRechazo\":true}")));

        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.ventas.length()").value(1))
                .andExpect(jsonPath("$._embedded.ventas[0].nombreCliente").value("Ana Pérez"));
    }

    @Test
    void listWithFilters() throws Exception {
        comprar();

        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("metodo", "DEBITO"))
                .andExpect(jsonPath("$._embedded.ventas.length()").value(1));
        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("metodo", "CREDITO"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("texto", "ana"))
                .andExpect(jsonPath("$._embedded.ventas.length()").value(1));
        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("texto", "zzz"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("desde", "2000-01-01").param("hasta", "2999-01-01"))
                .andExpect(jsonPath("$._embedded.ventas.length()").value(1));
    }

    @Test
    void listInvalidDates400() throws Exception {
        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN).param("desde", "2026-12-01").param("hasta", "2026-01-01"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void detailAndNotFound() throws Exception {
        Long numero = comprar();

        mockMvc.perform(get("/api/ventas/" + numero).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.numeroVenta").value(numero))
                .andExpect(jsonPath("$.totalNeto").exists());
        mockMvc.perform(get("/api/ventas/999999").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void forbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("VER_VENTAS"));

        mockMvc.perform(get("/api/ventas").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isForbidden());
    }
}
