package chibson.ventas.service;

import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.PedidoDTO;
import chibson.ventas.dto.PedidoResumenDTO;
import chibson.ventas.dto.UsuarioDTO;
import chibson.ventas.dto.VentaDTO;
import chibson.ventas.model.EstadoPago;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.model.ItemDevolucion;
import chibson.ventas.model.ItemPedido;
import chibson.ventas.model.MetodoPago;
import chibson.ventas.model.Pago;
import chibson.ventas.model.Pedido;
import chibson.ventas.model.SolicitudDevolucion;
import chibson.ventas.repository.PedidoRepository;
import chibson.ventas.service.PedidoService;
import chibson.ventas.service.VentaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VentaYConsultasPedidoTest {
    private static final String RUT = "11111111-1";
    private static final String ADMIN = "12345678-5";

    @Mock
    private PedidoRepository pedidoRepository;
    @Mock
    private ProductosClient productosClient;
    @Mock
    private UsuariosClient usuariosClient;

    private PedidoService pedidoService;
    private VentaService ventaService;

    @BeforeEach
    void setUp() {
        pedidoService = new PedidoService(pedidoRepository, productosClient, usuariosClient, 5000);
        ventaService = new VentaService(pedidoRepository, usuariosClient);
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    private UsuarioDTO cliente() {
        return new UsuarioDTO(RUT, "Ana", "Pérez", "Metropolitana", "Santiago", "Cond", "123", "ACTIVO");
    }

    private Pedido pedido(Long numero, LocalDateTime fecha, EstadoPedido estado, boolean pagado) {
        Pedido p = new Pedido();
        p.setNumeroPedido(numero);
        p.setRutCliente(RUT);
        p.setFecha(fecha);
        p.setEstado(estado);
        p.setSubtotal(100000);
        p.setCostoEnvio(5000);
        p.setIva(19950);
        p.setTotal(124950);
        p.setMetodoPago(MetodoPago.DEBITO);
        ItemPedido item = new ItemPedido();
        item.setSku("GTR-0001");
        item.setNombreProducto("Strato");
        item.setCantidad(1);
        item.setPrecioUnitario(100000);
        item.setPedido(p);
        p.getItems().add(item);
        if (pagado) {
            Pago pago = new Pago();
            pago.setEstado(EstadoPago.APROBADO);
            pago.setPedido(p);
            p.getPagos().add(pago);
        }
        return p;
    }

    private void reembolsar(Pedido p, LocalDateTime fecha) {
        SolicitudDevolucion s = new SolicitudDevolucion();
        ItemDevolucion item = new ItemDevolucion();
        item.setSku("GTR-0001");
        item.setCantidad(1);
        item.setPrecioUnitario(100000);
        s.getItems().add(item);
        s.setPedido(p);
        s.reembolsar(ADMIN);
        s.setFechaReembolso(fecha);
        p.getDevoluciones().add(s);
    }

    @Test
    void clientOrders() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        when(pedidoRepository.findByRutClienteOrderByFechaDesc(RUT))
                .thenReturn(List.of(pedido(1L, LocalDateTime.now(), EstadoPedido.PAGADO, true)));

        List<PedidoDTO> lista = pedidoService.listarPorCliente(RUT);

        assertEquals(1, lista.size());
        assertEquals("Ana Pérez", lista.get(0).getNombreCliente());
        assertEquals("Santiago", lista.get(0).getDireccion().getCiudadComuna());
        assertFalse(lista.get(0).getDireccion().isAlternativa());
    }

    @Test
    void clientDetailAltAddress() {
        Pedido p = pedido(1L, LocalDateTime.now(), EstadoPedido.PAGADO, true);
        p.setRegionEnvio("Valparaíso");
        p.setCiudadComunaEnvio("Viña");
        p.setNumeroEnvio("9");
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(p));

        PedidoDTO dto = pedidoService.detalleCliente(1L, RUT);

        assertTrue(dto.getDireccion().isAlternativa());
        assertEquals("Valparaíso", dto.getDireccion().getRegion());
    }

    @Test
    void otherClientOrder() {
        Pedido p = pedido(1L, LocalDateTime.now(), EstadoPedido.PAGADO, true);
        p.setRutCliente("99999999-9");
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(p));

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> pedidoService.detalleCliente(1L, RUT))));
    }

    @Test
    void orderNotFound() {
        when(pedidoRepository.findById(9L)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> pedidoService.findById(9L))));
    }

    @Test
    void adminListFilters() {
        Pedido a = pedido(1L, LocalDateTime.now(), EstadoPedido.PAGADO, true);
        Pedido b = pedido(2L, LocalDateTime.now(), EstadoPedido.ENTREGADO, true);
        when(pedidoRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(a, b));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(null);

        List<PedidoDTO> todos = pedidoService.listar(ADMIN, null);
        List<PedidoDTO> pagados = pedidoService.listar(ADMIN, EstadoPedido.PAGADO);

        assertEquals(2, todos.size());
        assertNull(todos.get(0).getNombreCliente());
        assertNull(todos.get(0).getDireccion());
        assertEquals(1, pagados.size());
    }

    @Test
    void adminListForbidden() {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(RUT, "GESTIONAR_PEDIDOS");

        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> pedidoService.listar(RUT, null))));
    }

    @Test
    void adminDetail() {
        Pedido p = pedido(1L, LocalDateTime.now(), EstadoPedido.PAGADO, true);
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(p));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(cliente());

        assertEquals("Ana Pérez", pedidoService.detalleAdmin(1L, ADMIN).getNombreCliente());
    }

    @Test
    void existenceChecks() {
        when(pedidoRepository.existsByRutCliente(RUT)).thenReturn(true);
        when(pedidoRepository.existsByItemsSku("GTR-0001")).thenReturn(true);
        when(pedidoRepository.existsByRutClienteAndEstadoAndItemsSku(RUT, EstadoPedido.ENTREGADO, "GTR-0001"))
                .thenReturn(true);

        assertTrue(pedidoService.clienteTienePedidos(RUT));
        assertTrue(pedidoService.productoTienePedidos("GTR-0001"));
        assertTrue(pedidoService.clienteRecibioProducto(RUT, "GTR-0001"));
        assertFalse(pedidoService.productoTienePedidos("OTRO-0001"));
    }

    @Test
    void summaryInRange() {
        Pedido dentro = pedido(1L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.PAGADO, true);
        Pedido fuera = pedido(2L, LocalDateTime.of(2026, 1, 5, 10, 0), EstadoPedido.ENTREGADO, true);
        Pedido fueraConReembolso = pedido(3L, LocalDateTime.of(2026, 1, 6, 10, 0), EstadoPedido.ENTREGADO, true);
        fueraConReembolso.setRegionEnvio("Biobío");
        reembolsar(fueraConReembolso, LocalDateTime.of(2026, 2, 12, 10, 0));
        when(pedidoRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(dentro, fuera, fueraConReembolso));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(cliente());

        List<PedidoResumenDTO> r = pedidoService.resumen(LocalDate.of(2026, 2, 1), LocalDate.of(2026, 2, 28));

        assertEquals(2, r.size());
        assertEquals("Metropolitana", r.get(0).getRegion());
        assertTrue(r.get(0).isPagado());
        assertEquals("Biobío", r.get(1).getRegion());
        assertEquals(1, r.get(1).getReembolsos().size());
    }

    @Test
    void summaryNoDates() {
        when(pedidoRepository.findAllByOrderByFechaDesc())
                .thenReturn(List.of(pedido(1L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.PAGADO, false)));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(null);

        List<PedidoResumenDTO> r = pedidoService.resumen(null, null);

        assertEquals(1, r.size());
        assertNull(r.get(0).getRegion());
        assertFalse(r.get(0).isPagado());
    }

    @Test
    void salesPaidOnly() {
        Pedido pagado = pedido(1L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.PAGADO, true);
        Pedido pendiente = pedido(2L, LocalDateTime.of(2026, 2, 11, 10, 0), EstadoPedido.PENDIENTE, false);
        when(pedidoRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(pendiente, pagado));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(cliente());

        List<VentaDTO> ventas = ventaService.listar(ADMIN, null, null, null, null);

        assertEquals(1, ventas.size());
        assertEquals(1L, ventas.get(0).getNumeroVenta());
        assertEquals(124950, ventas.get(0).getTotalNeto());
    }

    @Test
    void salesFilterMethodDates() {
        Pedido a = pedido(1L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.PAGADO, true);
        Pedido b = pedido(2L, LocalDateTime.of(2026, 3, 10, 10, 0), EstadoPedido.PAGADO, true);
        b.setMetodoPago(MetodoPago.CREDITO);
        when(pedidoRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(a, b));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(cliente());

        assertEquals(1, ventaService.listar(ADMIN, null, MetodoPago.CREDITO, null, null).size());
        assertEquals(1, ventaService.listar(ADMIN, null, null, LocalDate.of(2026, 3, 1), null).size());
        assertEquals(1, ventaService.listar(ADMIN, null, null, null, LocalDate.of(2026, 2, 28)).size());
    }

    @Test
    void salesFilterText() {
        Pedido a = pedido(15L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.PAGADO, true);
        when(pedidoRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(a));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(cliente());

        assertEquals(1, ventaService.listar(ADMIN, " ", null, null, null).size());
        assertEquals(1, ventaService.listar(ADMIN, "#15", null, null, null).size());
        assertEquals(1, ventaService.listar(ADMIN, "ANA", null, null, null).size());
        assertEquals(1, ventaService.listar(ADMIN, "11111111", null, null, null).size());
        assertEquals(0, ventaService.listar(ADMIN, "zzz", null, null, null).size());
    }

    @Test
    void salesSearchByRut() {
        Pedido a = pedido(15L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.PAGADO, true);
        when(pedidoRepository.findAllByOrderByFechaDesc()).thenReturn(List.of(a));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(null);

        assertEquals(1, ventaService.listar(ADMIN, "11111111", null, null, null).size());
        assertEquals(0, ventaService.listar(ADMIN, "ana", null, null, null).size());
    }

    @Test
    void salesInvalidRange() {
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> ventaService.listar(ADMIN, null, null, LocalDate.of(2026, 3, 1), LocalDate.of(2026, 2, 1)))));
    }

    @Test
    void salesNoPermission() {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(RUT, "VER_VENTAS");

        assertThrows(ResponseStatusException.class, () -> ventaService.listar(RUT, null, null, null, null));
        verify(pedidoRepository, never()).findAllByOrderByFechaDesc();
    }

    @Test
    void saleDetailRefund() {
        Pedido p = pedido(1L, LocalDateTime.of(2026, 2, 10, 10, 0), EstadoPedido.ENTREGADO, true);
        reembolsar(p, LocalDateTime.of(2026, 2, 20, 10, 0));
        when(pedidoRepository.findById(1L)).thenReturn(Optional.of(p));
        when(usuariosClient.buscarUsuario(RUT)).thenReturn(cliente());

        VentaDTO v = ventaService.detalle(1L, ADMIN);

        assertEquals(100000, v.getMontoReembolsado());
        assertEquals(24950, v.getTotalNeto());
        assertEquals(1, v.getReembolsos().size());
    }

    @Test
    void unpaidNotSale() {
        when(pedidoRepository.findById(2L))
                .thenReturn(Optional.of(pedido(2L, LocalDateTime.now(), EstadoPedido.PENDIENTE, false)));

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> ventaService.detalle(2L, ADMIN))));
    }

    @Test
    void saleNotFound() {
        when(pedidoRepository.findById(9L)).thenReturn(Optional.empty());

        assertSame(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> ventaService.detalle(9L, ADMIN))));
    }
}
