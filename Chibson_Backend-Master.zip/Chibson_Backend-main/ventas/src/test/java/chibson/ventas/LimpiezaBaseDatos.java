package chibson.ventas;

import chibson.ventas.repository.DevolucionRepository;
import chibson.ventas.repository.HistorialEstadoRepository;
import chibson.ventas.repository.PagoRepository;
import chibson.ventas.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LimpiezaBaseDatos {
    @Autowired
    private DevolucionRepository devolucionRepository;

    @Autowired
    private PagoRepository pagoRepository;

    @Autowired
    private HistorialEstadoRepository historialEstadoRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    public void limpiar() {
        devolucionRepository.deleteAll();
        pagoRepository.deleteAll();
        historialEstadoRepository.deleteAll();
        pedidoRepository.deleteAll();
    }
}
