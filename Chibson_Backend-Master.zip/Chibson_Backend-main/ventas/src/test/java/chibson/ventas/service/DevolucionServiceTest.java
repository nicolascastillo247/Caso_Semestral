package chibson.ventas.service;

import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.DevolucionDTO;
import chibson.ventas.dto.ItemDTO;
import chibson.ventas.dto.RegistroAccionDTO;
import chibson.ventas.dto.UsuarioDTO;
import chibson.ventas.model.EstadoDevolucion;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.model.HistorialEstadoPedido;
import chibson.ventas.model.ItemDevolucion;
import chibson.ventas.model.ItemPedido;
import chibson.ventas.model.MotivoDevolucion;
import chibson.ventas.model.Pedido;
import chibson.ventas.model.SolicitudDevolucion;
import chibson.ventas.repository.DevolucionRepository;
import chibson.ventas.service.DevolucionService;
import chibson.ventas.service.PedidoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DevolucionServiceTest {
    private static final String RUT = "11111111-1";
    private static final String ADMIN = "12345678-5";

    @Mock
    private DevolucionRepository devolucionRepository;
    @Mock
    private PedidoService pedidoService;
    @Mock
    private ProductosClient productosClient;
    @Mock
    private UsuariosClient usuariosClient;

    private DevolucionService service;

    @BeforeEach
    void setUp() {
        service = new DevolucionService(devolucionRepository, pedidoService, productosClient, usuariosClient);
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    private UsuarioDTO cliente() {
        return new UsuarioDTO(RUT, "Ana", "Pérez", null, null, null, null, "ACTIVO");
    }

    private Pedido pedidoEntregado(long diasAtras) {
        Pedido p = new Pedido();
        p.setNumeroPedido(50L);
        p.setRutCliente(RUT);
        p.setEstado(EstadoPedido.ENTREGADO);
        ItemPedido item = new ItemPedido();
        item.setSku("GTR-0001");
        item.setNombreProducto("Strato");
        item.setCantidad(2);
        item.setPrecioUnitario(50000);
        item.setPedido(p);
        p.getItems().add(item);
        HistorialEstadoPedido h = new HistorialEstadoPedido();
        h.setEstadoNuevo(EstadoPedido.ENTREGADO);
        h.setFecha(LocalDateTime.now().minusDays(diasAtras));
        p.getHistorial().add(h);
        return p;
    }

    private DevolucionDTO solicitud(String sku, Integer cantidad) {
        return new DevolucionDTO(50L, List.of(new ItemDTO(sku, cantidad)), MotivoDevolucion.PRODUCTO_DANADO,
                "  Llegó roto ", "  ");
    }

    private void clienteYPedido(Pedido pedido) {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        when(pedidoService.buscarDelCliente(50L, RUT)).thenReturn(pedido);
    }

    private SolicitudDevolucion guardada(EstadoDevolucion estado) {
        SolicitudDevolucion s = new SolicitudDevolucion();
        s.setNumeroSeguimiento(7L);
        s.setRutCliente(RUT);
        s.setEstado(estado);
        Pedido p = new Pedido();
        p.setNumeroPedido(50L);
        s.setPedido(p);
        ItemDevolucion item = new ItemDevolucion();
        item.setSku("GTR-0001");
        item.setCantidad(2);
        item.setPrecioUnitario(50000);
        item.setSolicitud(s);
        s.getItems().add(item);
        return s;
    }

    @Test
    void requestOk() {
        clienteYPedido(pedidoEntregado(3));
        when(devolucionRepository.findByPedidoNumeroPedidoAndEstadoNot(50L, EstadoDevolucion.RECHAZADA)).thenReturn(List.of());
        when(devolucionRepository.save(any(SolicitudDevolucion.class))).thenAnswer(i -> i.getArgument(0));

        SolicitudDevolucion s = service.solicitar(RUT, solicitud(" gtr-0001 ", 1));

        assertEquals(EstadoDevolucion.PENDIENTE, s.getEstado());
        assertEquals(1, s.getItems().size());
        assertEquals("GTR-0001", s.getItems().get(0).getSku());
        assertEquals("Llegó roto", s.getDescripcion());
        assertNull(s.getEvidenciaUrl());
        assertEquals(50000, s.calcularMontoReembolso());
        assertEquals(50L, s.getNumeroPedido());
    }

    @Test
    void requestMissingData() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        DevolucionDTO sinPedido = solicitud("GTR-0001", 1);
        sinPedido.setNumeroPedido(null);
        DevolucionDTO sinMotivo = solicitud("GTR-0001", 1);
        sinMotivo.setMotivo(null);

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, sinPedido))));
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, sinMotivo))));
    }

    @Test
    void invalidItems() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        DevolucionDTO sinItems = solicitud("GTR-0001", 1);
        sinItems.setItems(List.of());
        DevolucionDTO nulos = solicitud("GTR-0001", 1);
        nulos.setItems(null);

        assertThrows(ResponseStatusException.class, () -> service.solicitar(RUT, sinItems));
        assertThrows(ResponseStatusException.class, () -> service.solicitar(RUT, nulos));
        assertThrows(ResponseStatusException.class, () -> service.solicitar(RUT, solicitud(" ", 1)));
        assertThrows(ResponseStatusException.class, () -> service.solicitar(RUT, solicitud("GTR-0001", 0)));
        assertThrows(ResponseStatusException.class, () -> service.solicitar(RUT, solicitud("GTR-0001", null)));
    }

    @Test
    void deliveredOnly() {
        Pedido p = pedidoEntregado(1);
        p.setEstado(EstadoPedido.ENVIADO);
        clienteYPedido(p);

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("GTR-0001", 1)))));
    }

    @Test
    void deadlineExpired() {
        clienteYPedido(pedidoEntregado(11));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("GTR-0001", 1)));

        assertEquals(HttpStatus.BAD_REQUEST, estado(e));
        assertTrue(e.getReason().contains("venció"));
    }

    @Test
    void noDeliveryDate() {
        Pedido p = pedidoEntregado(1);
        p.getHistorial().clear();
        clienteYPedido(p);

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("GTR-0001", 1)))));
    }

    @Test
    void productNotInOrder() {
        clienteYPedido(pedidoEntregado(1));
        when(devolucionRepository.findByPedidoNumeroPedidoAndEstadoNot(50L, EstadoDevolucion.RECHAZADA)).thenReturn(List.of());

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("OTRO-0001", 1)))));
    }

    @Test
    void tooManyUnits() {
        clienteYPedido(pedidoEntregado(1));
        when(devolucionRepository.findByPedidoNumeroPedidoAndEstadoNot(50L, EstadoDevolucion.RECHAZADA)).thenReturn(List.of());

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("GTR-0001", 3)))));
        verify(devolucionRepository, never()).save(any());
    }

    @Test
    void countsPreviousRequests() {
        clienteYPedido(pedidoEntregado(1));
        SolicitudDevolucion previa = guardada(EstadoDevolucion.PENDIENTE);
        previa.getItems().get(0).setCantidad(1);
        when(devolucionRepository.findByPedidoNumeroPedidoAndEstadoNot(50L, EstadoDevolucion.RECHAZADA))
                .thenReturn(List.of(previa));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("GTR-0001", 2)));

        assertTrue(e.getReason().contains("máximo 1"));
    }

    @Test
    void noUnitsLeft() {
        clienteYPedido(pedidoEntregado(1));
        when(devolucionRepository.findByPedidoNumeroPedidoAndEstadoNot(50L, EstadoDevolucion.RECHAZADA))
                .thenReturn(List.of(guardada(EstadoDevolucion.APROBADA)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> service.solicitar(RUT, solicitud("GTR-0001", 1)));

        assertTrue(e.getReason().contains("todas las unidades"));
    }

    @Test
    void repeatedSkuSummed() {
        clienteYPedido(pedidoEntregado(1));
        when(devolucionRepository.findByPedidoNumeroPedidoAndEstadoNot(50L, EstadoDevolucion.RECHAZADA)).thenReturn(List.of());
        DevolucionDTO d = solicitud("GTR-0001", 1);
        d.setItems(List.of(new ItemDTO("GTR-0001", 1), new ItemDTO("gtr-0001", 1)));
        when(devolucionRepository.save(any(SolicitudDevolucion.class))).thenAnswer(i -> i.getArgument(0));

        SolicitudDevolucion s = service.solicitar(RUT, d);

        assertEquals(1, s.getItems().size());
        assertEquals(2, s.getItems().get(0).getCantidad());
    }

    @Test
    void listByClient() {
        when(usuariosClient.obtenerCliente(RUT)).thenReturn(cliente());
        when(devolucionRepository.findByRutClienteOrderByFechaSolicitudDesc(RUT))
                .thenReturn(List.of(guardada(EstadoDevolucion.PENDIENTE)));

        assertEquals(1, service.listarPorCliente(RUT).size());
    }

    @Test
    void adminListFilters() {
        when(devolucionRepository.findAllByOrderByFechaSolicitudDesc())
                .thenReturn(List.of(guardada(EstadoDevolucion.PENDIENTE), guardada(EstadoDevolucion.APROBADA)));

        assertEquals(2, service.listar(ADMIN, null).size());
        assertEquals(1, service.listar(ADMIN, EstadoDevolucion.APROBADA).size());
    }

    @Test
    void detailAndCountPending() {
        SolicitudDevolucion s = guardada(EstadoDevolucion.PENDIENTE);
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(s));
        when(devolucionRepository.countByEstado(EstadoDevolucion.PENDIENTE)).thenReturn(3L);

        assertEquals(s, service.detalle(7L, ADMIN));
        assertEquals(3L, service.contarPendientes());
    }

    @Test
    void detailNotFound() {
        when(devolucionRepository.findById(9L)).thenReturn(Optional.empty());

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> service.detalle(9L, ADMIN))));
    }

    @Test
    void approve() {
        SolicitudDevolucion s = guardada(EstadoDevolucion.PENDIENTE);
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(s));
        when(devolucionRepository.save(s)).thenReturn(s);

        SolicitudDevolucion r = service.aprobar(7L, " " + ADMIN + " ");

        assertEquals(EstadoDevolucion.APROBADA, r.getEstado());
        assertEquals(ADMIN, r.getRutAdministrador());
        assertNotNull(r.getFechaResolucion());
        verify(productosClient).reponerStock("GTR-0001", 2, 50L, "DEVOLUCION", ADMIN);
        verify(usuariosClient).enviarNotificacion(eq(RUT), contains("$100.000"), eq("devolucion:7"));
        verify(usuariosClient).registrarAccion(any(RegistroAccionDTO.class));
    }

    @Test
    void resolvePendingOnly() {
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(guardada(EstadoDevolucion.APROBADA)));

        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.aprobar(7L, ADMIN))));
        verify(productosClient, never()).reponerStock(anyString(), anyInt(), anyLong(), anyString(), anyString());
    }

    @Test
    void reject() {
        SolicitudDevolucion s = guardada(EstadoDevolucion.PENDIENTE);
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(s));
        when(devolucionRepository.save(s)).thenReturn(s);

        SolicitudDevolucion r = service.rechazar(7L, "  Uso indebido ", ADMIN);

        assertEquals(EstadoDevolucion.RECHAZADA, r.getEstado());
        assertEquals("Uso indebido", r.getMotivoRechazo());
        verify(usuariosClient).enviarNotificacion(eq(RUT), anyString(), eq("devolucion:7"));
    }

    @Test
    void rejectNoReason() {
        assertEquals(HttpStatus.BAD_REQUEST, estado(assertThrows(ResponseStatusException.class,
                () -> service.rechazar(7L, " ", ADMIN))));
        assertThrows(ResponseStatusException.class, () -> service.rechazar(7L, null, ADMIN));
    }

    @Test
    void refund() {
        SolicitudDevolucion s = guardada(EstadoDevolucion.APROBADA);
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(s));
        when(devolucionRepository.save(s)).thenReturn(s);

        SolicitudDevolucion r = service.reembolsar(7L, ADMIN);

        assertEquals(EstadoDevolucion.REEMBOLSADA, r.getEstado());
        assertEquals(100000, r.getMontoReembolsado());
        assertEquals(ADMIN, r.getRutAdministradorReembolso());
        verify(usuariosClient).registrarAccion(any(RegistroAccionDTO.class));
    }

    @Test
    void refundTwice() {
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(guardada(EstadoDevolucion.REEMBOLSADA)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> service.reembolsar(7L, ADMIN));

        assertTrue(e.getReason().contains("ya fue reembolsada"));
    }

    @Test
    void refundPending() {
        when(devolucionRepository.findById(7L)).thenReturn(Optional.of(guardada(EstadoDevolucion.PENDIENTE)));

        ResponseStatusException e = assertThrows(ResponseStatusException.class, () -> service.reembolsar(7L, ADMIN));

        assertEquals(HttpStatus.BAD_REQUEST, estado(e));
        assertTrue(e.getReason().contains("aprobada"));
    }
}
