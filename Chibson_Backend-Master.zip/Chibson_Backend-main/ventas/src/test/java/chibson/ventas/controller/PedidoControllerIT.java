package chibson.ventas.controller;

import chibson.ventas.LimpiezaBaseDatos;
import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.ProductoDTO;
import chibson.ventas.dto.UsuarioDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class PedidoControllerIT {
    private static final MediaType JSON = MediaType.APPLICATION_JSON;

    @Autowired
    private MockMvc mockMvc;

    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final String COMPRA = "{\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":2}],\"metodoPago\":\"DEBITO\"}";

    @Autowired
    private LimpiezaBaseDatos limpiezaBaseDatos;
    @MockitoBean
    private UsuariosClient usuariosClient;
    @MockitoBean
    private ProductosClient productosClient;

    @BeforeEach
    void prepararBase() {
        limpiezaBaseDatos.limpiar();
        UsuarioDTO ana = new UsuarioDTO(CLIENTE, "Ana", "Pérez", "Metropolitana", "Santiago", "Condominio Sur", "10", "ACTIVO");
        when(usuariosClient.obtenerCliente(CLIENTE)).thenReturn(ana);
        when(usuariosClient.buscarUsuario(any())).thenReturn(ana);
        when(productosClient.obtenerProducto("GTR-0001"))
                .thenReturn(new ProductoDTO("GTR-0001", "Stratocaster", 10000, "GUITARRA", 50));
    }

    private Long comprar() throws Exception {
        String json = mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(COMPRA))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return Long.valueOf(json.replaceAll(".*?\"numeroPedido\":(\\d+).*", "$1"));
    }

    private void cambiarEstado(Long numero, String estado) throws Exception {
        mockMvc.perform(patch("/api/pedidos/" + numero + "/estado").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"estado\":\"" + estado + "\"}"))
                .andExpect(status().isOk());
    }

    private Long entregar() throws Exception {
        Long numero = comprar();
        cambiarEstado(numero, "EN_PROCESO");
        cambiarEstado(numero, "ENVIADO");
        cambiarEstado(numero, "ENTREGADO");
        return numero;
    }

    @Test
    void checkoutApproved() throws Exception {
        mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(COMPRA))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.aprobado").value(true))
                .andExpect(jsonPath("$.pedido.estado").value("PAGADO"))
                .andExpect(jsonPath("$.pedido.items.length()").value(1));
    }

    @Test
    void checkoutRejectedThenRetry() throws Exception {
        String json = mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(COMPRA.replace("}", ",\"simularRechazo\":true}")))
                .andExpect(status().isPaymentRequired())
                .andExpect(jsonPath("$.aprobado").value(false))
                .andExpect(jsonPath("$.pedido.estado").value("PENDIENTE"))
                .andReturn().getResponse().getContentAsString();
        Long numero = Long.valueOf(json.replaceAll(".*?\"numeroPedido\":(\\d+).*", "$1"));

        mockMvc.perform(post("/api/pedidos/" + numero + "/pagar").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"metodoPago\":\"CREDITO\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.pedido.estado").value("PAGADO"));
        mockMvc.perform(post("/api/pedidos/" + numero + "/pagar").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"metodoPago\":\"CREDITO\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void checkoutWithoutPaymentMethod400() throws Exception {
        mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":1}]}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void checkoutInsufficientStock() throws Exception {
        when(productosClient.obtenerProducto("GTR-0001"))
                .thenReturn(new ProductoDTO("GTR-0001", "Stratocaster", 10000, "GUITARRA", 1));

        mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON).content(COMPRA))
                .andExpect(status().is4xxClientError());
    }

    @Test
    void myOrdersAndDetail() throws Exception {
        Long numero = comprar();

        mockMvc.perform(get("/api/pedidos/mis-pedidos").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.pedidos.length()").value(1));
        mockMvc.perform(get("/api/pedidos/mis-pedidos/" + numero).header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.numeroPedido").value(numero))
                .andExpect(jsonPath("$.historial.length()").value(2));
        mockMvc.perform(get("/api/pedidos/mis-pedidos/999999").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isNotFound());
    }

    @Test
    void adminListAndDetail() throws Exception {
        Long numero = comprar();

        mockMvc.perform(get("/api/pedidos").header("X-Rut-Usuario", ADMIN))
                .andExpect(jsonPath("$._embedded.pedidos.length()").value(1));
        mockMvc.perform(get("/api/pedidos").header("X-Rut-Usuario", ADMIN).param("estado", "ENTREGADO"))
                .andExpect(jsonPath("$._embedded").doesNotExist());
        mockMvc.perform(get("/api/pedidos/" + numero).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreCliente").value("Ana Pérez"));
    }

    @Test
    void adminForbidden() throws Exception {
        doThrow(new ResponseStatusException(HttpStatus.FORBIDDEN, "Sin permiso"))
                .when(usuariosClient).exigirPermiso(any(), eq("GESTIONAR_PEDIDOS"));

        mockMvc.perform(get("/api/pedidos").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isForbidden());
    }

    @Test
    void statusFlow() throws Exception {
        Long numero = comprar();

        mockMvc.perform(patch("/api/pedidos/" + numero + "/estado").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"estado\":\"ENVIADO\"}"))
                .andExpect(status().isBadRequest());
        cambiarEstado(numero, "EN_PROCESO");
        cambiarEstado(numero, "ENVIADO");
        cambiarEstado(numero, "ENTREGADO");
        mockMvc.perform(get("/api/pedidos/" + numero).header("X-Rut-Usuario", ADMIN))
                .andExpect(jsonPath("$.estado").value("ENTREGADO"));
    }

    @Test
    void statusCancelViaStatusEndpoint400() throws Exception {
        Long numero = comprar();

        mockMvc.perform(patch("/api/pedidos/" + numero + "/estado").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"estado\":\"CANCELADO\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void cancelOrder() throws Exception {
        Long numero = comprar();

        mockMvc.perform(patch("/api/pedidos/" + numero + "/cancelar").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"motivo\":\"Cliente se arrepintió\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("CANCELADO"))
                .andExpect(jsonPath("$.motivoCancelacion").value("Cliente se arrepintió"));
        mockMvc.perform(patch("/api/pedidos/" + numero + "/cancelar").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"motivo\":\"otra vez\"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void cancelWithoutReason400() throws Exception {
        Long numero = comprar();

        mockMvc.perform(patch("/api/pedidos/" + numero + "/cancelar").header("X-Rut-Usuario", ADMIN).contentType(JSON)
                        .content("{\"motivo\":\" \"}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void deletePaidOrder409() throws Exception {
        Long numero = comprar();

        mockMvc.perform(delete("/api/pedidos/" + numero).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isConflict());
    }

    @Test
    void deleteUnpaidOrder() throws Exception {
        String json = mockMvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content(COMPRA.replace("}", ",\"simularRechazo\":true}")))
                .andReturn().getResponse().getContentAsString();
        Long numero = Long.valueOf(json.replaceAll(".*?\"numeroPedido\":(\\d+).*", "$1"));

        mockMvc.perform(delete("/api/pedidos/" + numero).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNoContent());
        mockMvc.perform(get("/api/pedidos/" + numero).header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }

    @Test
    void queriesForOtherServices() throws Exception {
        mockMvc.perform(get("/api/pedidos/cliente/" + CLIENTE + "/existe"))
                .andExpect(content().string("false"));
        mockMvc.perform(get("/api/pedidos/producto/GTR-0001/existe"))
                .andExpect(content().string("false"));
        Long numero = entregar();
        mockMvc.perform(get("/api/pedidos/cliente/" + CLIENTE + "/existe"))
                .andExpect(content().string("true"));
        mockMvc.perform(get("/api/pedidos/producto/GTR-0001/existe"))
                .andExpect(content().string("true"));
        mockMvc.perform(get("/api/pedidos/cliente/" + CLIENTE + "/recibio/GTR-0001"))
                .andExpect(content().string("true"));
        mockMvc.perform(get("/api/pedidos/cliente/" + CLIENTE + "/recibio/BAJ-0001"))
                .andExpect(content().string("false"));
        mockMvc.perform(get("/api/pedidos/resumen"))
                .andExpect(status().isOk());
        org.junit.jupiter.api.Assertions.assertNotNull(numero);
    }
}
