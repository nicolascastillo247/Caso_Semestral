package chibson.ventas.controller;

import chibson.ventas.dto.CheckoutDTO;
import chibson.ventas.dto.CompraRespuestaDTO;
import chibson.ventas.dto.PedidoDTO;
import chibson.ventas.dto.PedidoResumenDTO;
import chibson.ventas.model.EstadoPedido;
import chibson.ventas.model.MetodoPago;
import chibson.ventas.service.PedidoService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(PedidoController.class)
@ActiveProfiles("test")
class PedidoControllerTest {
    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private PedidoService pedidoService;

    @Autowired
    private MockMvc mvc;

    private PedidoDTO pedidoDto(Long numero) {
        PedidoDTO p = new PedidoDTO();
        p.setNumeroPedido(numero);
        p.setEstado(EstadoPedido.PAGADO);
        p.setItems(new ArrayList<>());
        p.setHistorial(new ArrayList<>());
        p.setPagos(new ArrayList<>());
        return p;
    }

    @Test
    void checkout201() throws Exception {
        when(pedidoService.comprar(eq(CLIENTE), any(CheckoutDTO.class)))
                .thenReturn(new CompraRespuestaDTO(true, "Compra exitosa", pedidoDto(1L)));

        mvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE)
                        .contentType(JSON).content("{\"metodoPago\":\"DEBITO\",\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":1}]}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.aprobado").value(true))
                .andExpect(jsonPath("$.pedido.numeroPedido").value(1));
    }

    @Test
    void checkoutRejected402() throws Exception {
        when(pedidoService.comprar(eq(CLIENTE), any(CheckoutDTO.class)))
                .thenReturn(new CompraRespuestaDTO(false, "Pago rechazado", pedidoDto(2L)));

        mvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE)
                        .contentType(JSON).content("{}"))
                .andExpect(status().isPaymentRequired())
                .andExpect(jsonPath("$.aprobado").value(false));
    }

    @Test
    void checkoutNoStock409() throws Exception {
        when(pedidoService.comprar(eq(CLIENTE), any(CheckoutDTO.class)))
                .thenThrow(new ResponseStatusException(HttpStatus.CONFLICT, "Sin stock"));

        mvc.perform(post("/api/pedidos/checkout").header("X-Rut-Usuario", CLIENTE)
                        .contentType(JSON).content("{}"))
                .andExpect(status().isConflict());
    }

    @Test
    void retryPayment() throws Exception {
        when(pedidoService.reintentarPago(5L, CLIENTE, MetodoPago.CREDITO, true))
                .thenReturn(new CompraRespuestaDTO(false, "Rechazado", pedidoDto(5L)));
        when(pedidoService.reintentarPago(6L, CLIENTE, MetodoPago.CREDITO, false))
                .thenReturn(new CompraRespuestaDTO(true, "Ok", pedidoDto(6L)));

        mvc.perform(post("/api/pedidos/5/pagar").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"metodoPago\":\"CREDITO\",\"simularRechazo\":true}"))
                .andExpect(status().isPaymentRequired());
        mvc.perform(post("/api/pedidos/6/pagar").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"metodoPago\":\"CREDITO\"}"))
                .andExpect(status().isCreated());
    }

    @Test
    void myOrders() throws Exception {
        when(pedidoService.listarPorCliente(CLIENTE)).thenReturn(List.of(pedidoDto(1L)));
        when(pedidoService.detalleCliente(1L, CLIENTE)).thenReturn(pedidoDto(1L));

        mvc.perform(get("/api/pedidos/mis-pedidos").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.pedidos[0].numeroPedido").value(1));
        mvc.perform(get("/api/pedidos/mis-pedidos/1").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("PAGADO"));
    }

    @Test
    void adminListDetail() throws Exception {
        when(pedidoService.listar(ADMIN, EstadoPedido.PAGADO)).thenReturn(List.of(pedidoDto(3L)));
        when(pedidoService.detalleAdmin(3L, ADMIN)).thenReturn(pedidoDto(3L));

        mvc.perform(get("/api/pedidos").header("X-Rut-Usuario", ADMIN).param("estado", "PAGADO"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.pedidos[0].numeroPedido").value(3));
        mvc.perform(get("/api/pedidos/3").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk());
    }

    @Test
    void updateStatusCancel() throws Exception {
        when(pedidoService.actualizarEstado(3L, EstadoPedido.EN_PROCESO, ADMIN)).thenReturn(pedidoDto(3L));
        when(pedidoService.cancelar(3L, "Sin stock", ADMIN)).thenReturn(pedidoDto(3L));

        mvc.perform(patch("/api/pedidos/3/estado").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"estado\":\"EN_PROCESO\"}"))
                .andExpect(status().isOk());
        mvc.perform(patch("/api/pedidos/3/cancelar").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"motivo\":\"Sin stock\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void delete204() throws Exception {
        mvc.perform(delete("/api/pedidos/3").header("X-Rut-Usuario", ADMIN)).andExpect(status().isNoContent());

        verify(pedidoService).eliminar(3L, ADMIN);
    }

    @Test
    void crossServiceChecks() throws Exception {
        when(pedidoService.clienteTienePedidos(CLIENTE)).thenReturn(true);
        when(pedidoService.productoTienePedidos("GTR-0001")).thenReturn(false);
        when(pedidoService.clienteRecibioProducto(CLIENTE, "GTR-0001")).thenReturn(true);

        mvc.perform(get("/api/pedidos/cliente/11111111-1/existe")).andExpect(content().string("true"));
        mvc.perform(get("/api/pedidos/producto/GTR-0001/existe")).andExpect(content().string("false"));
        mvc.perform(get("/api/pedidos/cliente/11111111-1/recibio/GTR-0001")).andExpect(content().string("true"));
    }

    @Test
    void summary() throws Exception {
        PedidoResumenDTO r = new PedidoResumenDTO(1L, null, EstadoPedido.PAGADO, 1000, "Metropolitana", true,
                new ArrayList<>(), new ArrayList<>());
        when(pedidoService.resumen(LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31))).thenReturn(List.of(r));

        mvc.perform(get("/api/pedidos/resumen").param("desde", "2026-01-01").param("hasta", "2026-01-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].region").value("Metropolitana"))
                .andExpect(jsonPath("$[0].pagado").value(true));
    }
}
