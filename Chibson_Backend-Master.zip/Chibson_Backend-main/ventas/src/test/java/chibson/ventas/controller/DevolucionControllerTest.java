package chibson.ventas.controller;

import chibson.ventas.dto.DevolucionDTO;
import chibson.ventas.model.EstadoDevolucion;
import chibson.ventas.model.SolicitudDevolucion;
import chibson.ventas.service.DevolucionService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(DevolucionController.class)
@ActiveProfiles("test")
class DevolucionControllerTest {
    private static final String CLIENTE = "11111111-1";
    private static final String ADMIN = "12345678-5";
    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @MockitoBean
    private DevolucionService devolucionService;

    @Autowired
    private MockMvc mvc;

    private SolicitudDevolucion solicitud(Long id) {
        SolicitudDevolucion s = new SolicitudDevolucion();
        s.setNumeroSeguimiento(id);
        s.setEstado(EstadoDevolucion.PENDIENTE);
        return s;
    }

    @Test
    void requestReturn201() throws Exception {
        when(devolucionService.solicitar(eq(CLIENTE), any(DevolucionDTO.class))).thenReturn(solicitud(1L));

        mvc.perform(post("/api/devoluciones").header("X-Rut-Usuario", CLIENTE).contentType(JSON)
                        .content("{\"numeroPedido\":1,\"motivo\":\"PRODUCTO_DANADO\",\"items\":[{\"sku\":\"GTR-0001\",\"cantidad\":1}]}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.numeroSeguimiento").value(1));
    }

    @Test
    void myReturnsAdminList() throws Exception {
        when(devolucionService.listarPorCliente(CLIENTE)).thenReturn(List.of(solicitud(1L)));
        when(devolucionService.listar(ADMIN, EstadoDevolucion.PENDIENTE)).thenReturn(List.of(solicitud(2L)));

        mvc.perform(get("/api/devoluciones/mis-devoluciones").header("X-Rut-Usuario", CLIENTE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.devoluciones[0].numeroSeguimiento").value(1));
        mvc.perform(get("/api/devoluciones").header("X-Rut-Usuario", ADMIN).param("estado", "PENDIENTE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.devoluciones[0].numeroSeguimiento").value(2));
    }

    @Test
    void countPendingDetail() throws Exception {
        when(devolucionService.contarPendientes()).thenReturn(4L);
        when(devolucionService.detalle(1L, ADMIN)).thenReturn(solicitud(1L));

        mvc.perform(get("/api/devoluciones/pendientes/contar")).andExpect(content().string("4"));
        mvc.perform(get("/api/devoluciones/1").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk());
    }

    @Test
    void approveRejectRefund() throws Exception {
        when(devolucionService.aprobar(1L, ADMIN)).thenReturn(solicitud(1L));
        when(devolucionService.rechazar(2L, "Fuera de plazo", ADMIN)).thenReturn(solicitud(2L));
        when(devolucionService.reembolsar(1L, ADMIN)).thenReturn(solicitud(1L));

        mvc.perform(patch("/api/devoluciones/1/aprobar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk());
        mvc.perform(patch("/api/devoluciones/2/rechazar").header("X-Rut-Usuario", ADMIN)
                        .contentType(JSON).content("{\"motivo\":\"Fuera de plazo\"}"))
                .andExpect(status().isOk());
        mvc.perform(patch("/api/devoluciones/1/reembolsar").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isOk());
    }

    @Test
    void returnNotFound() throws Exception {
        when(devolucionService.detalle(9L, ADMIN))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "No existe"));

        mvc.perform(get("/api/devoluciones/9").header("X-Rut-Usuario", ADMIN))
                .andExpect(status().isNotFound());
    }
}
