package chibson.ventas.client;

import chibson.ventas.client.ProductosClient;
import chibson.ventas.client.UsuariosClient;
import chibson.ventas.dto.ProductoDTO;
import chibson.ventas.dto.RegistroAccionDTO;
import chibson.ventas.dto.StockDTO;
import chibson.ventas.dto.UsuarioDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VentasClientsTest {
    @Mock
    private RestTemplate restTemplate;

    private ProductosClient productos;
    private UsuariosClient usuarios;

    @BeforeEach
    void setUp() {
        productos = new ProductosClient(restTemplate, "http://localhost:8082");
        usuarios = new UsuariosClient(restTemplate, "http://localhost:8081");
    }

    private HttpStatus estado(ResponseStatusException e) {
        return HttpStatus.valueOf(e.getStatusCode().value());
    }

    private HttpClientErrorException error(HttpStatus status, String cuerpo) {
        return HttpClientErrorException.create(status, status.name(), null,
                cuerpo.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
    }

    @Test
    void getProduct() {
        ProductoDTO p = new ProductoDTO("GTR-0001", "Strato", 100, "GUITARRA", 5);
        when(restTemplate.getForObject(anyString(), eq(ProductoDTO.class), eq("GTR-0001"))).thenReturn(p);

        assertSame(p, productos.obtenerProducto("GTR-0001"));
    }

    @Test
    void productNotFound404() {
        when(restTemplate.getForObject(anyString(), eq(ProductoDTO.class), eq("X")))
                .thenThrow(HttpClientErrorException.create(HttpStatus.NOT_FOUND, "nf", null, null, null));

        assertEquals(HttpStatus.NOT_FOUND, estado(assertThrows(ResponseStatusException.class,
                () -> productos.obtenerProducto("X"))));
    }

    @Test
    void productsDown503() {
        when(restTemplate.getForObject(anyString(), eq(ProductoDTO.class), eq("X")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> productos.obtenerProducto("X"))));
    }

    @Test
    void discountRestock() {
        StockDTO s = new StockDTO("GTR-0001", 3, 1, false);
        when(restTemplate.postForObject(anyString(), any(), eq(StockDTO.class), eq("GTR-0001"))).thenReturn(s);

        assertSame(s, productos.descontarStock("GTR-0001", 2, 10L, RUT));
        assertSame(s, productos.reponerStock("GTR-0001", 2, 10L, "DEVOLUCION", RUT));
    }

    private static final String RUT = "11111111-1";

    @Test
    void movementRejected() {
        when(restTemplate.postForObject(anyString(), any(), eq(StockDTO.class), eq("GTR-0001")))
                .thenThrow(error(HttpStatus.CONFLICT, "{\"status\":409,\"message\":\"Stock insuficiente\"}"));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> productos.descontarStock("GTR-0001", 99, 10L, RUT));

        assertEquals(HttpStatus.CONFLICT, estado(e));
        assertEquals("Stock insuficiente", e.getReason());
    }

    @Test
    void movementRejectedGeneric() {
        when(restTemplate.postForObject(anyString(), any(), eq(StockDTO.class), eq("GTR-0001")))
                .thenThrow(error(HttpStatus.BAD_REQUEST, "no es json"));

        ResponseStatusException e = assertThrows(ResponseStatusException.class,
                () -> productos.descontarStock("GTR-0001", 1, 10L, RUT));

        assertEquals("ms-productos rechazó la operación", e.getReason());
    }

    @Test
    void movementDown503() {
        when(restTemplate.postForObject(anyString(), any(), eq(StockDTO.class), eq("GTR-0001")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> productos.reponerStock("GTR-0001", 1, 10L, "CANCELACION", RUT))));
    }

    @Test
    void permissionNoRut401() {
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(null, "X"))));
    }

    @Test
    void permissionCases() {
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("OK"))).thenReturn(true);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("NO"))).thenReturn(false);
        when(restTemplate.getForObject(anyString(), eq(Boolean.class), eq(RUT), eq("CAIDO")))
                .thenThrow(new ResourceAccessException("caído"));

        assertDoesNotThrow(() -> usuarios.exigirPermiso(" " + RUT + " ", "OK"));
        assertEquals(HttpStatus.FORBIDDEN, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(RUT, "NO"))));
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.exigirPermiso(RUT, "CAIDO"))));
    }

    @Test
    void getActiveClient() {
        UsuarioDTO u = new UsuarioDTO(RUT, "Ana", "Pérez", null, null, null, null, "ACTIVO");
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT))).thenReturn(u);

        assertSame(u, usuarios.obtenerCliente(" " + RUT + " "));
    }

    @Test
    void getClientInvalid401() {
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerCliente(" "))));

        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT)))
                .thenReturn(new UsuarioDTO(RUT, "Ana", "Pérez", null, null, null, null, "DESACTIVADO"));
        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerCliente(RUT))));
    }

    @Test
    void getClientNull401() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT))).thenReturn(null);

        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerCliente(RUT))));
    }

    @Test
    void getClientNotFoundOrDown() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq("1-9")))
                .thenThrow(error(HttpStatus.NOT_FOUND, "{}"));
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq("2-7")))
                .thenThrow(new ResourceAccessException("caído"));

        assertEquals(HttpStatus.UNAUTHORIZED, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerCliente("1-9"))));
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, estado(assertThrows(ResponseStatusException.class,
                () -> usuarios.obtenerCliente("2-7"))));
    }

    @Test
    void findUserNull() {
        when(restTemplate.getForObject(anyString(), eq(UsuarioDTO.class), eq(RUT)))
                .thenThrow(new ResourceAccessException("caído"));

        assertNull(usuarios.buscarUsuario(RUT));
    }

    @Test
    void notificationsNeverFail() {
        when(restTemplate.postForObject(anyString(), any(), eq(Void.class)))
                .thenThrow(new ResourceAccessException("caído"));

        assertDoesNotThrow(() -> usuarios.enviarNotificacion(RUT, "hola", "pedido:1"));
        assertDoesNotThrow(() -> usuarios.registrarAccion(new RegistroAccionDTO()));
    }

    @Test
    void notificationsSent() {
        assertDoesNotThrow(() -> usuarios.enviarNotificacion(RUT, "hola", "pedido:1"));
        assertDoesNotThrow(() -> usuarios.registrarAccion(new RegistroAccionDTO()));
    }
}
