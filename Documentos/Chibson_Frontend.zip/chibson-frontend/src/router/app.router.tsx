import { createBrowserRouter } from 'react-router'
import RutaCliente from '@/components/RutaCliente'
import TiendaLayout from '@/layouts/TiendaLayout'
import LoginPage from '@/pages/auth/LoginPage'
import RecuperarPasswordPage from '@/pages/auth/RecuperarPasswordPage'
import RegistroPage from '@/pages/auth/RegistroPage'
import CarritoPage from '@/pages/cliente/CarritoPage'
import CheckoutPage from '@/pages/cliente/CheckoutPage'
import ConfirmacionPedidoPage from '@/pages/cliente/ConfirmacionPedidoPage'
import DejarResenaPage from '@/pages/cliente/DejarResenaPage'
import MiPerfilPage from '@/pages/cliente/MiPerfilPage'
import MisDevolucionesPage from '@/pages/cliente/MisDevolucionesPage'
import MisPedidosPage from '@/pages/cliente/MisPedidosPage'
import MisTicketsPage from '@/pages/cliente/MisTicketsPage'
import NuevoTicketPage from '@/pages/cliente/NuevoTicketPage'
import PedidoDetallePage from '@/pages/cliente/PedidoDetallePage'
import SolicitarDevolucionPage from '@/pages/cliente/SolicitarDevolucionPage'
import TicketDetallePage from '@/pages/cliente/TicketDetallePage'
import AdminPendientePage from '@/pages/tienda/AdminPendientePage'
import CatalogoPage from '@/pages/tienda/CatalogoPage'
import InicioPage from '@/pages/tienda/InicioPage'
import NoEncontradoPage from '@/pages/tienda/NoEncontradoPage'
import NosotrosPage from '@/pages/tienda/NosotrosPage'
import NoticiaDetallePage from '@/pages/tienda/NoticiaDetallePage'
import NoticiasPage from '@/pages/tienda/NoticiasPage'
import ProductoDetallePage from '@/pages/tienda/ProductoDetallePage'

export const rootRouter = createBrowserRouter([
  {
    path: '/',
    element: <TiendaLayout />,
    children: [
      { index: true, element: <InicioPage /> },
      { path: 'catalogo', element: <CatalogoPage /> },
      { path: 'productos/:sku', element: <ProductoDetallePage /> },
      { path: 'noticias', element: <NoticiasPage /> },
      { path: 'noticias/:id', element: <NoticiaDetallePage /> },
      { path: 'nosotros', element: <NosotrosPage /> },
      { path: 'login', element: <LoginPage /> },
      { path: 'registro', element: <RegistroPage /> },
      { path: 'recuperar-password', element: <RecuperarPasswordPage /> },
      { path: 'admin', element: <AdminPendientePage /> },
      {
        element: <RutaCliente />,
        children: [
          { path: 'carrito', element: <CarritoPage /> },
          { path: 'checkout', element: <CheckoutPage /> },
          { path: 'pedido-confirmado/:numero', element: <ConfirmacionPedidoPage /> },
          { path: 'mis-pedidos', element: <MisPedidosPage /> },
          { path: 'mis-pedidos/:numero', element: <PedidoDetallePage /> },
          { path: 'mis-pedidos/:numero/devolucion', element: <SolicitarDevolucionPage /> },
          { path: 'devoluciones', element: <MisDevolucionesPage /> },
          { path: 'soporte', element: <MisTicketsPage /> },
          { path: 'soporte/nuevo', element: <NuevoTicketPage /> },
          { path: 'soporte/:numero', element: <TicketDetallePage /> },
          { path: 'perfil', element: <MiPerfilPage /> },
          { path: 'productos/:sku/resena', element: <DejarResenaPage /> },
        ],
      },
      { path: '*', element: <NoEncontradoPage /> },
    ],
  },
])

export default rootRouter
