export const CATEGORIAS_PRODUCTO: Record<string, string> = {
  GUITARRA: 'Guitarras',
  BAJO: 'Bajos',
  PERCUSION: 'Baterías y Percusión',
  TECLAS: 'Teclados y Pianos',
  VIENTO: 'Instrumentos de viento',
  CUERDAS: 'Cuerdas y Accesorios',
}

export const CATEGORIAS_NOTICIA: Record<string, string> = {
  PROMOCION: 'Promoción',
  EVENTO: 'Evento',
  ANUNCIO: 'Anuncio',
}

export const COLOR_CATEGORIA_NOTICIA: Record<string, string> = {
  PROMOCION: 'bg-danger',
  EVENTO: 'bg-info text-dark',
  ANUNCIO: 'bg-warning text-dark',
}

export const ESTADOS_PEDIDO: Record<string, { texto: string; color: string }> = {
  PENDIENTE: { texto: 'Pago pendiente', color: 'bg-secondary' },
  PAGADO: { texto: 'Confirmado', color: 'bg-primary' },
  EN_PROCESO: { texto: 'En preparación', color: 'bg-info text-dark' },
  ENVIADO: { texto: 'En camino', color: 'bg-warning text-dark' },
  ENTREGADO: { texto: 'Entregado', color: 'bg-success' },
  CANCELADO: { texto: 'Cancelado', color: 'bg-danger' },
}

export const METODOS_PAGO: Record<string, string> = {
  DEBITO: 'Tarjeta de débito',
  CREDITO: 'Tarjeta de crédito',
  TRANSFERENCIA: 'Transferencia bancaria',
}

export const MOTIVOS_DEVOLUCION: Record<string, string> = {
  PRODUCTO_DEFECTUOSO: 'Producto defectuoso',
  PRODUCTO_DANADO: 'Producto dañado',
  PRODUCTO_INCORRECTO: 'Producto incorrecto',
  OTRO: 'Otro',
}

export const ESTADOS_DEVOLUCION: Record<string, { texto: string; color: string }> = {
  PENDIENTE: { texto: 'En revisión', color: 'bg-warning text-dark' },
  APROBADA: { texto: 'Aprobada', color: 'bg-primary' },
  RECHAZADA: { texto: 'Rechazada', color: 'bg-danger' },
  REEMBOLSADA: { texto: 'Reembolsada', color: 'bg-success' },
}

export const CATEGORIAS_TICKET: Record<string, string> = {
  PEDIDO: 'Pedido',
  PAGO: 'Pago',
  DESPACHO: 'Despacho',
  GARANTIA: 'Garantía',
  OTRO: 'Otro',
}

export const ESTADOS_TICKET: Record<string, { texto: string; color: string }> = {
  ABIERTO: { texto: 'Abierto', color: 'bg-secondary' },
  EN_PROCESO: { texto: 'En proceso', color: 'bg-info text-dark' },
  RESUELTO: { texto: 'Resuelto', color: 'bg-success' },
  CERRADO: { texto: 'Cerrado', color: 'bg-dark' },
}
