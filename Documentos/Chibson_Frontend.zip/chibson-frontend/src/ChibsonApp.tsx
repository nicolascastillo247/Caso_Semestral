import { RouterProvider } from 'react-router'
import { AuthProvider } from '@/context/AuthContext'
import { CarritoProvider } from '@/context/CarritoContext'
import { rootRouter } from '@/router/app.router'

export const ChibsonApp = () => {
  return (
    <AuthProvider>
      <CarritoProvider>
        <RouterProvider router={rootRouter} />
      </CarritoProvider>
    </AuthProvider>
  )
}

export default ChibsonApp
