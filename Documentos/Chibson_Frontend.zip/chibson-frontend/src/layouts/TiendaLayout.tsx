import { useEffect } from 'react'
import { Link, Outlet, useLocation } from 'react-router'
import Footer from '@/components/Footer'
import Navbar from '@/components/Navbar'
import { useAuth } from '@/context/AuthContext'

export const TiendaLayout = () => {
  const { pathname } = useLocation()
  const { sesionExpirada, estaAutenticado } = useAuth()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])

  return (
    <div className="d-flex flex-column min-vh-100">
      <Navbar />
      {sesionExpirada && !estaAutenticado && (
        <div className="alert alert-warning rounded-0 mb-0 text-center" role="alert">
          Tu sesión expiró. <Link to="/login" className="text-link fw-semibold">Vuelve a iniciar sesión</Link>.
        </div>
      )}
      <main className="container my-5 flex-grow-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  )
}

export default TiendaLayout
