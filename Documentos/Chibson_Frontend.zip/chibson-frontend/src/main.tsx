import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-icons/font/bootstrap-icons.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import './styles/miestilo.css'
import { ChibsonApp } from './ChibsonApp'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ChibsonApp />
  </StrictMode>,
)
