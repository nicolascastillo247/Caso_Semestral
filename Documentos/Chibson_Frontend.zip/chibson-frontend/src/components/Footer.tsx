export const Footer = () => (
  <footer className="border-top py-4 text-center text-muted small bg-white mt-5">
    <p className="mb-0">&copy; {new Date().getFullYear()} Chibson Instruments. Todos los derechos reservados.</p>
  </footer>
)

export default Footer
