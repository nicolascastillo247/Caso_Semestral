import InstitucionalService from '@/services/institucional.service'
import useApi from '@/hooks/useApi'

export const CONTACTO_POR_DEFECTO = {
  correo: 'contacto@chibsoninstruments.com',
  telefono: '+56 9 1234 5678',
  direccion: 'Av. Principal 1234, Concepción, Chile',
}

export const ContactoSection = () => {
  const { datos } = useApi(() => InstitucionalService.obtener())

  return (
    <section className="contact-section p-4 rounded shadow-sm">
      <h2 className="h4 fw-bold mb-3">Información de Contacto</h2>
      <p>
        ¿Tienes dudas o buscas asesoría personalizada sobre un instrumento? Contáctanos a través de nuestros canales
        oficiales:
      </p>
      <ul className="list-unstyled mb-0 d-flex flex-column gap-2">
        <li>
          <strong>Correo electrónico:</strong> {datos?.correo || CONTACTO_POR_DEFECTO.correo}
        </li>
        <li>
          <strong>Teléfono / WhatsApp:</strong> {datos?.telefono || CONTACTO_POR_DEFECTO.telefono}
        </li>
        <li>
          <strong>Ubicación:</strong> {datos?.direccion || CONTACTO_POR_DEFECTO.direccion}
        </li>
        <li>
          <strong>Horario de atención:</strong> Lunes a Viernes de 10:00 a 19:00 hrs / Sábados de 10:00 a 14:00 hrs
        </li>
      </ul>
    </section>
  )
}

export default ContactoSection
