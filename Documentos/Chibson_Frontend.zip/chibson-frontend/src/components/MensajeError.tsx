interface MensajeErrorProps {
  mensaje: string | null
  alReintentar?: () => void
}

export const MensajeError = ({ mensaje, alReintentar }: MensajeErrorProps) => {
  if (!mensaje) return null
  return (
    <div className="alert alert-danger d-flex flex-wrap justify-content-between align-items-center gap-2" role="alert">
      <span>{mensaje}</span>
      {alReintentar && (
        <button type="button" className="btn btn-sm btn-outline-danger" onClick={alReintentar}>
          Reintentar
        </button>
      )}
    </div>
  )
}

export default MensajeError
