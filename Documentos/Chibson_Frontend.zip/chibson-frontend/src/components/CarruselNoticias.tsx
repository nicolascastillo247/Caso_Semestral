import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import type { Noticia } from '@/services/noticia.service'
import { CATEGORIAS_NOTICIA, COLOR_CATEGORIA_NOTICIA } from '@/utils/etiquetas'
import { imagenRespaldo, recortar, urlImagen } from '@/utils/formato'

export const CarruselNoticias = ({ noticias }: { noticias: Noticia[] }) => {
  const [activa, setActiva] = useState(0)
  const total = noticias.length

  useEffect(() => {
    if (total < 2) return
    const intervalo = window.setInterval(() => setActiva((actual) => (actual + 1) % total), 4500)
    return () => window.clearInterval(intervalo)
  }, [total])

  if (total === 0) return null

  const mover = (paso: number) => setActiva((actual) => (actual + paso + total) % total)

  return (
    <div id="topHeroNewsCarousel" className="carousel slide carousel-fade news-carousel-container">
      <div className="carousel-indicators mb-2">
        {noticias.map((noticia, indice) => (
          <button
            key={noticia.idNoticia}
            type="button"
            className={indice === activa ? 'active' : ''}
            aria-current={indice === activa}
            aria-label={`Noticia ${indice + 1}`}
            onClick={() => setActiva(indice)}
          ></button>
        ))}
      </div>

      <div className="carousel-inner">
        {noticias.map((noticia, indice) => (
          <div key={noticia.idNoticia} className={`carousel-item${indice === activa ? ' active' : ''}`}>
            <img
              src={urlImagen(noticia.imagenUrl)}
              onError={imagenRespaldo}
              className="d-block w-100 hero-carousel-img"
              alt={noticia.titulo}
            />
            <div className="carousel-caption text-start">
              <div className="d-flex align-items-center gap-2 mb-1">
                <span className={`badge fw-semibold ${COLOR_CATEGORIA_NOTICIA[noticia.categoria] ?? 'bg-secondary'}`}>
                  {CATEGORIAS_NOTICIA[noticia.categoria] ?? noticia.categoria}
                </span>
              </div>
              <h3 className="h6 fw-bold text-white mb-1">{noticia.titulo}</h3>
              <p className="small text-light mb-2">{recortar(noticia.contenido, 110)}</p>
              <Link to={`/noticias/${noticia.idNoticia}`} className="btn btn-sm btn-light fw-bold">
                Leer noticia →
              </Link>
            </div>
          </div>
        ))}
      </div>

      {total > 1 && (
        <>
          <button className="carousel-control-prev" type="button" onClick={() => mover(-1)}>
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Anterior</span>
          </button>
          <button className="carousel-control-next" type="button" onClick={() => mover(1)}>
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Siguiente</span>
          </button>
        </>
      )}
    </div>
  )
}

export default CarruselNoticias
