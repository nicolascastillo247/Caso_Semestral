import type { InputHTMLAttributes } from 'react'

interface CampoTextoProps extends InputHTMLAttributes<HTMLInputElement> {
  etiqueta: string
  ayuda?: string
}

export const CampoTexto = ({ etiqueta, ayuda, id, className, ...props }: CampoTextoProps) => (
  <div className={className ?? 'mb-3'}>
    <label htmlFor={id} className="form-label fw-semibold">
      {etiqueta}
    </label>
    <input id={id} className="form-control" {...props} />
    {ayuda && <div className="form-text">{ayuda}</div>}
  </div>
)

export default CampoTexto
