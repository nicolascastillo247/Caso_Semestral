import { Link } from 'react-router'
import type { Noticia } from '@/services/noticia.service'
import { CATEGORIAS_NOTICIA, COLOR_CATEGORIA_NOTICIA } from '@/utils/etiquetas'
import { formatearFechaLarga, imagenRespaldo, recortar, urlImagen } from '@/utils/formato'

export const NoticiaCard = ({ noticia }: { noticia: Noticia }) => {
  const detalle = `/noticias/${noticia.idNoticia}`
  return (
    <article className="card h-100 blog-card shadow-sm border-0 p-3">
      <Link to={detalle}>
        <img
          src={urlImagen(noticia.imagenUrl)}
          onError={imagenRespaldo}
          alt={noticia.titulo}
          className="news-img mb-3"
        />
      </Link>
      <div className="d-flex align-items-center gap-2 mb-2">
        <span className={`badge ${COLOR_CATEGORIA_NOTICIA[noticia.categoria] ?? 'bg-secondary'}`}>
          {CATEGORIAS_NOTICIA[noticia.categoria] ?? noticia.categoria}
        </span>
        <span className="news-date">{formatearFechaLarga(noticia.fechaPublicacion)}</span>
      </div>
      <h3 className="news-title fw-bold">
        <Link to={detalle}>{noticia.titulo}</Link>
      </h3>
      <p className="news-excerpt mb-0">{recortar(noticia.contenido, 220)}</p>
    </article>
  )
}

export default NoticiaCard
