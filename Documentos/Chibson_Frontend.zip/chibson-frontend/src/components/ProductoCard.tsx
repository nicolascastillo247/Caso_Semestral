import { Link } from 'react-router'
import type { Producto } from '@/services/producto.service'
import { formatearPrecio, imagenRespaldo, recortar, urlImagen } from '@/utils/formato'

interface ProductoCardProps {
  producto: Producto
  alComprar: (producto: Producto) => void
}

export const ProductoCard = ({ producto, alComprar }: ProductoCardProps) => {
  const detalle = `/productos/${encodeURIComponent(producto.sku)}`
  return (
    <article className="card h-100 product-card shadow-sm border-0 overflow-hidden">
      <Link to={detalle} className="text-decoration-none">
        <img
          src={urlImagen(producto.imagenUrl)}
          onError={imagenRespaldo}
          alt={producto.modelo}
          className="card-img-top p-3 bg-white"
          style={{ height: 240, objectFit: 'contain' }}
        />
      </Link>
      <div className="card-body d-flex flex-column p-4">
        <p className="small text-muted mb-1">{producto.marca}</p>
        <h3 className="h5 fw-bold mb-2">
          <Link to={detalle} className="text-link">
            {producto.modelo}
          </Link>
        </h3>
        <p className="price-tag my-2">{formatearPrecio(producto.precio)}</p>
        <p className="small text-muted mb-3">{recortar(producto.descripcion, 110)}</p>
        {producto.agotado ? (
          <span className="badge bg-secondary align-self-start mb-3">Agotado</span>
        ) : (
          producto.bajoStock && <span className="badge bg-warning text-dark align-self-start mb-3">Últimas unidades</span>
        )}
        <div className="mt-auto d-flex flex-column gap-2">
          <Link to={detalle} className="btn btn-outline-dark w-100">
            Ver detalles
          </Link>
          <button
            type="button"
            className="btn btn-custom w-100"
            disabled={producto.agotado}
            onClick={() => alComprar(producto)}
          >
            {producto.agotado ? 'Sin stock' : 'Agregar al carro'}
          </button>
        </div>
      </div>
    </article>
  )
}

export default ProductoCard
