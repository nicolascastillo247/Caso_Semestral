import { Link } from 'react-router'

interface ModalLoginRequeridoProps {
  visible: boolean
  redireccion: string
  alCerrar: () => void
}

export const ModalLoginRequerido = ({ visible, redireccion, alCerrar }: ModalLoginRequeridoProps) => {
  if (!visible) return null
  return (
    <>
      <div className="modal fade show d-block" tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="loginModalLabel">
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content border-0 shadow">
            <div className="modal-header border-bottom-0 pb-0">
              <h5 className="modal-title fw-bold" id="loginModalLabel">
                Iniciar sesión requerido
              </h5>
              <button type="button" className="btn-close" aria-label="Cerrar" onClick={alCerrar}></button>
            </div>
            <div className="modal-body py-4">
              <p className="mb-0">
                Para comprar este producto o agregarlo a tu carro, necesitas tener una cuenta activa e iniciar sesión.
              </p>
            </div>
            <div className="modal-footer border-top-0 pt-0 d-flex flex-column flex-sm-row gap-2">
              <Link
                to={`/login?redirect=${encodeURIComponent(redireccion)}`}
                className="btn btn-custom w-100 flex-grow-1"
              >
                Iniciar sesión
              </Link>
              <Link to="/registro" className="btn btn-outline-dark w-100 flex-grow-1">
                Registrarse
              </Link>
            </div>
          </div>
        </div>
      </div>
      <div className="modal-backdrop fade show" onClick={alCerrar}></div>
    </>
  )
}

export default ModalLoginRequerido
