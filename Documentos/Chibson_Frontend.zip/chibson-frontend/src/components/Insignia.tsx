interface InsigniaProps {
  valor: string
  estados: Record<string, { texto: string; color: string }>
}

export const Insignia = ({ valor, estados }: InsigniaProps) => {
  const estado = estados[valor] ?? { texto: valor, color: 'bg-secondary' }
  return <span className={`badge ${estado.color}`}>{estado.texto}</span>
}

export default Insignia
