export const Cargando = ({ texto = 'Cargando...' }: { texto?: string }) => (
  <div className="d-flex align-items-center justify-content-center gap-2 py-5 text-muted" role="status">
    <span className="spinner-border spinner-border-sm" aria-hidden="true"></span>
    <span>{texto}</span>
  </div>
)

export default Cargando
