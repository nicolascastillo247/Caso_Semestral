import { Link, NavLink, useNavigate } from 'react-router'
import { useAuth } from '@/context/AuthContext'
import { useCarrito } from '@/context/CarritoContext'

const claseEnlace = ({ isActive }: { isActive: boolean }) => `nav-link${isActive ? ' active' : ''}`

export const Navbar = () => {
  const { sesion, esCliente, cerrarSesion } = useAuth()
  const { cantidadTotal } = useCarrito()
  const navigate = useNavigate()

  const salir = () => {
    cerrarSesion()
    navigate('/')
  }

  return (
    <nav className="navbar navbar-expand-sm bg-dark navbar-dark chibson-navbar">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          <img src="/img/chibson-navbar.png" alt="Chibson Instruments" className="navbar-logo" />
        </Link>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#collapsibleNavbar"
          aria-controls="collapsibleNavbar"
          aria-expanded="false"
          aria-label="Mostrar navegación"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="collapsibleNavbar">
          <ul className="navbar-nav">
            <li className="nav-item">
              <NavLink className={claseEnlace} to="/" end>
                Inicio
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className={claseEnlace} to="/catalogo">
                Catálogo
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className={claseEnlace} to="/noticias">
                Noticias
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className={claseEnlace} to="/nosotros">
                Nosotros
              </NavLink>
            </li>
          </ul>

          <ul className="navbar-nav ms-auto align-items-sm-center">
            {esCliente && (
              <li className="nav-item">
                <NavLink className={claseEnlace} to="/carrito" aria-label="Carro de compras">
                  <span className="position-relative d-inline-block">
                    <i className="bi bi-cart3 fs-5"></i>
                    {cantidadTotal > 0 && (
                      <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark">
                        {cantidadTotal}
                      </span>
                    )}
                  </span>
                </NavLink>
              </li>
            )}

            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                aria-label="Cuenta"
                onClick={(evento) => evento.preventDefault()}
              >
                <i className="bi bi-person-circle fs-5"></i>
                {sesion && <span className="ms-2 small">{sesion.nombres}</span>}
              </a>

              <ul className="dropdown-menu dropdown-menu-end">
                {!sesion && (
                  <>
                    <li>
                      <Link className="dropdown-item" to="/login">
                        Iniciar sesión
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/registro">
                        Registrarse
                      </Link>
                    </li>
                  </>
                )}

                {sesion && esCliente && (
                  <>
                    <li>
                      <Link className="dropdown-item" to="/perfil">
                        Mi perfil
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/mis-pedidos">
                        Mis pedidos
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/devoluciones">
                        Devoluciones
                      </Link>
                    </li>
                    <li>
                      <Link className="dropdown-item" to="/soporte">
                        Soporte
                      </Link>
                    </li>
                  </>
                )}

                {sesion && !esCliente && (
                  <li>
                    <Link className="dropdown-item" to="/admin">
                      Panel de administración
                    </Link>
                  </li>
                )}

                {sesion && (
                  <>
                    <li>
                      <hr className="dropdown-divider" />
                    </li>
                    <li>
                      <button type="button" className="dropdown-item" onClick={salir}>
                        Cerrar sesión
                      </button>
                    </li>
                  </>
                )}
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
