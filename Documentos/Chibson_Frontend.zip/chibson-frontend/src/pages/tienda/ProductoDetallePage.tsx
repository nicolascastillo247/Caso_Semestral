import { useState } from 'react'
import { Link, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import ModalLoginRequerido from '@/components/ModalLoginRequerido'
import { useAuth } from '@/context/AuthContext'
import useApi from '@/hooks/useApi'
import useComprar from '@/hooks/useComprar'
import { useProducto } from '@/hooks/useProductos'
import ResenaService from '@/services/resena.service'
import { CATEGORIAS_PRODUCTO } from '@/utils/etiquetas'
import { estrellas, formatearFechaLarga, formatearPrecio, imagenRespaldo, urlImagen } from '@/utils/formato'

export const ProductoDetallePage = () => {
  const { sku = '' } = useParams()
  const { producto, cargando, error, recargar } = useProducto(sku)
  const { datos: opiniones } = useApi(() => ResenaService.listarAprobadas(sku), [sku])
  const { esCliente } = useAuth()
  const { comprar, modalVisible, redireccionLogin, cerrarModal } = useComprar()
  const [cantidad, setCantidad] = useState(1)

  if (cargando) return <Cargando texto="Cargando producto..." />
  if (error || !producto) {
    return (
      <>
        <MensajeError mensaje={error ?? 'El producto no existe.'} alReintentar={recargar} />
        <Link to="/catalogo" className="text-link">
          ← Volver al catálogo
        </Link>
      </>
    )
  }

  const resenas = opiniones?.resenas ?? []
  const promedio = opiniones?.promedio ?? 0
  const total = opiniones?.total ?? 0
  const categoria = CATEGORIAS_PRODUCTO[producto.categoria] ?? producto.categoria

  return (
    <>
      <nav aria-label="Ruta de navegación" className="mb-4">
        <ol className="breadcrumb">
          <li className="breadcrumb-item">
            <Link to="/catalogo" className="text-link">
              Catálogo
            </Link>
          </li>
          <li className="breadcrumb-item">
            <Link to={`/catalogo?categoria=${producto.categoria}`} className="text-link">
              {categoria}
            </Link>
          </li>
          <li className="breadcrumb-item active" aria-current="page">
            {producto.modelo}
          </li>
        </ol>
      </nav>

      <article className="row g-5 align-items-start mb-5">
        <div className="col-12 col-lg-6 text-center">
          <div className="card product-card p-4 shadow-sm border-0">
            <img
              src={urlImagen(producto.imagenUrl)}
              onError={imagenRespaldo}
              alt={producto.modelo}
              className="img-fluid mx-auto"
              style={{ maxHeight: 420, objectFit: 'contain' }}
            />
          </div>
        </div>

        <div className="col-12 col-lg-6">
          <p className="text-muted mb-1">{producto.marca}</p>
          <h2 className="display-6 fw-bold mb-3">{producto.modelo}</h2>

          <div className="d-flex flex-wrap align-items-center gap-3 mb-3 small">
            <span className="fw-bold">
              {total > 0 ? `${estrellas(promedio)} (${promedio.toFixed(1)} de 5)` : 'Sin valoraciones aún'}
            </span>
            <span className="text-muted">|</span>
            <a href="#seccion-resenas" className="text-link">
              Ver {total} {total === 1 ? 'valoración' : 'valoraciones'}
            </a>
            <span className="text-muted">|</span>
            <span className="text-muted">
              SKU: <strong className="text-dark">{producto.sku}</strong>
            </span>
          </div>

          <p className="price-tag fs-2 my-3">{formatearPrecio(producto.precio)}</p>
          {producto.agotado ? (
            <p className="badge bg-secondary-subtle text-secondary border px-3 py-2 fs-6 mb-4">Sin stock</p>
          ) : (
            <p className="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 fs-6 mb-4">
              En stock ({producto.stockDisponible} {producto.stockDisponible === 1 ? 'unidad disponible' : 'unidades disponibles'})
            </p>
          )}

          {producto.descripcion && <p className="mb-4">{producto.descripcion}</p>}

          {!producto.agotado && (
            <div className="d-flex gap-2 align-items-center mb-3">
              <label htmlFor="cantidad" className="form-label m-0">
                Cantidad
              </label>
              <input
                id="cantidad"
                type="number"
                className="form-control"
                style={{ width: 100 }}
                min={1}
                max={producto.stockDisponible}
                value={cantidad}
                onChange={(e) =>
                  setCantidad(Math.max(1, Math.min(Number(e.target.value) || 1, producto.stockDisponible)))
                }
              />
            </div>
          )}

          <div className="d-grid gap-2">
            <button
              type="button"
              className="btn btn-custom py-3 fs-5"
              disabled={producto.agotado}
              onClick={() => comprar(producto, cantidad)}
            >
              {producto.agotado ? 'Sin stock' : 'Agregar al carro'}
            </button>
          </div>
        </div>
      </article>

      <hr className="custom-divider my-5" />

      <section id="ficha-tecnica" className="mb-5">
        <h3 className="fw-bold mb-4">Ficha Técnica</h3>
        {producto.especificaciones?.length ? (
          <div className="table-responsive card border-0 shadow-sm">
            <table className="table table-striped table-hover mb-0">
              <caption className="p-3 text-muted">Especificaciones técnicas y componentes del instrumento</caption>
              <thead className="table-light">
                <tr>
                  <th scope="col" className="w-50">
                    Característica
                  </th>
                  <th scope="col" className="w-50">
                    Detalle
                  </th>
                </tr>
              </thead>
              <tbody>
                {producto.especificaciones.map((esp) => (
                  <tr key={esp.clave}>
                    <td>{esp.clave}</td>
                    <td>{esp.valor}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-muted">Este producto todavía no tiene ficha técnica.</p>
        )}
      </section>

      <hr className="custom-divider my-5" />

      <section id="seccion-resenas">
        <h3 className="fw-bold mb-4">Reseñas de Clientes</h3>

        <div className="row g-4 mb-5">
          <div className="col-12 col-md-4">
            <div className="card category-card border-0 p-4 shadow-sm h-100">
              <h4 className="h5 fw-bold mb-3">Puntuación General</h4>
              <p className="display-6 fw-bold m-0">{total > 0 ? promedio.toFixed(1) : '—'}</p>
              <p className="text-muted small mb-3">de 5 estrellas</p>
              <ul className="list-unstyled mb-0 d-flex flex-column gap-1 small">
                {[5, 4, 3, 2, 1].map((nivel) => {
                  const cantidadNivel = resenas.filter((r) => r.calificacion === nivel).length
                  return (
                    <li key={nivel}>
                      {nivel} {nivel === 1 ? 'estrella' : 'estrellas'}:{' '}
                      <strong>
                        {cantidadNivel} {cantidadNivel === 1 ? 'opinión' : 'opiniones'}
                      </strong>
                    </li>
                  )
                })}
              </ul>
            </div>
          </div>

          <div className="col-12 col-md-8">
            <div className="d-flex flex-column gap-3">
              {resenas.length === 0 && <p className="text-muted">Todavía no hay reseñas para este producto.</p>}
              {resenas.map((resena) => (
                <article key={resena.idResena} className="card product-card border-0 p-3 shadow-sm">
                  <h5 className="h6 fw-bold mb-1">
                    {resena.titulo} — {estrellas(resena.calificacion)}
                  </h5>
                  <p className="small text-muted mb-2">
                    Por <strong>{resena.nombreCliente}</strong> el {formatearFechaLarga(resena.fecha)} (Compra verificada)
                  </p>
                  {resena.comentario && <p className="mb-0 small">{resena.comentario}</p>}
                  {resena.respuestaAdmin && (
                    <div className="mt-2 p-2 rounded bg-light small">
                      <strong>Respuesta de Chibson:</strong> {resena.respuestaAdmin}
                    </div>
                  )}
                </article>
              ))}
            </div>
          </div>
        </div>

        <div className="card p-4 border-0 shadow-sm category-card">
          <h4 className="h5 fw-bold mb-2">Dejar una reseña sobre este producto</h4>
          {esCliente ? (
            <p className="mb-0 small">
              Si ya recibiste este producto, puedes{' '}
              <Link to={`/productos/${encodeURIComponent(producto.sku)}/resena`} className="text-link fw-bold">
                escribir tu reseña
              </Link>
              .
            </p>
          ) : (
            <p className="mb-0 small">
              Debes{' '}
              <Link
                to={`/login?redirect=${encodeURIComponent(`/productos/${producto.sku}`)}`}
                className="text-link fw-bold"
              >
                iniciar sesión
              </Link>{' '}
              o{' '}
              <Link to="/registro" className="text-link fw-bold">
                registrarte
              </Link>{' '}
              para poder calificar y opinar sobre este producto.
            </p>
          )}
        </div>
      </section>

      <ModalLoginRequerido visible={modalVisible} redireccion={redireccionLogin} alCerrar={cerrarModal} />
    </>
  )
}

export default ProductoDetallePage
