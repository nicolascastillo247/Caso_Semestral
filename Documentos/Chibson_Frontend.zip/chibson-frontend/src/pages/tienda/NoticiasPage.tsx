import { useState } from 'react'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import NoticiaCard from '@/components/NoticiaCard'
import useNoticias from '@/hooks/useNoticias'

export const NoticiasPage = () => {
  const { noticias, cargando, error, recargar } = useNoticias()
  const [porPagina, setPorPagina] = useState(6)
  const [pagina, setPagina] = useState(1)

  const totalPaginas = Math.max(1, Math.ceil(noticias.length / porPagina))
  const paginaActual = Math.min(pagina, totalPaginas)
  const inicio = (paginaActual - 1) * porPagina
  const visibles = noticias.slice(inicio, inicio + porPagina)

  return (
    <>
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <h2 className="display-6 fw-bold m-0">Noticias y Novedades</h2>
        {noticias.length > 0 && (
          <div className="d-flex align-items-center gap-3">
            <div className="d-flex align-items-center gap-2">
              <label htmlFor="porPagina" className="form-label m-0 small text-nowrap">
                Post por página
              </label>
              <select
                id="porPagina"
                className="form-select form-select-sm w-auto"
                value={porPagina}
                onChange={(e) => {
                  setPorPagina(Number(e.target.value))
                  setPagina(1)
                }}
              >
                <option value={2}>2</option>
                <option value={4}>4</option>
                <option value={6}>6</option>
              </select>
            </div>
            <span className="small text-muted">
              {inicio + 1}–{inicio + visibles.length} de {noticias.length}
            </span>
          </div>
        )}
      </div>

      {cargando && <Cargando texto="Cargando noticias..." />}
      <MensajeError mensaje={error} alReintentar={recargar} />
      {!cargando && !error && noticias.length === 0 && (
        <p className="text-muted">No hay noticias publicadas por ahora.</p>
      )}

      <div className="row g-4">
        {visibles.map((noticia) => (
          <div key={noticia.idNoticia} className="col-12 col-md-6 col-lg-4">
            <NoticiaCard noticia={noticia} />
          </div>
        ))}
      </div>

      {totalPaginas > 1 && (
        <nav aria-label="Paginación de noticias" className="mt-5">
          <ul className="pagination justify-content-center">
            <li className={`page-item${paginaActual === 1 ? ' disabled' : ''}`}>
              <button type="button" className="page-link" onClick={() => setPagina(paginaActual - 1)}>
                Anterior
              </button>
            </li>
            {Array.from({ length: totalPaginas }, (_, i) => i + 1).map((numero) => (
              <li key={numero} className={`page-item${numero === paginaActual ? ' active' : ''}`}>
                <button type="button" className="page-link" onClick={() => setPagina(numero)}>
                  {numero}
                </button>
              </li>
            ))}
            <li className={`page-item${paginaActual === totalPaginas ? ' disabled' : ''}`}>
              <button type="button" className="page-link" onClick={() => setPagina(paginaActual + 1)}>
                Siguiente
              </button>
            </li>
          </ul>
        </nav>
      )}
    </>
  )
}

export default NoticiasPage
