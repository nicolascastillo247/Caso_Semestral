import { Link } from 'react-router'

export const NoEncontradoPage = () => (
  <div className="text-center py-5">
    <h1 className="display-5 fw-bold">Página no encontrada</h1>
    <p className="text-muted">La dirección que buscas no existe.</p>
    <Link to="/" className="btn btn-custom">
      Volver al inicio
    </Link>
  </div>
)

export default NoEncontradoPage
