import { Link, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import useNoticias from '@/hooks/useNoticias'
import NoticiaService from '@/services/noticia.service'
import { CATEGORIAS_NOTICIA, COLOR_CATEGORIA_NOTICIA } from '@/utils/etiquetas'
import { formatearFechaLarga, imagenRespaldo, urlImagen } from '@/utils/formato'

export const NoticiaDetallePage = () => {
  const { id = '' } = useParams()
  const idNoticia = Number(id)
  const { datos: noticia, cargando, error, recargar } = useApi(
    () => NoticiaService.obtenerPublicada(idNoticia),
    [idNoticia],
  )
  const { noticias } = useNoticias()

  if (cargando) return <Cargando texto="Cargando artículo..." />
  if (error || !noticia) {
    return (
      <>
        <MensajeError mensaje={error ?? 'La noticia no existe.'} alReintentar={recargar} />
        <Link to="/noticias" className="text-link">
          ← Volver a noticias
        </Link>
      </>
    )
  }

  const posicion = noticias.findIndex((n) => n.idNoticia === noticia.idNoticia)
  const siguiente = posicion >= 0 && noticias.length > 1 ? noticias[(posicion + 1) % noticias.length] : null

  return (
    <>
      <nav aria-label="Ruta de navegación" className="mb-4">
        <ol className="breadcrumb">
          <li className="breadcrumb-item">
            <Link to="/noticias" className="text-link">
              Noticias
            </Link>
          </li>
          <li className="breadcrumb-item active" aria-current="page">
            Artículo
          </li>
        </ol>
      </nav>

      <div className="row justify-content-center">
        <div className="col-lg-9">
          <article className="card border-0 shadow-sm p-4 p-md-5">
            <header className="mb-4">
              <span className={`badge mb-2 ${COLOR_CATEGORIA_NOTICIA[noticia.categoria] ?? 'bg-secondary'}`}>
                {CATEGORIAS_NOTICIA[noticia.categoria] ?? noticia.categoria}
              </span>
              <h2 className="fw-bold">{noticia.titulo}</h2>
              <p className="text-muted small mb-0">
                Publicado por <strong>Taller Chibson</strong> <span className="mx-1">|</span>
                <span>{formatearFechaLarga(noticia.fechaPublicacion)}</span>
              </p>
            </header>

            {noticia.imagenUrl && (
              <figure className="mb-4">
                <img
                  src={urlImagen(noticia.imagenUrl)}
                  onError={imagenRespaldo}
                  alt={noticia.titulo}
                  className="img-fluid rounded w-100"
                  style={{ maxHeight: 420, objectFit: 'cover' }}
                />
              </figure>
            )}

            <section>
              {noticia.contenido.split(/\n+/).map((parrafo, indice) => (
                <p key={indice}>{parrafo}</p>
              ))}
            </section>

            <footer className="d-flex flex-wrap justify-content-between gap-2 mt-4 pt-3 border-top">
              <Link to="/noticias" className="text-link">
                ← Volver a noticias
              </Link>
              {siguiente && (
                <Link to={`/noticias/${siguiente.idNoticia}`} className="text-link">
                  Ver siguiente noticia →
                </Link>
              )}
            </footer>
          </article>
        </div>
      </div>
    </>
  )
}

export default NoticiaDetallePage
