import { Link } from 'react-router'
import Cargando from '@/components/Cargando'
import CarruselNoticias from '@/components/CarruselNoticias'
import ContactoSection from '@/components/ContactoSection'
import MensajeError from '@/components/MensajeError'
import ModalLoginRequerido from '@/components/ModalLoginRequerido'
import NoticiaCard from '@/components/NoticiaCard'
import ProductoCard from '@/components/ProductoCard'
import { useAuth } from '@/context/AuthContext'
import useComprar from '@/hooks/useComprar'
import useNoticias from '@/hooks/useNoticias'
import useProductos from '@/hooks/useProductos'
import { CATEGORIAS_PRODUCTO } from '@/utils/etiquetas'

export const InicioPage = () => {
  const { sesion } = useAuth()
  const { productos, cargando, error, recargar } = useProductos()
  const { noticias } = useNoticias()
  const { comprar, modalVisible, redireccionLogin, cerrarModal } = useComprar()

  const destacados = [...productos].filter((p) => !p.agotado).slice(0, 4)

  return (
    <>
      {noticias.length > 0 && (
        <>
          <section className="my-4">
            <CarruselNoticias noticias={noticias.slice(0, 3)} />
          </section>
          <hr className="custom-divider my-5" />
        </>
      )}

      <section className="row align-items-center g-4">
        <div className="col-lg-6">
          <h2 className="display-6 fw-bold">
            {sesion ? `Hola, ${sesion.nombres}` : 'Encuentra tu próximo instrumento'}
          </h2>
          <p className="lead">
            Explora nuestro catálogo con las mejores marcas, asesoría técnica y envíos a todo el país.
          </p>
          <Link to="/catalogo" className="btn btn-custom px-4">
            Ver catálogo
          </Link>
        </div>
        <div className="col-lg-6">
          <div className="card p-4 category-card shadow-sm border-0">
            <h3 className="h5 mb-3 fw-bold">Categorías</h3>
            <ul className="list-unstyled mb-0 d-flex flex-column gap-2">
              {Object.entries(CATEGORIAS_PRODUCTO).map(([codigo, nombre]) => (
                <li key={codigo}>
                  <Link to={`/catalogo?categoria=${codigo}`} className="category-link">
                    → {nombre}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <hr className="custom-divider my-5" />

      <section>
        <h3 className="fw-bold mb-4">Instrumentos Destacados</h3>
        {cargando && <Cargando texto="Cargando productos..." />}
        <MensajeError mensaje={error} alReintentar={recargar} />
        {!cargando && !error && destacados.length === 0 && (
          <p className="text-muted">Aún no hay productos disponibles.</p>
        )}
        <div className="row g-4">
          {destacados.map((producto) => (
            <div key={producto.sku} className="col-12 col-sm-6 col-lg-3">
              <ProductoCard producto={producto} alComprar={comprar} />
            </div>
          ))}
        </div>
      </section>

      {noticias.length > 0 && (
        <>
          <hr className="custom-divider my-5" />
          <section>
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h3 className="fw-bold m-0">Últimas Noticias y Artículos</h3>
              <Link to="/noticias" className="text-link">
                Ver todas →
              </Link>
            </div>
            <div className="row g-4">
              {noticias.slice(0, 2).map((noticia) => (
                <div key={noticia.idNoticia} className="col-md-6">
                  <NoticiaCard noticia={noticia} />
                </div>
              ))}
            </div>
          </section>
        </>
      )}

      <hr className="custom-divider my-5" />
      <ContactoSection />

      <ModalLoginRequerido visible={modalVisible} redireccion={redireccionLogin} alCerrar={cerrarModal} />
    </>
  )
}

export default InicioPage
