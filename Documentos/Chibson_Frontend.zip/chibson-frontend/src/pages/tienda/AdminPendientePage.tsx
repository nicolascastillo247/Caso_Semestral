import { Link } from 'react-router'
import { useAuth } from '@/context/AuthContext'

export const AdminPendientePage = () => {
  const { sesion } = useAuth()
  return (
    <div className="row justify-content-center">
      <div className="col-lg-7">
        <div className="card product-card border-0 shadow-sm p-5 text-center">
          <h1 className="h3 fw-bold">Panel de administración</h1>
          <p className="text-muted mb-4">
            {sesion
              ? `Ingresaste como ${sesion.rol.toLowerCase()}. El panel de administración se conecta en la siguiente etapa del proyecto.`
              : 'Inicia sesión con una cuenta de administrador para continuar.'}
          </p>
          <Link to={sesion ? '/' : '/login'} className="btn btn-custom">
            {sesion ? 'Volver a la tienda' : 'Iniciar sesión'}
          </Link>
        </div>
      </div>
    </div>
  )
}

export default AdminPendientePage
