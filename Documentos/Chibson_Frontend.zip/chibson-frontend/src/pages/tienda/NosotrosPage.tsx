import { CONTACTO_POR_DEFECTO } from '@/components/ContactoSection'
import useApi from '@/hooks/useApi'
import InstitucionalService from '@/services/institucional.service'

const MISION_POR_DEFECTO =
  'Brindar a los músicos las mejores herramientas sonoras del mercado, combinando calidad técnica, precios accesibles y un servicio al cliente comprometido con el crecimiento artístico de nuestra comunidad.'

const VISION_POR_DEFECTO =
  'Ser la tienda referente de instrumentos y equipamiento musical a nivel nacional, reconocida por la excelencia de nuestros productos, la cercanía con nuestros clientes y el fomento activo de la cultura musical.'

export const NosotrosPage = () => {
  const { datos } = useApi(() => InstitucionalService.obtener())

  return (
    <>
      <section className="row align-items-center g-4">
        <div className="col-lg-5 text-center">
          <img src="/img/logo.png" alt="Chibson Instruments" className="img-fluid" style={{ maxHeight: 260 }} />
        </div>
        <div className="col-lg-7">
          <h2 className="display-6 fw-bold">Quiénes Somos</h2>
          <p className="lead">
            En <strong>Chibson Instruments</strong> nos dedicamos a acercar la música a cada rincón, ofreciendo
            instrumentos musicales de alta calidad y accesorios especializados tanto para músicos emergentes como para
            profesionales consolidados.
          </p>
        </div>
      </section>

      <hr className="custom-divider my-5" />

      <section className="row g-4">
        <div className="col-md-6">
          <article className="card h-100 category-card border-0 shadow-sm p-4">
            <h3 className="h4 fw-bold">Nuestra Misión</h3>
            <p className="mb-0">{datos?.mision || MISION_POR_DEFECTO}</p>
          </article>
        </div>
        <div className="col-md-6">
          <article className="card h-100 category-card border-0 shadow-sm p-4">
            <h3 className="h4 fw-bold">Nuestra Visión</h3>
            <p className="mb-0">{datos?.vision || VISION_POR_DEFECTO}</p>
          </article>
        </div>
      </section>

      <hr className="custom-divider my-5" />

      <section className="contact-section p-4 rounded shadow-sm">
        <h2 className="h4 fw-bold mb-3">Información de Contacto</h2>
        <ul className="list-unstyled mb-0 d-flex flex-column gap-2">
          <li>
            <strong>Correo electrónico:</strong> {datos?.correo || CONTACTO_POR_DEFECTO.correo}
          </li>
          <li>
            <strong>Teléfono / WhatsApp:</strong> {datos?.telefono || CONTACTO_POR_DEFECTO.telefono}
          </li>
          <li>
            <strong>Ubicación:</strong> {datos?.direccion || CONTACTO_POR_DEFECTO.direccion}
          </li>
          <li>
            <strong>Horario de atención:</strong> Lunes a Viernes de 10:00 a 19:00 hrs / Sábados de 10:00 a 14:00 hrs
          </li>
        </ul>
      </section>
    </>
  )
}

export default NosotrosPage
