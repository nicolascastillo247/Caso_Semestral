import { useMemo, useState, type FormEvent } from 'react'
import { useSearchParams } from 'react-router'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import ModalLoginRequerido from '@/components/ModalLoginRequerido'
import ProductoCard from '@/components/ProductoCard'
import useComprar from '@/hooks/useComprar'
import useProductos from '@/hooks/useProductos'
import { CATEGORIAS_PRODUCTO } from '@/utils/etiquetas'

type Orden = 'relevancia' | 'precio_asc' | 'precio_desc' | 'recientes'

const normalizar = (texto: string) =>
  texto
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')

export const CatalogoPage = () => {
  const [parametros, setParametros] = useSearchParams()
  const { productos, cargando, error, recargar } = useProductos()
  const { comprar, modalVisible, redireccionLogin, cerrarModal } = useComprar()

  const texto = parametros.get('q') ?? ''
  const categorias = parametros.getAll('categoria')
  const [busqueda, setBusqueda] = useState(texto)
  const [marcas, setMarcas] = useState<string[]>([])
  const [precioMin, setPrecioMin] = useState('')
  const [precioMax, setPrecioMax] = useState('')
  const [soloStock, setSoloStock] = useState(false)
  const [orden, setOrden] = useState<Orden>('relevancia')
  const [verFiltros, setVerFiltros] = useState(categorias.length > 0)

  const marcasDisponibles = useMemo(
    () => [...new Set(productos.map((p) => p.marca).filter(Boolean))].sort((a, b) => a.localeCompare(b)),
    [productos],
  )

  const filtrados = useMemo(() => {
    const consulta = normalizar(texto.trim())
    const min = precioMin === '' ? null : Number(precioMin)
    const max = precioMax === '' ? null : Number(precioMax)
    const resultado = productos.filter((p) => {
      const enTexto =
        !consulta ||
        normalizar(`${p.modelo} ${p.marca} ${CATEGORIAS_PRODUCTO[p.categoria] ?? p.categoria}`).includes(consulta)
      return (
        enTexto &&
        (categorias.length === 0 || categorias.includes(p.categoria)) &&
        (marcas.length === 0 || marcas.includes(p.marca)) &&
        (min === null || p.precio >= min) &&
        (max === null || p.precio <= max) &&
        (!soloStock || !p.agotado)
      )
    })
    switch (orden) {
      case 'precio_asc':
        return resultado.sort((a, b) => a.precio - b.precio)
      case 'precio_desc':
        return resultado.sort((a, b) => b.precio - a.precio)
      case 'recientes':
        return resultado.sort((a, b) => (b.fechaModificacion ?? '').localeCompare(a.fechaModificacion ?? ''))
      default:
        return resultado
    }
  }, [productos, texto, categorias, marcas, precioMin, precioMax, soloStock, orden])

  const buscar = (evento: FormEvent) => {
    evento.preventDefault()
    const nuevos = new URLSearchParams(parametros)
    if (busqueda.trim()) nuevos.set('q', busqueda.trim())
    else nuevos.delete('q')
    setParametros(nuevos)
  }

  const alternarCategoria = (codigo: string) => {
    const nuevos = new URLSearchParams(parametros)
    const actuales = nuevos.getAll('categoria')
    nuevos.delete('categoria')
    const siguientes = actuales.includes(codigo) ? actuales.filter((c) => c !== codigo) : [...actuales, codigo]
    siguientes.forEach((c) => nuevos.append('categoria', c))
    setParametros(nuevos)
  }

  const alternarMarca = (marca: string) =>
    setMarcas((actuales) => (actuales.includes(marca) ? actuales.filter((m) => m !== marca) : [...actuales, marca]))

  const limpiar = () => {
    setBusqueda('')
    setMarcas([])
    setPrecioMin('')
    setPrecioMax('')
    setSoloStock(false)
    setParametros(new URLSearchParams())
  }

  return (
    <>
      <h2 className="display-6 fw-bold mb-4">Catálogo de Instrumentos</h2>

      <div className="row g-3 align-items-center mb-4">
        <div className="col-12 col-md-8">
          <form className="d-flex gap-2" onSubmit={buscar} role="search">
            <input
              type="search"
              className="form-control"
              placeholder="Modelo, marca o tipo..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              aria-label="Buscar instrumentos"
            />
            <button type="submit" className="btn btn-custom px-4">
              Buscar
            </button>
          </form>
        </div>
        <div className="col-12 col-md-4 text-md-end">
          <button type="button" className="btn btn-custom w-100 w-md-auto" onClick={() => setVerFiltros(!verFiltros)}>
            {verFiltros ? 'Ocultar filtros' : 'Filtrar resultados'}
          </button>
        </div>
      </div>

      {verFiltros && (
        <div className="card p-4 category-card border-0 shadow-sm mb-4">
          <div className="row g-4">
            <div className="col-12 col-sm-6 col-lg-3">
              <h3 className="h6 fw-bold mb-3">Categoría</h3>
              {Object.entries(CATEGORIAS_PRODUCTO).map(([codigo, nombre]) => (
                <div className="form-check mb-1" key={codigo}>
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id={`cat_${codigo}`}
                    checked={categorias.includes(codigo)}
                    onChange={() => alternarCategoria(codigo)}
                  />
                  <label className="form-check-label" htmlFor={`cat_${codigo}`}>
                    {nombre}
                  </label>
                </div>
              ))}
            </div>

            <div className="col-12 col-sm-6 col-lg-3">
              <h3 className="h6 fw-bold mb-3">Rango de Precio</h3>
              <div className="mb-2">
                <label htmlFor="precio_min" className="form-label small">
                  Mínimo:
                </label>
                <input
                  type="number"
                  className="form-control form-control-sm"
                  id="precio_min"
                  min={0}
                  placeholder="$0"
                  value={precioMin}
                  onChange={(e) => setPrecioMin(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="precio_max" className="form-label small">
                  Máximo:
                </label>
                <input
                  type="number"
                  className="form-control form-control-sm"
                  id="precio_max"
                  min={0}
                  placeholder="$1.000.000"
                  value={precioMax}
                  onChange={(e) => setPrecioMax(e.target.value)}
                />
              </div>
            </div>

            <div className="col-12 col-sm-6 col-lg-3">
              <h3 className="h6 fw-bold mb-3">Marca</h3>
              {marcasDisponibles.length === 0 && <p className="small text-muted">Sin marcas</p>}
              {marcasDisponibles.map((marca) => (
                <div className="form-check mb-1" key={marca}>
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id={`marca_${marca}`}
                    checked={marcas.includes(marca)}
                    onChange={() => alternarMarca(marca)}
                  />
                  <label className="form-check-label" htmlFor={`marca_${marca}`}>
                    {marca}
                  </label>
                </div>
              ))}
            </div>

            <div className="col-12 col-sm-6 col-lg-3">
              <h3 className="h6 fw-bold mb-3">Disponibilidad</h3>
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="solo_stock"
                  checked={soloStock}
                  onChange={(e) => setSoloStock(e.target.checked)}
                />
                <label className="form-check-label" htmlFor="solo_stock">
                  Solo con stock disponible
                </label>
              </div>
            </div>
          </div>

          <div className="d-flex gap-2 mt-4 pt-3 border-top border-secondary-subtle">
            <button type="button" className="btn btn-outline-secondary btn-sm px-3" onClick={limpiar}>
              Limpiar filtros
            </button>
          </div>
        </div>
      )}

      <section className="d-flex flex-wrap justify-content-between align-items-center gap-3 py-3 border-top border-bottom custom-divider">
        <p className="m-0 fw-semibold">
          {filtrados.length} {filtrados.length === 1 ? 'producto encontrado' : 'productos encontrados'}
        </p>
        <div className="d-flex align-items-center gap-2">
          <label htmlFor="ordenar" className="form-label m-0 small text-nowrap">
            Ordenar por:
          </label>
          <select
            id="ordenar"
            className="form-select form-select-sm w-auto"
            value={orden}
            onChange={(e) => setOrden(e.target.value as Orden)}
          >
            <option value="relevancia">Relevancia</option>
            <option value="precio_asc">Precio: menor a mayor</option>
            <option value="precio_desc">Precio: mayor a menor</option>
            <option value="recientes">Más recientes</option>
          </select>
        </div>
      </section>

      <section className="my-5">
        {cargando && <Cargando texto="Cargando catálogo..." />}
        <MensajeError mensaje={error} alReintentar={recargar} />
        {!cargando && !error && filtrados.length === 0 && (
          <p className="text-muted text-center py-4">No hay productos que coincidan con la búsqueda.</p>
        )}
        <div className="row g-4">
          {filtrados.map((producto) => (
            <div key={producto.sku} className="col-12 col-sm-6 col-lg-4">
              <ProductoCard producto={producto} alComprar={comprar} />
            </div>
          ))}
        </div>
      </section>

      <ModalLoginRequerido visible={modalVisible} redireccion={redireccionLogin} alCerrar={cerrarModal} />
    </>
  )
}

export default CatalogoPage
