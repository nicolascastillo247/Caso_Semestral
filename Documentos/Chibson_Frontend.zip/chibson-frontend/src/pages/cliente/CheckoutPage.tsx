import { useState, type FormEvent } from 'react'
import { Link, Navigate, useNavigate } from 'react-router'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import { COSTO_ENVIO, useCarrito } from '@/context/CarritoContext'
import useApi from '@/hooks/useApi'
import { mensajeDeError } from '@/api/apiClient'
import PedidoService, { type CompraRespuesta, type MetodoPago } from '@/services/pedido.service'
import UsuarioService, { direccionTexto, tieneDireccion } from '@/services/usuario.service'
import { METODOS_PAGO } from '@/utils/etiquetas'
import { formatearPrecio, numeroConCeros } from '@/utils/formato'

export const CheckoutPage = () => {
  const { items, subtotal, vaciar } = useCarrito()
  const { datos: perfil, cargando, error: errorPerfil } = useApi(() => UsuarioService.obtenerPerfil())
  const navigate = useNavigate()

  const [usarOtra, setUsarOtra] = useState(false)
  const [direccion, setDireccion] = useState({ region: '', ciudadComuna: '', condominio: '', numero: '' })
  const [metodoPago, setMetodoPago] = useState<MetodoPago | ''>('')
  const [simularRechazo, setSimularRechazo] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [rechazo, setRechazo] = useState<CompraRespuesta | null>(null)
  const [enviando, setEnviando] = useState(false)

  if (items.length === 0 && !rechazo && !enviando) {
    return <Navigate to="/carrito" replace />
  }
  if (cargando) return <Cargando texto="Preparando tu compra..." />

  const perfilConDireccion = tieneDireccion(perfil)
  const usaOtraDireccion = usarOtra || !perfilConDireccion

  const terminarCompra = (respuesta: CompraRespuesta) => {
    if (respuesta.aprobado) {
      vaciar()
      navigate(`/pedido-confirmado/${respuesta.pedido.numeroPedido}`, { replace: true })
    } else {
      setRechazo(respuesta)
      vaciar()
    }
  }

  const confirmar = async (evento: FormEvent) => {
    evento.preventDefault()
    if (!metodoPago) {
      setError('Selecciona un método de pago.')
      return
    }
    setEnviando(true)
    setError(null)
    try {
      const respuesta = rechazo
        ? await PedidoService.reintentarPago(rechazo.pedido.numeroPedido, metodoPago, simularRechazo)
        : await PedidoService.comprar({
            items: items.map((item) => ({ sku: item.sku, cantidad: item.cantidad })),
            metodoPago,
            usarDireccionDistinta: usaOtraDireccion,
            ...(usaOtraDireccion ? direccion : {}),
            simularRechazo,
          })
      terminarCompra(respuesta)
    } catch (err) {
      setError(mensajeDeError(err, 'No se pudo completar la compra.'))
    } finally {
      setEnviando(false)
    }
  }

  const lineas = rechazo
    ? rechazo.pedido.items.map((item) => ({
        sku: item.sku,
        nombre: item.nombreProducto,
        cantidad: item.cantidad,
        total: item.precioUnitario * item.cantidad,
      }))
    : items.map((item) => ({ sku: item.sku, nombre: item.modelo, cantidad: item.cantidad, total: item.precio * item.cantidad }))
  const totalCompra = rechazo ? rechazo.pedido.total : subtotal + COSTO_ENVIO

  return (
    <>
      <h1 className="display-6 fw-bold mb-4">Finalizar compra</h1>

      {rechazo && (
        <div className="alert alert-warning">
          <strong>El pago del pedido #{numeroConCeros(rechazo.pedido.numeroPedido)} fue rechazado.</strong>
          <div>{rechazo.mensaje}</div>
          <div className="small mt-1">Tu pedido quedó pendiente: puedes intentar pagarlo de nuevo con otro método.</div>
        </div>
      )}
      <MensajeError mensaje={error ?? errorPerfil} />

      <form onSubmit={confirmar}>
        <div className="row g-4">
          <div className="col-lg-8">
            {!rechazo && (
              <div className="card border-0 shadow-sm p-4 mb-4">
                <h2 className="h4 fw-bold">Dirección de envío</h2>
                {perfilConDireccion && (
                  <>
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="direccion"
                        id="direccion-perfil"
                        checked={!usarOtra}
                        onChange={() => setUsarOtra(false)}
                      />
                      <label className="form-check-label" htmlFor="direccion-perfil">
                        {direccionTexto(perfil)}
                      </label>
                    </div>
                    <div className="form-check mb-2">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="direccion"
                        id="direccion-otra"
                        checked={usarOtra}
                        onChange={() => setUsarOtra(true)}
                      />
                      <label className="form-check-label" htmlFor="direccion-otra">
                        Enviar a otra dirección
                      </label>
                    </div>
                  </>
                )}
                {!perfilConDireccion && (
                  <p className="small text-muted">
                    Tu perfil no tiene dirección guardada. Ingresa dónde quieres recibir el pedido o{' '}
                    <Link to="/perfil" className="text-link">
                      guárdala en tu perfil
                    </Link>
                    .
                  </p>
                )}
                {usaOtraDireccion && (
                  <div className="row g-3 mt-1">
                    <div className="col-md-6">
                      <label htmlFor="region" className="form-label">
                        Región
                      </label>
                      <input
                        id="region"
                        className="form-control"
                        required
                        value={direccion.region}
                        onChange={(e) => setDireccion({ ...direccion, region: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="ciudadComuna" className="form-label">
                        Ciudad o comuna
                      </label>
                      <input
                        id="ciudadComuna"
                        className="form-control"
                        required
                        value={direccion.ciudadComuna}
                        onChange={(e) => setDireccion({ ...direccion, ciudadComuna: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="numero" className="form-label">
                        Calle y número
                      </label>
                      <input
                        id="numero"
                        className="form-control"
                        required
                        value={direccion.numero}
                        onChange={(e) => setDireccion({ ...direccion, numero: e.target.value })}
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="condominio" className="form-label">
                        Depto. o condominio (opcional)
                      </label>
                      <input
                        id="condominio"
                        className="form-control"
                        value={direccion.condominio}
                        onChange={(e) => setDireccion({ ...direccion, condominio: e.target.value })}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="card border-0 shadow-sm p-4">
              <h2 className="h4 fw-bold">Método de pago</h2>
              {(Object.keys(METODOS_PAGO) as MetodoPago[]).map((metodo) => (
                <div className="form-check mb-2" key={metodo}>
                  <input
                    className="form-check-input"
                    type="radio"
                    name="pago"
                    id={metodo}
                    checked={metodoPago === metodo}
                    onChange={() => setMetodoPago(metodo)}
                  />
                  <label className="form-check-label" htmlFor={metodo}>
                    {METODOS_PAGO[metodo]}
                  </label>
                </div>
              ))}
              <div className="form-check form-switch mt-3 pt-3 border-top">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="simularRechazo"
                  checked={simularRechazo}
                  onChange={(e) => setSimularRechazo(e.target.checked)}
                />
                <label className="form-check-label small text-muted" htmlFor="simularRechazo">
                  Simular pago rechazado (demostración)
                </label>
              </div>
            </div>
          </div>

          <div className="col-lg-4">
            <div className="card category-card border-0 p-4">
              <h2 className="h5 fw-bold">Resumen del pedido</h2>
              {lineas.map((linea) => (
                <div key={linea.sku} className="d-flex justify-content-between gap-3 mb-2">
                  <span>
                    {linea.nombre} x{linea.cantidad}
                  </span>
                  <strong>{formatearPrecio(linea.total)}</strong>
                </div>
              ))}
              <div className="d-flex justify-content-between gap-3 mb-2">
                <span>Despacho</span>
                <strong>{formatearPrecio(rechazo ? rechazo.pedido.costoEnvio : COSTO_ENVIO)}</strong>
              </div>
              <hr />
              <div className="d-flex justify-content-between fs-5">
                <span>Total</span>
                <strong>{formatearPrecio(totalCompra)}</strong>
              </div>
              <button type="submit" className="btn btn-custom w-100 mt-3" disabled={enviando}>
                {enviando ? 'Procesando pago...' : rechazo ? 'Reintentar pago' : 'Confirmar compra'}
              </button>
              {rechazo ? (
                <Link to="/mis-pedidos" className="btn btn-outline-dark w-100 mt-2">
                  Pagar más tarde
                </Link>
              ) : (
                <Link to="/carrito" className="btn btn-outline-dark w-100 mt-2">
                  Volver
                </Link>
              )}
            </div>
          </div>
        </div>
      </form>
    </>
  )
}

export default CheckoutPage
