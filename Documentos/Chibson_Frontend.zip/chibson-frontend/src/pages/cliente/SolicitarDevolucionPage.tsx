import { useState, type FormEvent } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import { mensajeDeError } from '@/api/apiClient'
import DevolucionService, { type MotivoDevolucion } from '@/services/devolucion.service'
import PedidoService from '@/services/pedido.service'
import { MOTIVOS_DEVOLUCION } from '@/utils/etiquetas'
import { numeroConCeros } from '@/utils/formato'

export const SolicitarDevolucionPage = () => {
  const { numero = '' } = useParams()
  const navigate = useNavigate()
  const { datos: pedido, cargando, error: errorPedido } = useApi(() => PedidoService.miPedido(Number(numero)), [numero])

  const [cantidades, setCantidades] = useState<Record<string, number>>({})
  const [motivo, setMotivo] = useState<MotivoDevolucion | ''>('')
  const [descripcion, setDescripcion] = useState('')
  const [evidenciaUrl, setEvidenciaUrl] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [enviando, setEnviando] = useState(false)

  if (cargando) return <Cargando texto="Cargando pedido..." />
  if (errorPedido || !pedido) return <MensajeError mensaje={errorPedido ?? 'No se encontró el pedido.'} />

  if (pedido.estado !== 'ENTREGADO') {
    return (
      <div className="alert alert-info">
        Solo puedes pedir la devolución de un pedido entregado.{' '}
        <Link to={`/mis-pedidos/${pedido.numeroPedido}`} className="text-link">
          Volver al pedido
        </Link>
      </div>
    )
  }

  const enviar = async (evento: FormEvent) => {
    evento.preventDefault()
    const items = Object.entries(cantidades)
      .filter(([, cantidad]) => cantidad > 0)
      .map(([sku, cantidad]) => ({ sku, cantidad }))
    if (items.length === 0) {
      setError('Selecciona al menos un producto y la cantidad a devolver.')
      return
    }
    if (!motivo) {
      setError('Selecciona el motivo de la devolución.')
      return
    }
    setEnviando(true)
    setError(null)
    try {
      await DevolucionService.solicitar({
        numeroPedido: pedido.numeroPedido,
        items,
        motivo,
        descripcion,
        evidenciaUrl: evidenciaUrl.trim() || undefined,
      })
      navigate('/devoluciones', { replace: true, state: { creada: true } })
    } catch (err) {
      setError(mensajeDeError(err, 'No se pudo enviar la solicitud.'))
      setEnviando(false)
    }
  }

  return (
    <>
      <Link to={`/mis-pedidos/${pedido.numeroPedido}`} className="text-link d-inline-block mb-3">
        ← Volver al pedido
      </Link>
      <h1 className="display-6 fw-bold mb-4">Solicitar devolución</h1>

      <div className="card border-0 shadow-sm p-4">
        <form onSubmit={enviar}>
          <MensajeError mensaje={error} />
          <p className="fw-semibold">Pedido #{numeroConCeros(pedido.numeroPedido)}</p>

          <div className="table-responsive mb-3">
            <table className="table align-middle">
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Comprados</th>
                  <th style={{ width: 160 }}>A devolver</th>
                </tr>
              </thead>
              <tbody>
                {pedido.items.map((item) => (
                  <tr key={item.idItem}>
                    <td>{item.nombreProducto}</td>
                    <td>{item.cantidad}</td>
                    <td>
                      <input
                        type="number"
                        className="form-control"
                        min={0}
                        max={item.cantidad}
                        value={cantidades[item.sku] ?? 0}
                        aria-label={`Cantidad a devolver de ${item.nombreProducto}`}
                        onChange={(e) =>
                          setCantidades({
                            ...cantidades,
                            [item.sku]: Math.max(0, Math.min(Number(e.target.value) || 0, item.cantidad)),
                          })
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="row g-3">
            <div className="col-md-6">
              <label htmlFor="motivo" className="form-label">
                Motivo
              </label>
              <select
                id="motivo"
                className="form-select"
                required
                value={motivo}
                onChange={(e) => setMotivo(e.target.value as MotivoDevolucion)}
              >
                <option value="">Seleccione</option>
                {Object.entries(MOTIVOS_DEVOLUCION).map(([valor, texto]) => (
                  <option key={valor} value={valor}>
                    {texto}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-md-6">
              <label htmlFor="evidencia" className="form-label">
                Evidencia (enlace a una imagen, opcional)
              </label>
              <input
                id="evidencia"
                type="url"
                className="form-control"
                placeholder="https://..."
                value={evidenciaUrl}
                onChange={(e) => setEvidenciaUrl(e.target.value)}
              />
            </div>
            <div className="col-12">
              <label htmlFor="descripcion" className="form-label">
                Descripción
              </label>
              <textarea
                id="descripcion"
                className="form-control"
                rows={5}
                required
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
              ></textarea>
            </div>
          </div>

          <button type="submit" className="btn btn-custom mt-4" disabled={enviando}>
            {enviando ? 'Enviando...' : 'Enviar solicitud'}
          </button>
        </form>
      </div>
    </>
  )
}

export default SolicitarDevolucionPage
