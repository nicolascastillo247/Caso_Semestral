import { useState } from 'react'
import { Link, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import Insignia from '@/components/Insignia'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import { mensajeDeError } from '@/api/apiClient'
import PedidoService, { type MetodoPago } from '@/services/pedido.service'
import { ESTADOS_PEDIDO, METODOS_PAGO } from '@/utils/etiquetas'
import { formatearFechaHora, formatearPrecio, numeroConCeros } from '@/utils/formato'

export const PedidoDetallePage = () => {
  const { numero = '' } = useParams()
  const { datos: pedido, cargando, error, recargar } = useApi(() => PedidoService.miPedido(Number(numero)), [numero])
  const [metodo, setMetodo] = useState<MetodoPago>('DEBITO')
  const [pagando, setPagando] = useState(false)
  const [mensajePago, setMensajePago] = useState<{ tipo: 'success' | 'danger'; texto: string } | null>(null)

  if (cargando) return <Cargando texto="Cargando pedido..." />
  if (error || !pedido) {
    return (
      <>
        <MensajeError mensaje={error ?? 'No se encontró el pedido.'} alReintentar={recargar} />
        <Link to="/mis-pedidos" className="text-link">
          ← Volver a mis pedidos
        </Link>
      </>
    )
  }

  const pagar = async () => {
    setPagando(true)
    setMensajePago(null)
    try {
      const respuesta = await PedidoService.reintentarPago(pedido.numeroPedido, metodo)
      setMensajePago({ tipo: respuesta.aprobado ? 'success' : 'danger', texto: respuesta.mensaje })
      await recargar()
    } catch (err) {
      setMensajePago({ tipo: 'danger', texto: mensajeDeError(err) })
    } finally {
      setPagando(false)
    }
  }

  const entregado = pedido.estado === 'ENTREGADO'
  const direccion = pedido.direccion
    ? [pedido.direccion.numero, pedido.direccion.condominio, pedido.direccion.ciudadComuna, pedido.direccion.region]
        .filter(Boolean)
        .join(', ')
    : '—'

  return (
    <>
      <Link to="/mis-pedidos" className="text-link d-inline-block mb-3">
        ← Volver a mis pedidos
      </Link>
      <h1 className="display-6 fw-bold">Pedido #{numeroConCeros(pedido.numeroPedido)}</h1>
      <p className="mb-4">
        Estado actual: <Insignia valor={pedido.estado} estados={ESTADOS_PEDIDO} />
      </p>

      {mensajePago && <div className={`alert alert-${mensajePago.tipo}`}>{mensajePago.texto}</div>}

      <div className="row g-4">
        <div className="col-lg-8">
          <div className="card border-0 shadow-sm p-4">
            <h2 className="h4 fw-bold">Productos</h2>
            <div className="table-responsive">
              <table className="table align-middle">
                <thead>
                  <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                    {entregado && <th></th>}
                  </tr>
                </thead>
                <tbody>
                  {pedido.items.map((item) => (
                    <tr key={item.idItem}>
                      <td>
                        <Link to={`/productos/${encodeURIComponent(item.sku)}`} className="text-link">
                          {item.nombreProducto}
                        </Link>
                      </td>
                      <td>{item.cantidad}</td>
                      <td>{formatearPrecio(item.precioUnitario * item.cantidad)}</td>
                      {entregado && (
                        <td className="text-end">
                          <Link
                            to={`/productos/${encodeURIComponent(item.sku)}/resena`}
                            className="btn btn-sm btn-outline-dark"
                          >
                            Dejar reseña
                          </Link>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="d-flex justify-content-between">
              <span>Despacho</span>
              <strong>{formatearPrecio(pedido.costoEnvio)}</strong>
            </div>
            <div className="d-flex justify-content-between small text-muted">
              <span>IVA incluido</span>
              <span>{formatearPrecio(pedido.iva)}</span>
            </div>
            <div className="d-flex justify-content-between fs-5 mt-2">
              <span>Total</span>
              <strong>{formatearPrecio(pedido.total)}</strong>
            </div>

            {entregado && (
              <div className="d-flex flex-wrap gap-2 mt-4">
                <Link to={`/mis-pedidos/${pedido.numeroPedido}/devolucion`} className="btn btn-outline-danger">
                  Solicitar devolución
                </Link>
              </div>
            )}

            {pedido.estado === 'PENDIENTE' && (
              <div className="mt-4 pt-3 border-top">
                <h3 className="h6 fw-bold">Pago pendiente</h3>
                <div className="d-flex flex-wrap gap-2">
                  <select
                    className="form-select w-auto"
                    value={metodo}
                    onChange={(e) => setMetodo(e.target.value as MetodoPago)}
                    aria-label="Método de pago"
                  >
                    {(Object.keys(METODOS_PAGO) as MetodoPago[]).map((m) => (
                      <option key={m} value={m}>
                        {METODOS_PAGO[m]}
                      </option>
                    ))}
                  </select>
                  <button type="button" className="btn btn-custom" disabled={pagando} onClick={pagar}>
                    {pagando ? 'Procesando...' : 'Pagar pedido'}
                  </button>
                </div>
              </div>
            )}

            {pedido.motivoCancelacion && (
              <div className="alert alert-secondary mt-4 mb-0">
                <strong>Motivo de cancelación:</strong> {pedido.motivoCancelacion}
              </div>
            )}
          </div>
        </div>

        <div className="col-lg-4">
          <div className="card category-card border-0 p-4 mb-4">
            <h2 className="h5 fw-bold">Despacho</h2>
            <p className="mb-1">{direccion}</p>
            <p className="small text-muted mb-0">
              Pago: {pedido.metodoPago ? METODOS_PAGO[pedido.metodoPago] : 'Pendiente'}
            </p>
          </div>
          <div className="card category-card border-0 p-4">
            <h2 className="h5 fw-bold">Historial de estado</h2>
            <ul className="list-unstyled mb-0 d-flex flex-column gap-2 small">
              {pedido.historial.map((h) => (
                <li key={h.idHistorial}>
                  <strong>{formatearFechaHora(h.fecha)}</strong> — {ESTADOS_PEDIDO[h.estadoNuevo]?.texto ?? h.estadoNuevo}
                </li>
              ))}
              {pedido.historial.length === 0 && <li className="text-muted">Sin movimientos.</li>}
            </ul>
          </div>
        </div>
      </div>
    </>
  )
}

export default PedidoDetallePage
