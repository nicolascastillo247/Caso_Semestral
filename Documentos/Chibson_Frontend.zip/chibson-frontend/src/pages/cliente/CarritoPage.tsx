import { Link } from 'react-router'
import { COSTO_ENVIO, useCarrito } from '@/context/CarritoContext'
import { formatearPrecio, imagenRespaldo, urlImagen } from '@/utils/formato'

export const CarritoPage = () => {
  const { items, subtotal, cambiarCantidad, quitar, vaciar } = useCarrito()

  if (items.length === 0) {
    return (
      <div className="text-center py-5">
        <h1 className="display-6 fw-bold mb-3">Carro de compras</h1>
        <p className="text-muted">Tu carro está vacío.</p>
        <Link to="/catalogo" className="btn btn-custom">
          Ir al catálogo
        </Link>
      </div>
    )
  }

  return (
    <>
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <h1 className="display-6 fw-bold m-0">Carro de compras</h1>
        <button type="button" className="btn btn-outline-secondary btn-sm" onClick={vaciar}>
          Vaciar carro
        </button>
      </div>

      <div className="card border-0 shadow-sm p-3">
        <div className="table-responsive">
          <table className="table align-middle mb-0">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Precio</th>
                <th style={{ width: 140 }}>Cantidad</th>
                <th>Subtotal</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.sku}>
                  <td>
                    <div className="d-flex align-items-center gap-3">
                      <img
                        src={urlImagen(item.imagenUrl)}
                        onError={imagenRespaldo}
                        alt={item.modelo}
                        style={{ width: 90, height: 90, objectFit: 'contain' }}
                        className="border rounded p-2 bg-white"
                      />
                      <div>
                        <Link to={`/productos/${encodeURIComponent(item.sku)}`} className="text-link fw-bold">
                          {item.modelo}
                        </Link>
                        <div className="text-muted small">
                          {item.marca} · {item.sku}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>{formatearPrecio(item.precio)}</td>
                  <td>
                    <input
                      type="number"
                      min={1}
                      max={Math.max(item.stockDisponible, 1)}
                      value={item.cantidad}
                      className="form-control"
                      aria-label={`Cantidad de ${item.modelo}`}
                      onChange={(e) => cambiarCantidad(item.sku, Number(e.target.value) || 1)}
                    />
                  </td>
                  <td>{formatearPrecio(item.precio * item.cantidad)}</td>
                  <td>
                    <button type="button" className="btn btn-outline-danger btn-sm" onClick={() => quitar(item.sku)}>
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="row justify-content-end mt-4">
        <div className="col-md-5 col-lg-4">
          <div className="card category-card border-0 p-4">
            <h2 className="h5 fw-bold">Resumen</h2>
            <div className="d-flex justify-content-between mb-2">
              <span>Subtotal</span>
              <strong>{formatearPrecio(subtotal)}</strong>
            </div>
            <div className="d-flex justify-content-between mb-2">
              <span>Despacho</span>
              <strong>{formatearPrecio(COSTO_ENVIO)}</strong>
            </div>
            <hr />
            <div className="d-flex justify-content-between fs-5">
              <span>Total</span>
              <strong>{formatearPrecio(subtotal + COSTO_ENVIO)}</strong>
            </div>
            <p className="small text-muted mt-2 mb-0">Precios con IVA incluido.</p>
            <Link to="/checkout" className="btn btn-custom w-100 mt-3">
              Continuar compra
            </Link>
            <Link to="/catalogo" className="btn btn-outline-dark w-100 mt-2">
              Seguir comprando
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}

export default CarritoPage
