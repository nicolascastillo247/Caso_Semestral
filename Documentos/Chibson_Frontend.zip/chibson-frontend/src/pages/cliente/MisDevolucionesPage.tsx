import { Link, useLocation } from 'react-router'
import Cargando from '@/components/Cargando'
import Insignia from '@/components/Insignia'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import DevolucionService from '@/services/devolucion.service'
import { ESTADOS_DEVOLUCION, MOTIVOS_DEVOLUCION } from '@/utils/etiquetas'
import { formatearFecha, formatearPrecio, numeroConCeros } from '@/utils/formato'

export const MisDevolucionesPage = () => {
  const { state } = useLocation()
  const { datos, cargando, error, recargar } = useApi(() => DevolucionService.misDevoluciones())
  const devoluciones = [...(datos ?? [])].sort((a, b) => b.numeroSeguimiento - a.numeroSeguimiento)
  const recienCreada = (state as { creada?: boolean } | null)?.creada

  return (
    <>
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <h1 className="display-6 fw-bold m-0">Mis devoluciones</h1>
        <Link to="/mis-pedidos" className="btn btn-custom">
          Nueva solicitud
        </Link>
      </div>

      {recienCreada && (
        <div className="alert alert-success">Tu solicitud fue enviada. Te avisaremos cuando sea revisada.</div>
      )}
      {cargando && <Cargando texto="Cargando devoluciones..." />}
      <MensajeError mensaje={error} alReintentar={recargar} />

      {!cargando && !error && devoluciones.length === 0 && (
        <p className="text-muted">
          No tienes solicitudes de devolución. Puedes pedir una desde el detalle de un pedido entregado.
        </p>
      )}

      {devoluciones.length > 0 && (
        <div className="card border-0 shadow-sm p-3">
          <div className="table-responsive">
            <table className="table align-middle mb-0">
              <thead>
                <tr>
                  <th>N° Solicitud</th>
                  <th>Pedido</th>
                  <th>Productos</th>
                  <th>Motivo</th>
                  <th>Fecha</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {devoluciones.map((dev) => (
                  <tr key={dev.numeroSeguimiento}>
                    <td>DEV-{numeroConCeros(dev.numeroSeguimiento, 3)}</td>
                    <td>
                      <Link to={`/mis-pedidos/${dev.numeroPedido}`} className="text-link">
                        #{numeroConCeros(dev.numeroPedido)}
                      </Link>
                    </td>
                    <td>
                      {dev.items.map((item) => (
                        <div key={item.idItemDevolucion} className="small">
                          {item.nombreProducto} x{item.cantidad}
                        </div>
                      ))}
                    </td>
                    <td className="small">{MOTIVOS_DEVOLUCION[dev.motivo] ?? dev.motivo}</td>
                    <td>{formatearFecha(dev.fechaSolicitud)}</td>
                    <td>
                      <Insignia valor={dev.estado} estados={ESTADOS_DEVOLUCION} />
                      {dev.estado === 'RECHAZADA' && dev.motivoRechazo && (
                        <div className="small text-muted mt-1">{dev.motivoRechazo}</div>
                      )}
                      {dev.estado === 'REEMBOLSADA' && dev.montoReembolsado != null && (
                        <div className="small text-muted mt-1">{formatearPrecio(dev.montoReembolsado)}</div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  )
}

export default MisDevolucionesPage
