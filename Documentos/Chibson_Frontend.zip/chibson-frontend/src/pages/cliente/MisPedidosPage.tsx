import { Link } from 'react-router'
import Cargando from '@/components/Cargando'
import Insignia from '@/components/Insignia'
import MensajeError from '@/components/MensajeError'
import useMisPedidos from '@/hooks/useMisPedidos'
import { ESTADOS_PEDIDO } from '@/utils/etiquetas'
import { formatearFecha, formatearPrecio, numeroConCeros } from '@/utils/formato'

export const MisPedidosPage = () => {
  const { pedidos, cargando, error, recargar } = useMisPedidos()

  return (
    <>
      <h1 className="display-6 fw-bold mb-4">Mis pedidos</h1>
      {cargando && <Cargando texto="Cargando pedidos..." />}
      <MensajeError mensaje={error} alReintentar={recargar} />

      {!cargando && !error && pedidos.length === 0 && (
        <div className="text-center py-4">
          <p className="text-muted">Aún no has realizado compras.</p>
          <Link to="/catalogo" className="btn btn-custom">
            Ir al catálogo
          </Link>
        </div>
      )}

      {pedidos.length > 0 && (
        <div className="card border-0 shadow-sm p-3">
          <div className="table-responsive">
            <table className="table align-middle mb-0">
              <thead>
                <tr>
                  <th>N° Pedido</th>
                  <th>Fecha</th>
                  <th>Total</th>
                  <th>Estado</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {pedidos.map((pedido) => (
                  <tr key={pedido.numeroPedido}>
                    <td>
                      <strong>{numeroConCeros(pedido.numeroPedido)}</strong>
                    </td>
                    <td>{formatearFecha(pedido.fecha)}</td>
                    <td>{formatearPrecio(pedido.total)}</td>
                    <td>
                      <Insignia valor={pedido.estado} estados={ESTADOS_PEDIDO} />
                    </td>
                    <td className="text-end">
                      <Link to={`/mis-pedidos/${pedido.numeroPedido}`} className="btn btn-sm btn-outline-dark">
                        Ver detalle
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  )
}

export default MisPedidosPage
