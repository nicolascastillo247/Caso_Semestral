import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router'
import MensajeError from '@/components/MensajeError'
import { mensajeDeError } from '@/api/apiClient'
import TicketService, { type CategoriaTicket } from '@/services/ticket.service'
import { CATEGORIAS_TICKET } from '@/utils/etiquetas'

export const NuevoTicketPage = () => {
  const navigate = useNavigate()
  const [categoria, setCategoria] = useState<CategoriaTicket | ''>('')
  const [asunto, setAsunto] = useState('')
  const [descripcion, setDescripcion] = useState('')
  const [adjuntoUrl, setAdjuntoUrl] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [enviando, setEnviando] = useState(false)

  const enviar = async (evento: FormEvent) => {
    evento.preventDefault()
    if (!categoria) {
      setError('Selecciona una categoría.')
      return
    }
    setEnviando(true)
    setError(null)
    try {
      const ticket = await TicketService.crear({
        categoria,
        asunto,
        descripcion,
        adjuntoUrl: adjuntoUrl.trim() || undefined,
      })
      navigate('/soporte', { replace: true, state: { creado: ticket.numeroTicket } })
    } catch (err) {
      setError(mensajeDeError(err, 'No se pudo crear el ticket.'))
      setEnviando(false)
    }
  }

  return (
    <>
      <Link to="/soporte" className="text-link d-inline-block mb-3">
        ← Volver a mis tickets
      </Link>
      <h1 className="display-6 fw-bold mb-4">Crear solicitud de soporte</h1>
      <div className="card border-0 shadow-sm p-4">
        <form onSubmit={enviar}>
          <MensajeError mensaje={error} />
          <div className="mb-3">
            <label htmlFor="categoria" className="form-label">
              Categoría
            </label>
            <select
              id="categoria"
              className="form-select"
              required
              value={categoria}
              onChange={(e) => setCategoria(e.target.value as CategoriaTicket)}
            >
              <option value="">Seleccione</option>
              {Object.entries(CATEGORIAS_TICKET).map(([valor, texto]) => (
                <option key={valor} value={valor}>
                  {texto}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label htmlFor="asunto" className="form-label">
              Asunto
            </label>
            <input
              id="asunto"
              className="form-control"
              required
              maxLength={150}
              value={asunto}
              onChange={(e) => setAsunto(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="descripcion" className="form-label">
              Descripción
            </label>
            <textarea
              id="descripcion"
              className="form-control"
              rows={6}
              required
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
            ></textarea>
          </div>
          <div className="mb-3">
            <label htmlFor="adjunto" className="form-label">
              Adjunto (enlace a una imagen o documento, opcional)
            </label>
            <input
              id="adjunto"
              type="url"
              className="form-control"
              placeholder="https://..."
              value={adjuntoUrl}
              onChange={(e) => setAdjuntoUrl(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-custom" disabled={enviando}>
            {enviando ? 'Enviando...' : 'Enviar ticket'}
          </button>
        </form>
      </div>
    </>
  )
}

export default NuevoTicketPage
