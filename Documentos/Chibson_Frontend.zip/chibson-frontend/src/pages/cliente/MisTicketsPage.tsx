import { Link, useLocation } from 'react-router'
import Cargando from '@/components/Cargando'
import Insignia from '@/components/Insignia'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import TicketService from '@/services/ticket.service'
import { CATEGORIAS_TICKET, ESTADOS_TICKET } from '@/utils/etiquetas'
import { formatearFecha, numeroConCeros } from '@/utils/formato'

export const MisTicketsPage = () => {
  const { state } = useLocation()
  const { datos, cargando, error, recargar } = useApi(() => TicketService.misTickets())
  const tickets = [...(datos ?? [])].sort((a, b) => b.numeroTicket - a.numeroTicket)
  const creado = (state as { creado?: number } | null)?.creado

  return (
    <>
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <h1 className="display-6 fw-bold m-0">Mis solicitudes de soporte</h1>
        <Link to="/soporte/nuevo" className="btn btn-custom">
          Nuevo ticket
        </Link>
      </div>

      {creado && (
        <div className="alert alert-success">
          Creamos tu ticket TCK-{numeroConCeros(creado, 3)}. Te responderemos a la brevedad.
        </div>
      )}
      {cargando && <Cargando texto="Cargando tickets..." />}
      <MensajeError mensaje={error} alReintentar={recargar} />

      {!cargando && !error && tickets.length === 0 && <p className="text-muted">No tienes tickets de soporte.</p>}

      {tickets.length > 0 && (
        <div className="card border-0 shadow-sm p-3">
          <div className="table-responsive">
            <table className="table align-middle mb-0">
              <thead>
                <tr>
                  <th>N° Ticket</th>
                  <th>Asunto</th>
                  <th>Categoría</th>
                  <th>Fecha</th>
                  <th>Estado</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((ticket) => (
                  <tr key={ticket.numeroTicket}>
                    <td>TCK-{numeroConCeros(ticket.numeroTicket, 3)}</td>
                    <td>{ticket.asunto}</td>
                    <td>{CATEGORIAS_TICKET[ticket.categoria] ?? ticket.categoria}</td>
                    <td>{formatearFecha(ticket.fechaCreacion)}</td>
                    <td>
                      <Insignia valor={ticket.estado} estados={ESTADOS_TICKET} />
                    </td>
                    <td className="text-end">
                      <Link to={`/soporte/${ticket.numeroTicket}`} className="btn btn-sm btn-outline-dark">
                        Ver
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  )
}

export default MisTicketsPage
