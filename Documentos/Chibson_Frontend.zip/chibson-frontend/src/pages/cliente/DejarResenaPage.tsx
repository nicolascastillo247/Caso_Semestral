import { useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import MensajeError from '@/components/MensajeError'
import { useProducto } from '@/hooks/useProductos'
import { mensajeDeError } from '@/api/apiClient'
import ResenaService from '@/services/resena.service'
import { imagenRespaldo, urlImagen } from '@/utils/formato'

const OPCIONES = [
  [5, 'Excelente'],
  [4, 'Muy bueno'],
  [3, 'Bueno'],
  [2, 'Regular'],
  [1, 'Malo'],
] as const

export const DejarResenaPage = () => {
  const { sku = '' } = useParams()
  const { producto, cargando, error: errorProducto } = useProducto(sku)
  const [calificacion, setCalificacion] = useState('')
  const [titulo, setTitulo] = useState('')
  const [comentario, setComentario] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [enviada, setEnviada] = useState(false)
  const [enviando, setEnviando] = useState(false)

  if (cargando) return <Cargando texto="Cargando producto..." />
  if (errorProducto || !producto) return <MensajeError mensaje={errorProducto ?? 'El producto no existe.'} />

  const enviar = async (evento: FormEvent) => {
    evento.preventDefault()
    setEnviando(true)
    setError(null)
    try {
      await ResenaService.crear({ sku: producto.sku, calificacion: Number(calificacion), titulo, comentario })
      setEnviada(true)
    } catch (err) {
      setError(mensajeDeError(err, 'No se pudo publicar la reseña.'))
    } finally {
      setEnviando(false)
    }
  }

  return (
    <>
      <h1 className="display-6 fw-bold mb-4">Dejar reseña</h1>
      <div className="row g-4">
        <div className="col-md-4">
          <div className="card product-card border-0 shadow-sm p-4 text-center">
            <img
              src={urlImagen(producto.imagenUrl)}
              onError={imagenRespaldo}
              alt={producto.modelo}
              className="img-fluid mx-auto mb-3"
              style={{ maxHeight: 200, objectFit: 'contain' }}
            />
            <h2 className="h5 fw-bold mb-0">{producto.modelo}</h2>
            <p className="small text-muted mb-0">{producto.marca}</p>
          </div>
        </div>
        <div className="col-md-8">
          <div className="card border-0 shadow-sm p-4">
            {enviada ? (
              <div className="text-center py-3">
                <h2 className="h4 fw-bold">¡Gracias por tu opinión!</h2>
                <p className="text-muted">Tu reseña será visible cuando el equipo de Chibson la apruebe.</p>
                <Link to={`/productos/${encodeURIComponent(producto.sku)}`} className="btn btn-custom">
                  Volver al producto
                </Link>
              </div>
            ) : (
              <form onSubmit={enviar}>
                <MensajeError mensaje={error} />
                <div className="mb-3">
                  <label htmlFor="calificacion" className="form-label">
                    Calificación
                  </label>
                  <select
                    id="calificacion"
                    className="form-select"
                    required
                    value={calificacion}
                    onChange={(e) => setCalificacion(e.target.value)}
                  >
                    <option value="">Seleccione</option>
                    {OPCIONES.map(([valor, texto]) => (
                      <option key={valor} value={valor}>
                        {valor} - {texto}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="mb-3">
                  <label htmlFor="titulo" className="form-label">
                    Título
                  </label>
                  <input
                    id="titulo"
                    className="form-control"
                    required
                    maxLength={100}
                    value={titulo}
                    onChange={(e) => setTitulo(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="comentario" className="form-label">
                    Comentario
                  </label>
                  <textarea
                    id="comentario"
                    className="form-control"
                    rows={6}
                    required
                    value={comentario}
                    onChange={(e) => setComentario(e.target.value)}
                  ></textarea>
                </div>
                <button type="submit" className="btn btn-custom" disabled={enviando}>
                  {enviando ? 'Publicando...' : 'Publicar reseña'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </>
  )
}

export default DejarResenaPage
