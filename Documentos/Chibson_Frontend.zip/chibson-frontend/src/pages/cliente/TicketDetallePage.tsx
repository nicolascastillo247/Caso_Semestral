import { useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import Insignia from '@/components/Insignia'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import { mensajeDeError } from '@/api/apiClient'
import TicketService from '@/services/ticket.service'
import { CATEGORIAS_TICKET, ESTADOS_TICKET } from '@/utils/etiquetas'
import { estrellas, formatearFechaHora, numeroConCeros } from '@/utils/formato'

const OPCIONES_CALIFICACION = [
  [5, 'Excelente'],
  [4, 'Buena'],
  [3, 'Regular'],
  [2, 'Mala'],
  [1, 'Muy mala'],
] as const

export const TicketDetallePage = () => {
  const { numero = '' } = useParams()
  const { datos: ticket, cargando, error, recargar } = useApi(() => TicketService.miTicket(Number(numero)), [numero])
  const [calificacion, setCalificacion] = useState('')
  const [comentario, setComentario] = useState('')
  const [errorCierre, setErrorCierre] = useState<string | null>(null)
  const [enviando, setEnviando] = useState(false)

  if (cargando) return <Cargando texto="Cargando ticket..." />
  if (error || !ticket) {
    return (
      <>
        <MensajeError mensaje={error ?? 'No se encontró el ticket.'} alReintentar={recargar} />
        <Link to="/soporte" className="text-link">
          ← Volver a mis tickets
        </Link>
      </>
    )
  }

  const cerrar = async (evento: FormEvent) => {
    evento.preventDefault()
    setEnviando(true)
    setErrorCierre(null)
    try {
      await TicketService.cerrar(ticket.numeroTicket, { calificacion: Number(calificacion), comentario })
      await recargar()
    } catch (err) {
      setErrorCierre(mensajeDeError(err, 'No se pudo cerrar el ticket.'))
    } finally {
      setEnviando(false)
    }
  }

  return (
    <>
      <Link to="/soporte" className="text-link d-inline-block mb-3">
        ← Volver a mis tickets
      </Link>
      <h1 className="display-6 fw-bold">Ticket #TCK-{numeroConCeros(ticket.numeroTicket, 3)}</h1>
      <p className="d-flex flex-wrap gap-2 align-items-center">
        <Insignia valor={ticket.estado} estados={ESTADOS_TICKET} />
        <span className="badge bg-light text-dark border">{CATEGORIAS_TICKET[ticket.categoria] ?? ticket.categoria}</span>
        <span className="small text-muted">Creado el {formatearFechaHora(ticket.fechaCreacion)}</span>
      </p>

      <div className="card border-0 shadow-sm p-4 mb-4">
        <h2 className="h4 fw-bold mb-3">{ticket.asunto}</h2>

        <div className="d-flex flex-column gap-3">
          <div className="p-3 rounded bg-light">
            <strong>Tú</strong> <span className="small text-muted">· {formatearFechaHora(ticket.fechaCreacion)}</span>
            <p className="mb-0 mt-1">{ticket.descripcion}</p>
            {ticket.adjuntoUrl && (
              <a href={ticket.adjuntoUrl} target="_blank" rel="noreferrer" className="small text-link">
                Ver adjunto
              </a>
            )}
          </div>

          {ticket.mensajes.map((mensaje) => (
            <div
              key={mensaje.idMensaje}
              className={`p-3 rounded ${mensaje.esAdministrador ? 'category-card border' : 'bg-light'}`}
            >
              <strong>{mensaje.esAdministrador ? 'Soporte Chibson' : 'Tú'}</strong>{' '}
              <span className="small text-muted">· {formatearFechaHora(mensaje.fecha)}</span>
              <p className="mb-0 mt-1">{mensaje.contenido}</p>
            </div>
          ))}

          {ticket.mensajes.length === 0 && (
            <p className="text-muted small mb-0">Aún no hay respuestas del equipo de soporte.</p>
          )}
        </div>
      </div>

      {ticket.estado === 'RESUELTO' && (
        <div className="card border-0 shadow-sm p-4">
          <h2 className="h4 fw-bold">Calificar atención y cerrar</h2>
          <form onSubmit={cerrar}>
            <MensajeError mensaje={errorCierre} />
            <div className="mb-3">
              <label htmlFor="calificacion" className="form-label">
                Calificación
              </label>
              <select
                id="calificacion"
                className="form-select"
                required
                value={calificacion}
                onChange={(e) => setCalificacion(e.target.value)}
              >
                <option value="">Seleccione</option>
                {OPCIONES_CALIFICACION.map(([valor, texto]) => (
                  <option key={valor} value={valor}>
                    {valor} - {texto}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-3">
              <label htmlFor="comentario" className="form-label">
                Comentario
              </label>
              <textarea
                id="comentario"
                className="form-control"
                rows={4}
                value={comentario}
                onChange={(e) => setComentario(e.target.value)}
              ></textarea>
            </div>
            <button type="submit" className="btn btn-custom" disabled={enviando}>
              {enviando ? 'Enviando...' : 'Enviar calificación'}
            </button>
          </form>
        </div>
      )}

      {ticket.estado === 'CERRADO' && ticket.calificacion != null && (
        <div className="alert alert-secondary">
          Calificaste esta atención con <strong>{estrellas(ticket.calificacion)}</strong>
          {ticket.comentarioCalificacion && <>: “{ticket.comentarioCalificacion}”</>}
        </div>
      )}
    </>
  )
}

export default TicketDetallePage
