import { Link, useParams } from 'react-router'
import Cargando from '@/components/Cargando'
import Insignia from '@/components/Insignia'
import MensajeError from '@/components/MensajeError'
import useApi from '@/hooks/useApi'
import PedidoService from '@/services/pedido.service'
import { ESTADOS_PEDIDO, METODOS_PAGO } from '@/utils/etiquetas'
import { formatearFecha, formatearPrecio, numeroConCeros } from '@/utils/formato'

export const ConfirmacionPedidoPage = () => {
  const { numero = '' } = useParams()
  const { datos: pedido, cargando, error, recargar } = useApi(() => PedidoService.miPedido(Number(numero)), [numero])

  if (cargando) return <Cargando texto="Cargando comprobante..." />
  if (error || !pedido) return <MensajeError mensaje={error ?? 'No se encontró el pedido.'} alReintentar={recargar} />

  const unidades = pedido.items.reduce((total, item) => total + item.cantidad, 0)

  return (
    <div className="row justify-content-center">
      <div className="col-lg-7">
        <div className="card product-card border-0 shadow-sm p-5 text-center">
          <i className="bi bi-check-circle-fill text-success display-4 mb-2"></i>
          <h1 className="h2 fw-bold">Compra realizada correctamente</h1>
          <p className="text-muted">Tu pedido fue registrado y el pago fue aprobado.</p>
          <div className="category-card rounded p-4 text-start my-4">
            <p>
              <strong>Número de pedido:</strong> {numeroConCeros(pedido.numeroPedido)}
            </p>
            <p>
              <strong>Fecha:</strong> {formatearFecha(pedido.fecha)}
            </p>
            <p>
              <strong>Estado:</strong> <Insignia valor={pedido.estado} estados={ESTADOS_PEDIDO} />
            </p>
            <p>
              <strong>Método de pago:</strong> {pedido.metodoPago ? METODOS_PAGO[pedido.metodoPago] : '—'}
            </p>
            <p>
              <strong>Productos:</strong> {unidades}
            </p>
            <p className="mb-0">
              <strong>Total:</strong> {formatearPrecio(pedido.total)}
            </p>
          </div>
          <div className="d-flex justify-content-center gap-2">
            <Link to={`/mis-pedidos/${pedido.numeroPedido}`} className="btn btn-custom">
              Ver pedido
            </Link>
            <Link to="/" className="btn btn-outline-dark">
              Volver al inicio
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ConfirmacionPedidoPage
