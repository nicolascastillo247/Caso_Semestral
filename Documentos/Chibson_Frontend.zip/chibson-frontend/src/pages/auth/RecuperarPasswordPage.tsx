import { useState, type ChangeEvent, type FormEvent } from 'react'
import { Link } from 'react-router'
import CampoTexto from '@/components/CampoTexto'
import MensajeError from '@/components/MensajeError'
import { mensajeDeError } from '@/api/apiClient'
import AuthService, { type RecuperarPayload } from '@/services/auth.service'

export const RecuperarPasswordPage = () => {
  const [datos, setDatos] = useState<RecuperarPayload>({
    rut: '',
    correo: '',
    nuevaPassword: '',
    confirmarPassword: '',
  })
  const [error, setError] = useState<string | null>(null)
  const [exito, setExito] = useState<string | null>(null)
  const [enviando, setEnviando] = useState(false)

  const cambiar = (evento: ChangeEvent<HTMLInputElement>) =>
    setDatos({ ...datos, [evento.target.name]: evento.target.value })

  const enviar = async (evento: FormEvent) => {
    evento.preventDefault()
    if (datos.nuevaPassword !== datos.confirmarPassword) {
      setError('Las contraseñas no coinciden.')
      return
    }
    setEnviando(true)
    setError(null)
    try {
      setExito(await AuthService.recuperarPassword(datos))
    } catch (err) {
      setError(mensajeDeError(err, 'No se pudo recuperar la contraseña.'))
    } finally {
      setEnviando(false)
    }
  }

  return (
    <div className="row justify-content-center">
      <div className="col-12 col-sm-10 col-md-8 col-lg-5">
        <div className="card p-4 p-md-5 shadow-sm border-0 product-card">
          <div className="text-center mb-4">
            <h2 className="h3 fw-bold">Recuperar contraseña</h2>
            <p className="text-muted small">
              Ingresa el RUT y el correo de tu cuenta, y elige una contraseña nueva.
            </p>
          </div>

          {exito ? (
            <div className="alert alert-success text-center">
              <p className="mb-2">{exito}</p>
              <Link to="/login" className="btn btn-custom">
                Iniciar sesión
              </Link>
            </div>
          ) : (
            <form onSubmit={enviar}>
              <MensajeError mensaje={error} />
              <CampoTexto id="rut" name="rut" etiqueta="RUT" required value={datos.rut} onChange={cambiar} />
              <CampoTexto
                id="correo"
                name="correo"
                etiqueta="Correo electrónico"
                type="email"
                placeholder="nombre@ejemplo.com"
                required
                value={datos.correo}
                onChange={cambiar}
              />
              <CampoTexto
                id="nuevaPassword"
                name="nuevaPassword"
                etiqueta="Nueva contraseña"
                type="password"
                minLength={8}
                required
                value={datos.nuevaPassword}
                onChange={cambiar}
              />
              <CampoTexto
                id="confirmarPassword"
                name="confirmarPassword"
                etiqueta="Confirmar contraseña"
                type="password"
                minLength={8}
                className="mb-4"
                required
                value={datos.confirmarPassword}
                onChange={cambiar}
              />
              <button type="submit" className="btn btn-custom w-100 py-2" disabled={enviando}>
                {enviando ? 'Guardando...' : 'Cambiar contraseña'}
              </button>
            </form>
          )}

          <hr className="custom-divider my-4" />
          <div className="text-center small">
            <p className="mb-2">
              <Link to="/login" className="text-link">
                ← Volver a Iniciar Sesión
              </Link>
            </p>
            <p className="mb-0">
              ¿No tienes cuenta?{' '}
              <Link to="/registro" className="text-link">
                Regístrate aquí
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default RecuperarPasswordPage
