import { useState, type FormEvent } from 'react'
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router'
import CampoTexto from '@/components/CampoTexto'
import MensajeError from '@/components/MensajeError'
import { useAuth } from '@/context/AuthContext'
import { mensajeDeError } from '@/api/apiClient'

export const destinoSeguro = (redireccion: string | null): string =>
  redireccion && redireccion.startsWith('/') && !redireccion.startsWith('//') ? redireccion : '/'

export const LoginPage = () => {
  const { iniciarSesion, estaAutenticado } = useAuth()
  const navigate = useNavigate()
  const [parametros] = useSearchParams()
  const redireccion = destinoSeguro(parametros.get('redirect'))

  const [correo, setCorreo] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [enviando, setEnviando] = useState(false)

  if (estaAutenticado && !enviando) {
    return <Navigate to={redireccion} replace />
  }

  const enviar = async (evento: FormEvent) => {
    evento.preventDefault()
    setEnviando(true)
    setError(null)
    try {
      const sesion = await iniciarSesion({ correo: correo.trim(), password })
      navigate(sesion.rol === 'CLIENTE' ? redireccion : '/admin', { replace: true })
    } catch (err) {
      setError(mensajeDeError(err, 'No se pudo iniciar sesión.'))
      setEnviando(false)
    }
  }

  return (
    <div className="row justify-content-center">
      <div className="col-12 col-sm-10 col-md-8 col-lg-5">
        <div className="card p-4 p-md-5 shadow-sm border-0 product-card">
          <form onSubmit={enviar}>
            <div className="text-center mb-4">
              <h2 className="h3 fw-bold">Inicio de sesión</h2>
              <p className="text-muted small">Ingresa tus credenciales para acceder a tu cuenta</p>
            </div>

            <MensajeError mensaje={error} />

            <CampoTexto
              id="email"
              etiqueta="Correo electrónico"
              type="email"
              placeholder="nombre@ejemplo.com"
              autoComplete="email"
              required
              value={correo}
              onChange={(e) => setCorreo(e.target.value)}
            />
            <CampoTexto
              id="password"
              etiqueta="Contraseña"
              type="password"
              placeholder="••••••••"
              autoComplete="current-password"
              className="mb-4"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <button type="submit" className="btn btn-custom w-100 py-2" disabled={enviando}>
              {enviando ? 'Ingresando...' : 'Iniciar Sesión'}
            </button>
          </form>

          <hr className="custom-divider my-4" />
          <div className="text-center small">
            <p className="mb-2">
              ¿No tienes una cuenta?{' '}
              <Link to={`/registro?redirect=${encodeURIComponent(redireccion)}`} className="text-link">
                Regístrate aquí
              </Link>
            </p>
            <p className="mb-0">
              <Link to="/recuperar-password" className="text-link">
                ¿Olvidaste tu contraseña?
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
