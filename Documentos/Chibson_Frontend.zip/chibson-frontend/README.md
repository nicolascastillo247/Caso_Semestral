# Chibson Instruments · Frontend

Tienda de Chibson Instruments hecha con React + TypeScript + Vite. Se conecta al backend de microservicios a través del API Gateway (`http://localhost:8080`).

## Requisitos

- Node.js 20 o superior.
- El backend corriendo (`iniciar-todo.ps1` en la carpeta del backend) con MySQL encendido.

## Ejecutar

```
npm install
npm run dev
```

Se abre en `http://localhost:5173`. Para apuntar a otro gateway, copia `.env.example` a `.env` y cambia `VITE_API_URL`.

## Cuentas para probar

- Administrador: `admin@chibson.cl` / `Admin1234` (se crea solo al levantar ms-usuarios).
- Cliente: regístrate desde la página "Registrarse".

## Estructura

```
src/
├── api/apiClient.ts      axios con la URL del gateway, el token y los mensajes de error
├── services/             una clase de servicio por recurso del backend (productos, pedidos, tickets...)
├── hooks/                useApi (carga, error y recarga) y hooks por recurso
├── context/              sesión (AuthContext) y carro de compras (CarritoContext)
├── components/           Navbar, Footer, tarjetas, modal de login, ruta privada
├── layouts/              TiendaLayout (navbar + contenido + footer)
├── pages/tienda/         inicio, catálogo, producto, noticias, nosotros
├── pages/auth/           login, registro, recuperar contraseña
├── pages/cliente/        carro, checkout, pedidos, devoluciones, soporte, perfil, reseñas
├── router/app.router.tsx rutas (createBrowserRouter)
└── utils/                formato de precios y fechas, etiquetas de estados
```

## Cómo se conecta con el backend

- Todas las peticiones van al gateway. Al iniciar sesión se guarda el token y `apiClient` lo manda en `Authorization: Bearer <token>`; el gateway lo valida y le pasa el RUT a cada microservicio.
- Las listas vienen con HATEOAS dentro de `_embedded` (por ejemplo `_embedded.productos`). `listaDe()` las extrae.
- Los errores muestran el campo `message` que devuelve el backend.
- Si el token expira (401), la sesión se cierra y se pide iniciar sesión de nuevo.
- El carro se guarda en el navegador (localStorage), separado por usuario. Al confirmar la compra se envía a `POST /api/pedidos/checkout`.

## Rutas

| Ruta | Página | Sesión |
|---|---|---|
| `/` | Inicio | No |
| `/catalogo` | Catálogo con búsqueda y filtros | No |
| `/productos/:sku` | Detalle, ficha técnica y reseñas | No |
| `/noticias`, `/noticias/:id` | Noticias | No |
| `/nosotros` | Información institucional | No |
| `/login`, `/registro`, `/recuperar-password` | Cuenta | No |
| `/carrito`, `/checkout`, `/pedido-confirmado/:numero` | Compra | Cliente |
| `/mis-pedidos`, `/mis-pedidos/:numero` | Pedidos | Cliente |
| `/mis-pedidos/:numero/devolucion`, `/devoluciones` | Devoluciones | Cliente |
| `/soporte`, `/soporte/nuevo`, `/soporte/:numero` | Tickets | Cliente |
| `/perfil` | Mi perfil | Cliente |
| `/productos/:sku/resena` | Dejar reseña | Cliente |
| `/admin` | Panel de administración (pendiente) | Administrador |
